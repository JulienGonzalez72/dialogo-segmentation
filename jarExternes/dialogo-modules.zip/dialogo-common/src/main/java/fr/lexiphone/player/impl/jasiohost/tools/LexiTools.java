package fr.lexiphone.player.impl.jasiohost.tools;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

public class LexiTools {
	
	/**
	 * this is a method to make an attenuation
	 * @return a float who is the attenuation factor
	 */
//	static public float getAttenuationFactor(int numberOfChannels){
//		return (float) Math.pow(10.0, (-1.0f * 0.1f * numberOfChannels) / 20.0);
//	}

	static public <T> T[] concat(T[] first, T[] second) {
//		return (T[]) ArrayUtils.addAll(first, second);
		if(first == null && second != null)
			return second;
		else if (first != null && second == null)
			return first;
		else if (first == null && second == null)
			return null;
		T[] result = Arrays.copyOf(first, first.length + second.length);
		System.arraycopy(second, 0, result, first.length, second.length);
		return result;
	}
	
	static public <T> List<T> mergeList(List<T> first, List<T> second) {
		if(first == null && second != null)
			return second;
		else if (first != null && second == null)
			return first;
		else if (first == null && second == null)
			return null;
		List<T> result = new ArrayList<T>(first);
		Iterator<T> it = second.iterator();
		while(it.hasNext()){
			T object = it.next();
			if(!result.contains(object))
				result.add(object);
		}
		return result;
	}
	
	/**
	 * 
	 * @param aString
	 * @return -1 if unable to parse to double
	 */
	static public double stringToDouble(String aString) {
//		if(!Pattern.matches("^\\d+[,\\.]?\\d+$", aString))
//			return null;
//		return Double.parseDouble(aString.replace(',', '.'));
		try {
			return Double.parseDouble(aString.replace(',', '.'));
		} catch (NumberFormatException e) {
			return -1;
		}
	}
}
