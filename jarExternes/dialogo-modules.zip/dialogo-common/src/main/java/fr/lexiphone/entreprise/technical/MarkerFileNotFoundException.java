/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lexiphone.entreprise.technical;

import fr.lexiphone.reusable.util.i18n.Messages;

/**
 *
 * @author haerwynn
 */
public class MarkerFileNotFoundException extends SpecificFileNotFoundException{


	public MarkerFileNotFoundException() {
		super(Messages.getStringOrKey("entreprisesignalprocessingservice.nomrkfile")+" !");
	}

	public MarkerFileNotFoundException(String path) {
		super(Messages.getStringOrKey("entreprisesignalprocessingservice.nomrkfile")+" : "+path);
	}

}
