
package fr.lexiphone.entreprise.workmodule;

import fr.lexiphone.entreprise.technical.IEntrepriseData;
import java.io.Serializable;
import java.util.Map;
import java.util.Properties;

/**
 * <P>
 *  Bean de configuration du mode session patient du Lexiphone.
 * </P>
 * @author pprimot
 */

public class PhaseConfigurationBean implements IEntrepriseData, Serializable{

	/** VI : FICHIER emplacement du fichier son. */
	private String completeFilePath = null;

	private Properties sampleProperties;
	
	/** VI : FICHIER excursion disque. */
	private float fileExcursion = -1;
	
	/** VI : FICHIER volume disque. */
	private float fileVolume = -1;
	
	/** VI : PATIENT Fr�quence ultrasonique. */
	private int patientUltraSonicFrequency = -1;
	
	/** VI : PATIENT volume d'�coute du patient. */
	private float patientSpeakersVolume = -1;
	
	/** VI : PATIENT modificateur de vitesse du patient. */
	private float patientSpeedModifier = -1;
	
	/** VI : PATIENT indicateur de surcharge son. */
	private boolean patientExtraVolume = false;
	
	/** VI : PATIENT niveau du microphone patient. */
	private float patientMicrophoneInputLevel = -1;
	
	/** VI : PATIENT balance. */
	private float patientBalance = 0;
	
	/** VI : PATIENT mpmodulation. */
	private float patientMPModulation = -1;

	/** VI : PATIENT excursion. */
	private float patientExcursion = -1;

	/** VI : THERAPEUTE volume d'�coute du th�rapeute. */
	private float therapistSpeakersVolume = -1;

	/** VI : THERAPEUTE niveau du microphone th�rapeute. */
	private float therapistMicrophoneInputLevel = -1;
	
	/** VI : THERAPEUTE excursion. */
	private float therapistExcursion = -1;
	
	/** VI : PHASE stereo. */
	private float phaseStereo = -1;	
	
	/** VI : PHASE indicateur d'alternance. */
	private boolean phaseAlternance = false;
	
	/** VI : PHASE tempo des pauses. */
	private float phaseTempoPause = -1;
	
	/** VI : PHASE tempo des coupures son . */
	private float phaseTempoSound = -1;
	
	/** VI : PHASE mode d'�coute (M, M/P, P). */
	private String phaseSoundMode = null;
	
	private String phaseTypeName = null;
	
	/** Pr�f�rences d'affichage pour repetitionecrite ou lectureguideeanticipee */ 
	private Map<String, String> displayPreferencesMap = null;

	private ExerciseType exerciseType;

	private String sampleTitle;
	
	/** auto-set clean high frequency after a few seconds, after a f0 change */
	private boolean autoResetCleanHighFrequency = true;

	private boolean allowAudioWindowRestore=false;
	private Boolean readOnScreen;
	private String language;
	
	/** Constructeur. */
	public PhaseConfigurationBean() {
		super();	
	}

	/**
	 * Gets the completeFilePath.
	 * @return Returns a String
	 */
	public String getCompleteFilePath() {
		return completeFilePath;
	}

	/**
	 * Sets the completeFilePath.
	 * @param completeFilePath The completeFilePath to set
	 */
	public void setCompleteFilePath(String completeFilePath) {
		this.completeFilePath = completeFilePath;
	}

	/**
	 * Gets the patientUltraSonicFrequency.
	 * @return Returns a int
	 */
	public int getPatientUltraSonicFrequency() {
		return patientUltraSonicFrequency;
	}

	/**
	 * Sets the patientUltraSonicFrequency.
	 * @param patientUltraSonicFrequency The patientUltraSonicFrequency to set
	 */
	public void setPatientUltraSonicFrequency(int patientUltraSonicFrequency) {
		this.patientUltraSonicFrequency = patientUltraSonicFrequency;
	}

	/**
	 * Gets the patientSpeakersVolume.
	 * @return Returns a float
	 */
	public float getPatientSpeakersVolume() {
		return patientSpeakersVolume;
	}

	/**
	 * Sets the patientSpeakersVolume.
	 * @param patientSpeakersVolume The patientSpeakersVolume to set
	 */
	public void setPatientSpeakersVolume(float patientSpeakersVolume) {
		this.patientSpeakersVolume = patientSpeakersVolume;
	}

	/**
	 * Gets the patientSpeedModifier.
	 * @return Returns a float
	 */
	public float getPatientSpeedModifier() {
		return patientSpeedModifier;
	}

	/**
	 * Sets the patientSpeedModifier.
	 * @param patientSpeedModifier The patientSpeedModifier to set
	 */
	public void setPatientSpeedModifier(float patientSpeedModifier) {
		this.patientSpeedModifier = patientSpeedModifier;
	}

	/**
	 * Gets the therapistSpeakersVolume.
	 * @return Returns a float
	 */
	public float getTherapistSpeakersVolume() {
		return therapistSpeakersVolume;
	}

	/**
	 * Sets the therapistSpeakersVolume.
	 * @param therapistSpeakersVolume The therapistSpeakersVolume to set
	 */
	public void setTherapistSpeakersVolume(float therapistSpeakersVolume) {
		this.therapistSpeakersVolume = therapistSpeakersVolume;
	}

	/**
	 * Gets the patientExtraVolume.
	 * @return Returns a boolean
	 */
	public boolean getPatientExtraVolume() {
		return patientExtraVolume;
	}

	/**
	 * Sets the patientExtraVolume.
	 * @param patientExtraVolume The patientExtraVolume to set
	 */
	public void setPatientExtraVolume(boolean patientExtraVolume) {
		this.patientExtraVolume = patientExtraVolume;
	}

	/**
	 * Gets the patientMicrophoneInputLevel.
	 * @return Returns a float
	 */
	public float getPatientMicrophoneInputLevel() {
		return patientMicrophoneInputLevel;
	}

	/**
	 * Sets the patientMicrophoneInputLevel.
	 * @param patientMicrophoneInputLevel The patientMicrophoneInputLevel to set
	 */
	public void setPatientMicrophoneInputLevel(float patientMicrophoneInputLevel) {
		this.patientMicrophoneInputLevel = patientMicrophoneInputLevel;
	}

	/**
	 * Gets the therapistMicrophoneInputLevel.
	 * @return Returns a float
	 */
	public float getTherapistMicrophoneInputLevel() {
		return therapistMicrophoneInputLevel;
	}

	/**
	 * Sets the therapistMicrophoneInputLevel.
	 * @param therapistMicrophoneInputLevel The therapistMicrophoneInputLevel to set
	 */
	public void setTherapistMicrophoneInputLevel(float therapistMicrophoneInputLevel) {
		this.therapistMicrophoneInputLevel = therapistMicrophoneInputLevel;
	}

	/**
	 * Gets the therapistExcursion.
	 * @return Returns a float
	 */
	public float getTherapistExcursion() {
		return therapistExcursion;
	}

	/**
	 * Sets the therapistExcursion.
	 * @param therapistExcursion The therapistExcursion to set
	 */
	public void setTherapistExcursion(float therapistExcursion) {
		this.therapistExcursion = therapistExcursion;
	}

	/**
	 * Gets the patientBalance.
	 * @return Returns a float
	 */
	public float getPatientBalance() {
		return patientBalance;
	}

	/**
	 * Sets the patientBalance.
	 * @param patientBalance The patientBalance to set
	 */
	public void setPatientBalance(float patientBalance) {
		this.patientBalance = patientBalance;
	}

	/**
	 * Gets the phaseStereo.
	 * @return Returns a float
	 */
	public float getPhaseStereo() {
		return phaseStereo;
	}

	/**
	 * Sets the phaseStereo.
	 * @param phaseStereo The phaseStereo to set
	 */
	public void setPhaseStereo(float phaseStereo) {
		this.phaseStereo = phaseStereo;
	}

	/**
	 * Gets the patientMPModulation.
	 * @return Returns a float
	 */
	public float getPatientMPModulation() {
		return patientMPModulation;
	}

	/**
	 * Sets the patientMPModulation.
	 * @param patientMPModulation The patientMPModulation to set
	 */
	public void setPatientMPModulation(float patientMPModulation) {
		this.patientMPModulation = patientMPModulation;
	}

	/**
	 * Gets the phaseAlternance.
	 * @return Returns a boolean
	 */
	public boolean getPhaseAlternance() {
		return phaseAlternance;
	}

	/**
	 * Sets the phaseAlternance.
	 * @param phaseAlternance The phaseAlternance to set
	 */
	public void setPhaseAlternance(boolean phaseAlternance) {
		this.phaseAlternance = phaseAlternance;
	}

	/**
	 * Gets the phaseTempoPause.
	 * @return Returns a float
	 */
	public float getPhaseTempoPause() {
		return phaseTempoPause;
	}

	/**
	 * Sets the phaseTempoPause.
	 * @param phaseTempoPause The phaseTempoPause to set
	 */
	public void setPhaseTempoPause(float phaseTempoPause) {
		this.phaseTempoPause = phaseTempoPause;
	}

	/**
	 * Gets the phaseTempoSound.
	 * @return Returns a float
	 */
	public float getPhaseTempoSound() {
		return phaseTempoSound;
	}

	/**
	 * Sets the phaseTempoSound.
	 * @param phaseTempoSound The phaseTempoSound to set
	 */
	public void setPhaseTempoSound(float phaseTempoSound) {
		this.phaseTempoSound = phaseTempoSound;
	}


	/**
	 * Gets the fileExcursion.
	 * @return Returns a float
	 */
	public float getFileExcursion() {
		return fileExcursion;
	}

	/**
	 * Sets the fileExcursion.
	 * @param fileExcursion The fileExcursion to set
	 */
	public void setFileExcursion(float fileExcursion) {
		this.fileExcursion = fileExcursion;
	}

	/**
	 * Gets the phaseSoundMode.
	 * @return Returns a String
	 */
	public String getPhaseSoundMode() {
		return phaseSoundMode;
	}

	/**
	 * Sets the phaseSoundMode.
	 * @param phaseSoundMode The phaseSoundMode to set
	 */
	public void setPhaseSoundMode(String phaseSoundMode) {
		this.phaseSoundMode = phaseSoundMode;
	}

	/**
	 * @return
	 */
	public float getPatientExcursion() {
		return patientExcursion;
	}

	/**
	 * @param in_f
	 */
	public void setPatientExcursion(float in_f) {
		patientExcursion = in_f;
	}

	/**
	 * @return
	 */
	public float getFileVolume() {
		return fileVolume;
	}

	/**
	 * @param in_f
	 */
	public void setFileVolume(float in_f) {
		fileVolume = in_f;
	}

	/**
	 * @return
	 */
	public String getPhaseTypeName() {
		return phaseTypeName;
	}

	/**
	 * @param in_string
	 */
	public void setPhaseTypeName(String in_string) {
		phaseTypeName = in_string;
	}

	/*public void setAutoStart(Boolean autoStart) {
		if(autoStart==null)autoStart=Boolean.FALSE;
		this.autoStart=autoStart.booleanValue();
	}

	public boolean getAutoStart() {
		return this.autoStart;
	}*/

	public ExerciseType getExerciseType() {
		return exerciseType;
	}

	public void setExerciseType(ExerciseType exerciseType) {
		this.exerciseType = exerciseType;
	}

	public void setSampleTitle(String name) {
		sampleTitle=name;
	}

	public String getSampleTitle() {
		return sampleTitle;
	}

	public void setDisplayPreferencesMap(
			Map<String, String> displayPreferencesMap) {
		this.displayPreferencesMap=displayPreferencesMap;
	}

	public Map<String, String> getDisplayPreferencesMap(){
		return displayPreferencesMap;
	}

	public boolean isAutoResetCleanHighFrequency() {
		return autoResetCleanHighFrequency;
	}

	public void setAutoResetCleanHighFrequency(boolean autoResetCleanHighFrequency) {
		this.autoResetCleanHighFrequency = autoResetCleanHighFrequency;
	}

	public boolean isAllowAudioWindowRestore() {
		return allowAudioWindowRestore;
	}

	public void setAllowAudioWindowRestore(boolean allowAudioWindowRestore) {
		this.allowAudioWindowRestore = allowAudioWindowRestore;
	}

	public Properties getSampleProperties() {
		return sampleProperties;
	}

	public void setSampleProperties(Properties sampleProperties) {
		this.sampleProperties = sampleProperties;
	}

	public void setReadOnScreen(Boolean readOnScreen) {
		this.readOnScreen=readOnScreen;
	}

	public boolean isReadOnScreen() {
		return readOnScreen!=null&&readOnScreen;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}
	
}
