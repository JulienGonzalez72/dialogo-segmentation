/**
 * 
 */
package fr.lexiphone.configuration;

import static java.util.concurrent.TimeUnit.*;

import java.io.File;
import java.net.URL;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.FileConfiguration;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.reloading.FileChangedReloadingStrategy;

/**
 * @author C&eacute;drik LIME
 */
public class DLGConfiguration extends PropertiesConfiguration implements FileConfiguration {

	public static enum Type {
		SYSTEM(Folder.SYSTEM_CONFIGURATION),
		USER_COMMON(Folder.USER_COMMON_CONFIGURATION),
		USER_SPECIFIC(Folder.USER_SPECIFIC_CONFIGURATION),
		VERSIONS(Folder.VERSIONS);
		
		protected final Folder folder;
		private Type(Folder folder) {
			this.folder = folder;
		}
	}

	public DLGConfiguration() {
		super();
		init();
	}
	public DLGConfiguration(String fileName) throws ConfigurationException {
		super(fileName);
		init();
	}
	public DLGConfiguration(File file) throws ConfigurationException {
		super(file);
		init();
	}
	public DLGConfiguration(URL url) throws ConfigurationException {
		super(url);
		init();
	}
	
	protected void init() {
		FileChangedReloadingStrategy reloadingStrategy = new FileChangedReloadingStrategy();
		reloadingStrategy.setRefreshDelay(MINUTES.toMillis(1));
		this.setReloadingStrategy(reloadingStrategy);
	}

	/************************************************************************/

	public <T> T getProperty(String key, T defaultValue) {
		@SuppressWarnings("unchecked")
		T val = (T) getProperty(key);
		return (val == null) ? defaultValue : val;
	}

	/************************************************************************/

}
