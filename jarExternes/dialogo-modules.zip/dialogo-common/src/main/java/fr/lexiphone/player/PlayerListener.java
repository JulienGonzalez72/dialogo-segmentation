/**
 * 
 */
package fr.lexiphone.player;

import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import fr.lexiphone.entreprise.workmodule.PlayerState;


/**
 * This interface defines callbacks methods that will be notified
 * for all registered BasicPlayerListener of BasicPlayer.
 *
 * @author C&eacute;drik LIME
 */
public interface PlayerListener extends PropertyChangeListener/*, Observer*//*, javazoom.jlgui.basicplayer.BasicPlayerListener*//*, fr.lexiphone.player.impl.jasiohost.provider.jlPlayer.IPlayerStateChangedListener*/ {

	/**
	 * Open callback, stream is ready to play.
	 *
	 * @param streamName could be File, URL or InputStream name; can be {@code null}
	 */
	public void opened(String streamName);

	/**
	 * Notification callback for basicplayer events such as opened, eom...
	 * Usually this is a "stateUpdated" method.
	 * 
	 * @param evt this is a {@link PlayerEvent}, really!
	 * @see PlayerState
	 */
	@Override
	public void propertyChange(PropertyChangeEvent evt);

	void recurrenceJump(PlayerEvent evt);

	void seek(PlayerEvent evt);
}
