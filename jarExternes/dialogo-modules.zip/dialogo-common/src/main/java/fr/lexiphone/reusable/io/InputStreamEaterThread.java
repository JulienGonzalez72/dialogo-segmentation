package fr.lexiphone.reusable.io;

import java.io.IOException;
import java.io.InputStream;

/**
 * Thread dont la seule fonction est de manger un InputThread jusqu'� plus soif...
 * Cf. (style UN*X) : cat > /dev/null
 * @author clime
 */
public class InputStreamEaterThread extends Thread implements Runnable {
	private InputStream is;

	/**
	 * 
	 */
	public InputStreamEaterThread(InputStream in_is) {
		super("InputStreamEaterThread");
		is = in_is;
		// Priorit� plus basse que l'appelant
		if (this.getPriority() > Thread.MIN_PRIORITY) {
			this.setPriority(this.getPriority() - 1);
		}
	}


	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		try {
			while (is.read() != -1) {
				yield();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

}
