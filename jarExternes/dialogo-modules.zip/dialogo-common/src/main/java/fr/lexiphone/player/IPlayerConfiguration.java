/**
 * 
 */
package fr.lexiphone.player;

/**
 * @author C&eacute;drik LIME
 */
public interface IPlayerConfiguration {
	/**
	 * @return String
	 */
	public String getSamplesRootPath();

	/**
	 * @return multiplier factor
	 */
	public float getBasicPlayerSetPositionFactor();

	/**
	 * @return constant factor (number of bytes)
	 */
	public int getBasicPlayerSetPositionConstant();

	/**
	 * @return multiplier factor
	 */
	public float getPlayerAutoPauseFactor();

	/**
	 * @return constant factor (millisecondes)
	 */
	public int getPlayerAutoPauseConstant();

	/**
	 * @return the playerSpeedModifier
	 */
	public float getPlayerSpeedModifier();
}
