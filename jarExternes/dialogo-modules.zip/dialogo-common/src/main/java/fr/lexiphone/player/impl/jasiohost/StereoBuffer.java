package fr.lexiphone.player.impl.jasiohost;


public class StereoBuffer{

	private float [] rightChannel = null;
	private float [] leftChannel = null;
	
	public StereoBuffer() {
	}
	
	public StereoBuffer(float [] leftChannel, float [] rightChannel) {
		if(leftChannel.length != rightChannel.length)
			throw new IllegalArgumentException("leftChannel and rightChannel must have the same size!");
		this.leftChannel = leftChannel;
		this.rightChannel = rightChannel;
	}
	
	public float [] getRightChannel() {
		return this.rightChannel;
	}
	
	public float [] getLeftChannel() {
		return this.leftChannel;
	}
	
	public void setRightChannel(float [] rightChannel) {
		if(this.leftChannel.length != rightChannel.length)
			throw new IllegalArgumentException("rightChannel must have the same size than the buffer size");
		this.rightChannel = rightChannel;
	}
	
	public void setLeftChannel(float [] leftChannel) {
		if(this.rightChannel.length != leftChannel.length)
			throw new IllegalArgumentException("leftChannel must have the same size than the buffer size");
		this.leftChannel = leftChannel;
	}
	
	public int getBufferSize() {
		return this.leftChannel.length;
	}
}
