/**
 * 
 */
package fr.lexiphone.player.impl;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.PlayerListener;
import fr.lexiphone.player.impl.jasiohost.provider.ILineControl;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 * This interface defines available player controls.
 * @author C&eacute;drik LIME
 */
// TODO remove dependency to basicplayer?
public interface BasicController extends
		javazoom.jlgui.basicplayer.BasicController, ILineControl {

	/**
	 * @see PropertyChangeSupport#addPropertyChangeListener(PropertyChangeListener)
	 */
	void addPlayerListener(PlayerListener listener);
	/**
	 * @see PropertyChangeSupport#removePropertyChangeListener(PropertyChangeListener)
	 */
	void removePlayerListener(PlayerListener listener);

	PlayerState getState();

	/**
	 * @return total duration in milliseconds
	 */
	long getDuration() throws BasicPlayerException;
	long getPosMilliSeconds() throws BasicPlayerException;
	void setPosMilliSeconds(long milliSeconds) throws BasicPlayerException;
	float getPositionAsPercent() throws BasicPlayerException;
	void setPositionAsPercent(float percent) throws BasicPlayerException;
	/**
	 * @return the current sentence number (beginning by {@code 0}), {@code null} if sample doesn't have a zone marker file
	 */
	Integer getPosSentenceNumber() throws BasicPlayerException;
	/**
	 * Puts the sample at the beginning of sentence number {@code n} (beginning by {@code 0})
	 * @param sentenceNumber the current sentence number (beginning by {@code 0})
	 */
	void setPosSentenceNumber(int n) throws BasicPlayerException;
	/**
	 * @return the total sentences number, {@code null} if sample doesn't have a zone marker file
	 */
	Integer getTotalSentencesNumber() throws BasicPlayerException;

	void recurrenceJump() throws BasicPlayerException;

	/**
	 * Skip time in milliseconds (or +/-1 if in sentence mode).
	 * @param milliseconds
	 * @return milliseconds skipped (or new position in milliseconds if in sentence mode)
	 * @throws BasicPlayerException
	 */
	@Override
	long seek(long milliseconds) throws BasicPlayerException;

    /**
     * Start playback, auto-pause after {@code milliseconds} (or sentences, if in sentence mode).
     * @throws BasicPlayerException
     */
    void play(long milliseconds) throws BasicPlayerException;

    /**
     * Resume playback, auto-pause after {@code milliseconds} (or sentences, if in sentence mode). 
     * @throws BasicPlayerException
     */
    void resume(long milliseconds) throws BasicPlayerException;

    /**
     * Pause or resume playback, depending on player state. 
     * @throws BasicPlayerException
     */
    void playOrResume() throws BasicPlayerException;

    /**
     * Pause or resume playback, depending on player state. 
     * @throws BasicPlayerException
     */
    void playOrResume(long milliseconds) throws BasicPlayerException;
    
    /**
     * Pause or resume playback, depending on player state. 
     * @throws BasicPlayerException
     */
    void pauseOrResume() throws BasicPlayerException;
    
    /**
     * @return [0..1]
     */
    float getOutputVUMeterLevel();
	
	public void open(Mp3Wrapper sample)throws BasicPlayerException;
	//public void open(Mp3Wrapper sample, File intro)throws BasicPlayerException;

	public void reactivateControls();

	public void disactivateControls();

	//public boolean hasFinishedIntro();
}
