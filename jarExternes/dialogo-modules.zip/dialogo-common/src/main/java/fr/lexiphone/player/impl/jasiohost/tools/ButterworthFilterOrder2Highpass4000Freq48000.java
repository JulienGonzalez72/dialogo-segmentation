/**
 * 
 */
package fr.lexiphone.player.impl.jasiohost.tools;

import java.util.Arrays;

/**
 * Butterworth infinite-impulse-response (IIR) filters, with bandpass characteristics, designed by the bilinear transform method.
 * @author C&eacute;drik LIME
 * @see "http://www-users.cs.york.ac.uk/~fisher/mkfilter"
 */
/*
Command line: /www/usr/fisher/helpers/mkfilter -Bu -Hp -o 2 -a 8.3333333333e-02 0.0000000000e+00
raw alpha1    =   0.0833333333
raw alpha2    =   0.0833333333
warped alpha1 =   0.0852908769
warped alpha2 =   0.0852908769
gain at dc    :   mag = 0.000000000e+00
gain at centre:   mag = 1.025823956e+00   phase =   0.5000000000 pi
gain at hf    :   mag = 1.450734152e+00   phase =   0.0000000000 pi

S-plane zeros:
	  0.0000000000 + j   0.0000000000	2 times

S-plane poles:
	 -0.3789373820 + j  -0.3789373820
	 -0.3789373820 + j   0.3789373820

Z-plane zeros:
	  1.0000000000 + j   0.0000000000	2 times

Z-plane poles:
	  0.6398162125 + j  -0.2612038750
	  0.6398162125 + j   0.2612038750

Recurrence relation:
y[n] = (  1 * x[n- 2])
     + ( -2 * x[n- 1])
     + (  1 * x[n- 0])

     + ( -0.4775922501 * y[n- 2])
     + (  1.2796324250 * y[n- 1])
 */
public class ButterworthFilterOrder2Highpass4000Freq48000 {
	public static final String FILTER_TYPE = "Butterworth";
	public static final String PASS_TYPE = "Highpass";
	public static final byte FILTER_ORDER = 2;
	public static final int SAMPLE_RATE = 48000;
	public static final int CORNER_FREQUENCY_1 = 4000;// frequency at which the magnitude of the response is -3 dB
//	public static final int CORNER_FREQUENCY_2 = 2000;// frequency at which the magnitude of the response is -3 dB

	private final int nZeros = 2;
	private final int nPoles = 2;
	private final float gain = 1.450734152e+00f;
	private final float[] xv = new float[nZeros + 1];
	private final float[] yv = new float[nPoles + 1];

	/**
	 * 
	 */
	public ButterworthFilterOrder2Highpass4000Freq48000() {
		Arrays.fill(xv, 0);
		Arrays.fill(yv, 0);
	}

	public float next(float input) {
		xv[0] = xv[1]; xv[1] = xv[2];
		xv[2] = input / gain;
		yv[0] = yv[1]; yv[1] = yv[2];
		yv[2] =   (xv[0] + xv[2]) - 2 * xv[1]
				+ ( -0.4775922501f * yv[0]) + (  1.2796324250f * yv[1]);
		return yv[2];
	}
}
