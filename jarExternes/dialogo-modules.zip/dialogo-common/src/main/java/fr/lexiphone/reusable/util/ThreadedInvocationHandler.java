/**
 * 
 */
package fr.lexiphone.reusable.util;

import java.io.Closeable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import javax.annotation.PreDestroy;

/**
 * Runs calls to a given class instance in a background thread.<br />
 * Optionally allow for transient invocation errors (e.g. when making RMI calls...)<br />
 * 
 * Usage:
 * <pre>
MyServiceInterface myService = ...;
ThreadedInvocationHandler<MyServiceInterface> ih = new ThreadedInvocationHandler<MyServiceInterface>(myService);
myService = ih.makeThreaded(MyServiceInterface.class);
try {
	myService.doStuff();
} finally {
	ih.close(); // very important in order to reclaim underlying Thread ressources!
}
 * </pre>
 *
 * @author C&eacute;drik LIME
 */
public class ThreadedInvocationHandler<T> implements InvocationHandler, Closeable {

	protected final T delegate;
	protected final ExecutorService thread = Executors.newSingleThreadExecutor(); // note: unbounded queue!
	protected boolean outOfOrderGetCalls = false;
	protected int allowUpToNErrors = 0;
	protected long allowUpToTimeErrorsMillis = 0;
	protected Class<Throwable> allowedErrorType = null;

	private long errorsCount = 0;
	private long firstErrorDateMillis = 0;

	public ThreadedInvocationHandler(T delegate) {
		this.delegate = delegate;
	}

	/**
	 * When calling methods with a return value, should we instead run immediately so that we short-circuit the call queue?
	 * This means we accept out-of-order method execution.
	 * Defaults to {@code false}.
	 */
	public void setOutOfOrderGetCalls(boolean outOfOrderGetCalls) {
		this.outOfOrderGetCalls = outOfOrderGetCalls;
	}

	public T getDelegate() {
		return delegate;
	}

	/**
	 * @param allowUpToNErrors the allowUpToNErrors to set
	 */
	public void setAllowUpToNErrors(int allowUpToNErrors) {
		this.allowUpToNErrors = allowUpToNErrors;
	}

	/**
	 * @param allowUpToTimeErrorsMillis the allowUpToTimeErrorsMillis to set
	 */
	public void setAllowUpToTimeErrorsMillis(long allowUpToTimeErrorsMillis) {
		this.allowUpToTimeErrorsMillis = allowUpToTimeErrorsMillis;
	}

	/**
	 * @param allowedErrorType the allowedErrorType to set
	 */
	public void setAllowedErrorType(Class<Throwable> allowedErrorType) {
		this.allowedErrorType = allowedErrorType;
	}

	@SuppressWarnings("unchecked")
	public T makeThreaded(Class<?>... interfaces) {
		return (T) Proxy.newProxyInstance(delegate.getClass().getClassLoader(),
				interfaces,
				this);
	}

	/** {@inheritDoc} */
	@Override
	public Object invoke(Object proxy, final Method method, final Object[] args) throws Throwable {
		if (outOfOrderGetCalls && method.getReturnType() != Void.class) {
			try {
				Object returnValue = method.invoke(delegate, args);
				resetException();
				return returnValue;
			} catch (InvocationTargetException e) {
				handleException(e.getCause());
				return null;
			}
		}

		Future<Object> result = thread.submit(new Callable<Object>() {
			@Override
			public Object call() throws Exception {
				try {
					Object returnValue = method.invoke(delegate, args);
					resetException();
					return returnValue;
				} catch (InvocationTargetException e) {
					try {
						handleException(e.getCause());
						return null;
					} catch (Throwable t) {
						// method signature forbids throwing a Throwable...
						if (t instanceof Exception) {
							throw (Exception) t;
						} else if (t instanceof Error) {
							throw (Error) t;
						} else {
							throw e; // or: should we wrap and throw new Exception(t)?
						}
					}
				}
			}
		});

		if (method.getReturnType() != Void.class) {
			try {
				Object returnValue = result.get(); // note: blocking call here!
				return returnValue;
			} catch (ExecutionException e) {
				handleException(e.getCause());
				return null;
			}
		} else {
			return null;
		}
	}

	protected void resetException() {
		errorsCount = 0;
		firstErrorDateMillis = 0;
	}
	protected void handleException(Throwable cause) throws Throwable {
		if (allowedErrorType != null && allowedErrorType.isInstance(cause)) {
			++errorsCount;
			long now = System.currentTimeMillis();
			if (firstErrorDateMillis == 0) {
				firstErrorDateMillis = now;
			}
			// Handle count-based & time-based permission
			if (errorsCount <= allowUpToNErrors || firstErrorDateMillis + allowUpToTimeErrorsMillis > now) {
				return;
			}
		}
		throw cause;
	}

	/**
	 * Shuts down the created thread.
	 * 
     * <p>Initiates an orderly shutdown in which previously submitted
     * tasks are executed, but no new tasks will be accepted.
     * Invocation has no additional effect if already shut down.
     *
     * <p>This method does not wait for previously submitted tasks to
     * complete execution.
     * to do that.
	 */
	@Override
	@PreDestroy
	public void close() {
		thread.shutdown(); // do not call shutDownNow()!
	}

	/**
	 * Forcibly Shuts down the created thread.<br />
	 * Beware that un-processed calls will not be processed!
	 * 
     * <p>Attempts to stop all actively executing tasks, halts the
     * processing of waiting tasks, and returns a list of the tasks
     * that were awaiting execution.
     *
     * <p>This method does not wait for actively executing tasks to
     * terminate.
     *
     * <p>There are no guarantees beyond best-effort attempts to stop
     * processing actively executing tasks.  For example, typical
     * implementations will cancel via {@link Thread#interrupt}, so any
     * task that fails to respond to interrupts may never terminate.
	 */
	public void closeNow() {
		thread.shutdownNow();
	}
}
