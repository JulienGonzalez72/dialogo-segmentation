/**
 * 
 */
package fr.lexiphone.player;

import java.beans.PropertyChangeEvent;

import fr.lexiphone.entreprise.workmodule.PlayerState;

/**
 * @author C&eacute;drik LIME
 */
public class PlayerEvent extends PropertyChangeEvent /*javazoom.jlgui.basicplayer.BasicPlayerEvent*/ {

	public final long positionMillis;
	public final short sentenceNumber;

	/**
	 * 
	 * @param source    The object on which the Event initially occurred.
	 * @param oldState
	 * @param newState
	 * @param positionMillis  optional stream position when event occured.
	 * @throws IllegalArgumentException  if source is null.
	 */
	public PlayerEvent(Object source, PlayerState oldState, PlayerState newState, short sentenceNumber, long positionMillis) {
		super(source, null, oldState, newState);
		this.sentenceNumber = sentenceNumber;
		this.positionMillis = positionMillis;
	}

	@Override
	public PlayerState getOldValue() {
		return (PlayerState) super.getOldValue();
	}

	@Override
	public PlayerState getNewValue() {
		return (PlayerState) super.getNewValue();
	}
}
