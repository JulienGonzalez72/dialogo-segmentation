package fr.lexiphone.player.impl.jasiohost.bus.distantHP;

import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.UnknownHostException;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;

public class DistantHPBus extends BaseBus implements AutoCloseable {

	public static String ID = "Distant HP";
	
	private InetSocketAddress remote;
	private ObjectOutput oos;
	private Socket socket;
	
	public DistantHPBus() {
		super(ID);
	}
	
	public void connect(InetSocketAddress remote) {
		this.remote = remote;
		initDriver();
	}

	@Override
	public void close() throws IOException {
		if (oos != null) {
			oos.close();
		}
		if (socket != null) {
			socket.close();
		}
	}

	@Override
	public boolean initDriver() {
		if (oos != null || socket != null) {
			throw new IllegalStateException();
		}
		try {
			socket = new Socket(remote.getAddress(), remote.getPort());
			oos = new ObjectOutputStream(socket.getOutputStream());
		} catch (UnknownHostException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return true;
	}

	@Override
	public boolean stopDriver() {
		try {
			oos.close();
			socket.close();
		} catch (IOException e) {
			return false;
		}
		return true;
	}

	@Override
	public void write(StereoBuffer aStereoBuffer) {
		if (oos == null) {
			// nobody connected / listening, nothing to send
			return;
		}
		try {
			oos.writeObject(aStereoBuffer.getLeftChannel());
			oos.writeObject(aStereoBuffer.getRightChannel());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public boolean changeFrameRate(double sampleRate) {return true;}

}