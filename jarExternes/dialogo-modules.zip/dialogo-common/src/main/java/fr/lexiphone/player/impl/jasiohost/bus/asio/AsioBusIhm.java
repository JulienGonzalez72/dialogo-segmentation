package fr.lexiphone.player.impl.jasiohost.bus.asio;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import com.synthbot.jasiohost.AsioChannel;

import fr.lexiphone.player.impl.jasiohost.ihm.ConfigIhm;

@SuppressWarnings("serial")
public class AsioBusIhm extends ConfigIhm {

	private JPanel jPanelDriver = null;
	private JPanel jPanelLeftOutput = null;
	private JPanel jPanelRightOutput = null;
	private JPanel jPanelLeftTHOutput = null;
	private JPanel jPanelRightTHOutput = null;
	private JPanel superPanel = null;
	private JPanel jPanelButton;
	
	private JComboBox<String> jComboDriver = null;
	private JComboBox<String> jComboLeftOutput = null;
	private JComboBox<String> jComboRightOutput = null;
	private JComboBox<String> jComboLeftTHOutput = null;
	private JComboBox<String> jComboRightTHOutput = null;
	
	private JButton jButtonOk;
	
	private Asio asioDriver;
	
	private String [] driversName = {};
	private String [] outputLines = {};
	
	private int oldLeftOutput;
	private int oldRightOutput;
	private int oldLeftTHOutput;
	private int oldRightTHOutput;

	private JButton jButtonControlPanel;

	private JLabel labelSampleRate;

	private JPanel panelSampleRate;

	private JButton jButtonRefresh;


	public AsioBusIhm(Asio asioDriver) {
		super();
		
		//set asio driver
		this.asioDriver = asioDriver;
	}
	
	
	/**
	 * set the list for the comboBox of the left and right output channel
	 * @param outputLines all the output channels of the asioDriver
	 */
	public void getOutputChannelsNames(List<AsioChannel> outputLines) {
		List<String> tempBuff = new ArrayList<String>();
		for(AsioChannel aChannel : outputLines) {
			tempBuff.add(String.valueOf(aChannel.getChannelIndex()) + ' ' + aChannel.getChannelName());
		}
		this.outputLines = tempBuff.toArray(new String [] {});
	}
	
	/**
	 * this method select the correct drivers
	 * 0 for the first drivers
	 * @param driverIndex
	 */
	public void selectDriverName(int driverIndex) {
		getJComboDriver().setSelectedIndex(driverIndex);
	}
	
	/**
	 * this method select the correct channel for the driver
	 * 0 for the first Channel
	 * @param leftChannel 
	 * @param rightChannel
	 */
	public void selectOutputChannels(AsioChannel leftChannel, AsioChannel rightChannel, AsioChannel leftTHChannel, AsioChannel rightTHChannel) {
		int leftIndex = leftChannel != null ? leftChannel.getChannelIndex() : -1;
		int rightIndex = rightChannel != null ? rightChannel.getChannelIndex() : -1;
		getJComboLeftOutput().setSelectedIndex(leftIndex);
		oldLeftOutput = leftIndex;
		getJComboRightOutput().setSelectedIndex(rightIndex);
		oldRightOutput = rightIndex;
		int leftTHIndex = leftTHChannel != null ? leftTHChannel.getChannelIndex() : -1;
		int rightTHIndex = rightTHChannel != null ? rightTHChannel.getChannelIndex() : -1;
		getJComboLeftTHOutput().setSelectedIndex(leftTHIndex);
		oldLeftTHOutput = leftTHIndex;
		getJComboRightTHOutput().setSelectedIndex(rightTHIndex);
		oldRightTHOutput = rightTHIndex;
	}
	
	/**
	 * this method update the frame rate on the panel
	 * @param sampleRate a double that represent the frame rate
	 */
	public void updateFrameRate(double sampleRate) {
		getJLabelSampleRate().setText(Double.toString(sampleRate));
		getJPanelSampleRate().repaint();
	}
	
	/**
	 * this method r�init the selected comboBox
	 * @param outputLines a list of asioChannel that represent the output lines
	 */
	private void reinitOutputLines(List<AsioChannel> outputLines) {
		//save listeners and remove it
		ActionListener [] leftListeners = getJComboLeftOutput().getListeners(ActionListener.class);
		ActionListener [] rightListeners = getJComboRightOutput().getListeners(ActionListener.class);
		ActionListener [] leftTHListeners = getJComboLeftTHOutput().getListeners(ActionListener.class);
		ActionListener [] rightTHListeners = getJComboRightTHOutput().getListeners(ActionListener.class);
		for (ActionListener listener : leftListeners) {
			getJComboLeftOutput().removeActionListener(listener);
		}
		for (ActionListener listener : rightListeners) {
			getJComboRightOutput().removeActionListener(listener);
		}
		for (ActionListener listener : leftTHListeners) {
			getJComboLeftTHOutput().removeActionListener(listener);
		}
		for (ActionListener listener : rightTHListeners) {
			getJComboRightTHOutput().removeActionListener(listener);
		}
		
		getOutputChannelsNames(outputLines);
		DefaultComboBoxModel<String> aModel = new DefaultComboBoxModel<>(this.outputLines);
		getJComboLeftOutput().setModel(aModel);
		getJComboRightOutput().setModel(aModel);
		getJComboLeftTHOutput().setModel(aModel);
		getJComboRightTHOutput().setModel(aModel);
		selectOutputChannels(this.asioDriver.getLeftOutputChannel(), this.asioDriver.getRightOutputChannel(),
				this.asioDriver.getLeftTHOutputChannel(), this.asioDriver.getRightTHOutputChannel());
		
		//restore listeners
		for (ActionListener listener : leftListeners) {
			getJComboLeftOutput().addActionListener(listener);
		}
		for (ActionListener listener : rightListeners) {
			getJComboRightOutput().addActionListener(listener);
		}
		for (ActionListener listener : leftTHListeners) {
			getJComboLeftTHOutput().addActionListener(listener);
		}
		for (ActionListener listener : rightTHListeners) {
			getJComboRightTHOutput().addActionListener(listener);
		}
	}
	
	private JPanel getSuperPanel() {
		if (superPanel == null || !this.superPanel.isDisplayable()) {
			superPanel = new JPanel();
			superPanel.setLayout(new BoxLayout(superPanel, BoxLayout.Y_AXIS));
			superPanel.add(getJPanelDriver());
			superPanel.add(getJPanelLeftOutput());
			superPanel.add(getJPanelRightOutput());
			superPanel.add(getJPanelLeftTHOutput());
			superPanel.add(getJPanelRightTHOutput());
			superPanel.add(getJButtonControlPanel());
			superPanel.add(getJPanelSampleRate());
			superPanel.add(getJPanelSoundLevelBoost());
		}
		return superPanel;
	}
	
	private JPanel getJPanelSampleRate() {
		if (panelSampleRate == null) {
			panelSampleRate = createSection("Sample Rate" , new JPanel());
			panelSampleRate.add(getJLabelSampleRate());
		}
		return panelSampleRate;
	}
	
	private JLabel getJLabelSampleRate() {
		if (labelSampleRate == null) {
			labelSampleRate = new JLabel();
		}
		return labelSampleRate;
	}
	
	private JPanel getJPanelButton() {
		if (jPanelButton == null) {
			jPanelButton = new JPanel(new BorderLayout());
			jPanelButton.add(getJButtonRefresh(), BorderLayout.LINE_START);
			jPanelButton.add(getJButtonOk(), BorderLayout.LINE_END);
		}
		return jPanelButton;
	}
	
	private Component getJButtonRefresh() {
		if (this.jButtonRefresh == null) {
			this.jButtonRefresh = new JButton("Refesh Information");
			this.jButtonRefresh.setAlignmentX(Component.CENTER_ALIGNMENT);
			this.jButtonRefresh.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					superPanel.getParent().removeAll();
					Asio asio = AsioBusIhm.this.asioDriver;
					asio.initializeDriver();
					initAndShowIhm();
					selectOutputChannels(asio.getLeftOutputChannel(), asio.getRightOutputChannel(),
							asio.getLeftTHOutputChannel(), asio.getRightTHOutputChannel());
				}
			});
		}
		return this.jButtonRefresh;
	}

	private JButton getJButtonOk() {
		if (jButtonOk == null) {
			jButtonOk = new JButton("Ok");
			jButtonOk.setAlignmentX(Component.CENTER_ALIGNMENT);
			jButtonOk.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					asioDriver.saveParameters();
					dispose();
				}
			});
		}
		return jButtonOk;
	}

	public void addActionToOkButton(ActionListener anActionListener) {
		getJButtonOk().addActionListener(anActionListener);
	}
	
	private JButton getJButtonControlPanel() {
		if (jButtonControlPanel == null) {
			jButtonControlPanel = new JButton("Open Driver Control Panel");
			jButtonControlPanel.setAlignmentX(Component.CENTER_ALIGNMENT);
			jButtonControlPanel.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					asioDriver.controlPanel();
				}
			});
		}
		return jButtonControlPanel;
	}
	private JPanel getJPanelDriver() {
		if (jPanelDriver == null) {
			jPanelDriver = createSection("Driver" , new JPanel());
			jPanelDriver.add(getJComboDriver());
		}
		return jPanelDriver;
	}
	
	private JComboBox getJComboDriver() {
		if (jComboDriver == null) {
			jComboDriver = new JComboBox(driversName);
			jComboDriver.setSelectedItem(this.asioDriver.getDriverName());
			jComboDriver.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JComboBox driverList = (JComboBox)e.getSource();
					asioDriver.changeDriverName((String)driverList.getSelectedItem());
					if (getJComboLeftOutput() != null) {
						reinitOutputLines(asioDriver.getOutputChannels());
					}
				}
			});
		}
		return jComboDriver;
	}
	
	private JPanel getJPanelLeftOutput() {
		if (jPanelLeftOutput == null) {
			jPanelLeftOutput = createSection("Left Output Line", new JPanel());
			jPanelLeftOutput.add(getJComboLeftOutput());
		}
		return jPanelLeftOutput;
	}
	
	private JPanel getJPanelLeftTHOutput() {
		if (jPanelLeftTHOutput == null) {
			jPanelLeftTHOutput = createSection("Left TH Output Line", new JPanel());
			jPanelLeftTHOutput.add(getJComboLeftTHOutput());
		}
		return jPanelLeftTHOutput;
	}
	
	private JComboBox<String> getJComboLeftOutput() {
		if (this.jComboLeftOutput == null) {
			this.jComboLeftOutput = new JComboBox<>(outputLines);
			this.jComboLeftOutput.setSelectedIndex(this.asioDriver.getLeftOutputChannel() != null ?
					this.asioDriver.getLeftOutputChannel().getChannelIndex() : -1);
			this.oldLeftOutput = this.jComboLeftOutput.getSelectedIndex();
			this.jComboLeftOutput.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JComboBox box = (JComboBox)e.getSource();
					
					int selectedIndex = box.getSelectedIndex();
					
					//if empty box do nothing
					if (box.getItemCount() == 0 || getJComboRightOutput().getItemCount() == 0) {
						return;
					}
					
					if (selectedIndex == oldLeftOutput) {
						return;
					}
					
					//reset position if the left and right are the same
					if (selectedIndex == getJComboRightOutput().getSelectedIndex()) {
						box.setSelectedIndex(oldLeftOutput);
						return;
					}
					//else change line
					if (asioDriver.isRunning()) {
						asioDriver.setLeftOutputChannel(asioDriver.getOutputChannel(box.getSelectedIndex()));
						asioDriver.initializeDriver();
					}
				}
			});
		}
		return this.jComboLeftOutput;
	}
	
	private JComboBox<String> getJComboLeftTHOutput() {
		if (this.jComboLeftTHOutput == null) {
			this.jComboLeftTHOutput = new JComboBox<>(outputLines);
			this.jComboLeftTHOutput.setSelectedIndex(this.asioDriver.getLeftTHOutputChannel() != null ?
					this.asioDriver.getLeftTHOutputChannel().getChannelIndex() : -1);
			this.oldLeftTHOutput = this.jComboLeftTHOutput.getSelectedIndex();
			this.jComboLeftTHOutput.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JComboBox box = (JComboBox)e.getSource();
					
					int selectedIndex = box.getSelectedIndex();
					
					//if empty box do nothing
					if (box.getItemCount() == 0 || getJComboRightTHOutput().getItemCount() == 0) {
						return;
					}
					
					if (selectedIndex == oldLeftTHOutput) {
						return;
					}
					
					//reset position if the left and right are the same
					if (selectedIndex == getJComboRightTHOutput().getSelectedIndex()) {
						box.setSelectedIndex(oldLeftTHOutput);
						return;
					}
					//else change line
					if (asioDriver.isRunning()) {
						asioDriver.setLeftTHOutputChannel(asioDriver.getOutputChannel(box.getSelectedIndex()));
						asioDriver.initializeDriver();
					}
				}
			});
		}
		return this.jComboLeftTHOutput;
	}
	
	private JPanel getJPanelRightOutput() {
		if (this.jPanelRightOutput == null) {
			this.jPanelRightOutput = createSection("Right Output Line", new JPanel());
			this.jPanelRightOutput.add(getJComboRightOutput(), BorderLayout.LINE_START);
		}
		return this.jPanelRightOutput;
	}
	
	private JPanel getJPanelRightTHOutput() {
		if (this.jPanelRightTHOutput == null) {
			this.jPanelRightTHOutput = createSection("Right TH Output Line", new JPanel());
			this.jPanelRightTHOutput.add(getJComboRightTHOutput(), BorderLayout.LINE_START);
		}
		return this.jPanelRightTHOutput;
	}
	
	private JComboBox<String> getJComboRightOutput() {
		if (this.jComboRightOutput == null) {
			this.jComboRightOutput = new JComboBox<>(outputLines);
			this.jComboRightOutput.setSelectedIndex(this.asioDriver.getRightOutputChannel() != null ?
					this.asioDriver.getRightOutputChannel().getChannelIndex() : -1);
			this.oldRightOutput = this.jComboRightOutput.getSelectedIndex();
			this.jComboRightOutput.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JComboBox box = (JComboBox)e.getSource();
					
					int selectedIndex = box.getSelectedIndex();
					
					//if empty box do nothing
					if (box.getItemCount() == 0 || getJComboLeftOutput().getItemCount() == 0) {
						return;
					}
					
					if (selectedIndex == oldRightOutput) {
						return;
					}
					
					//reset position if the left and right are the same
					if (box.getSelectedIndex() == getJComboLeftOutput().getSelectedIndex()) {
						box.setSelectedIndex(oldRightOutput);
						return;
					}
					
					//else change line
					if (asioDriver.isRunning()) {
						asioDriver.setRightOutputChannel(asioDriver.getOutputChannel(box.getSelectedIndex()));
						asioDriver.initializeDriver();
					}
				}
			});
		}
		return jComboRightOutput;
	}
	
	private JComboBox<String> getJComboRightTHOutput() {
		if (this.jComboRightTHOutput == null) {
			this.jComboRightTHOutput = new JComboBox<>(outputLines);
			this.jComboRightTHOutput.setSelectedIndex(this.asioDriver.getRightTHOutputChannel() != null ?
					this.asioDriver.getRightTHOutputChannel().getChannelIndex() : -1);
			this.oldRightTHOutput = this.jComboRightTHOutput.getSelectedIndex();
			this.jComboRightTHOutput.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JComboBox box = (JComboBox)e.getSource();
					
					int selectedIndex = box.getSelectedIndex();
					
					//if empty box do nothing
					if (box.getItemCount() == 0 || getJComboLeftTHOutput().getItemCount() == 0) {
						return;
					}
					
					if (selectedIndex == oldRightTHOutput) {
						return;
					}
					
					//reset position if the left and right are the same
					if (box.getSelectedIndex() == getJComboLeftTHOutput().getSelectedIndex()) {
						box.setSelectedIndex(oldRightTHOutput);
						return;
					}
					
					//else change line
					if (asioDriver.isRunning()) {
						asioDriver.setRightTHOutputChannel(asioDriver.getOutputChannel(box.getSelectedIndex()));
						asioDriver.initializeDriver();
					}
				}
			});
		}
		return jComboRightTHOutput;
	}
	
	@Override
	protected JPanel getJPanelSoundLevelBoost() {
		if (jPanelSoundLevelBoost == null) {
			JPanel panel = createSection("Sound Level Boost", new JPanel());
			panel.add(super.getJPanelSoundLevelBoost());
			this.jPanelSoundLevelBoost = panel;
		}
		return jPanelSoundLevelBoost;
	}

	@Override
	public void initAndShowIhm() {
		//reset
//		this.removeAll();
		if (superPanel != null) {
			this.remove(superPanel);
		}
		if (jPanelButton != null) {
			this.remove(jPanelButton);
		}
		this.jPanelDriver = null;
		this.jPanelLeftOutput = null;
		this.jPanelRightOutput = null;
		this.jPanelLeftTHOutput = null;
		this.jPanelRightTHOutput = null;
		this.superPanel = null;
		this.jPanelButton = null;
		
		this.jComboDriver = null;
		this.jComboLeftOutput = null;
		this.jComboRightOutput = null;
		this.jComboLeftTHOutput = null;
		this.jComboRightTHOutput = null;
		// do not reset jButtonOk as this would invalidate all listeners!
//		this.jButtonOk = null;
		
		this.jButtonControlPanel = null;
		this.labelSampleRate = null;
		this.panelSampleRate = null;
		this.jButtonRefresh = null;
		
		// do not reset jSliderSoundLevelBoost as this would invalidate all listeners!
//		this.jPanelSoundLevelBoost = null;
//		this.jLabelSoundLevelBoost = null;
//		this.jSliderSoundLevelBoost = null;
		
		//init drivers names
		this.driversName = Asio.getDriverNames().toArray(new String [] {});

		//init output lines names
		getOutputChannelsNames(this.asioDriver.getOutputChannels());
		
		//windows stuff
		this.setTitle("Settings for Asio");
		
		this.setLayout(new BorderLayout());
        this.setSize(new Dimension(400, 500));
        this.add(getSuperPanel(), BorderLayout.CENTER);
        this.add(getJPanelButton(), BorderLayout.PAGE_END);
    
		setVisible(true);
	}
	
	/**
	 * this method create jpanel for display lines
	 * @param name a string that is the name of the lines (input, output , ...)
	 * @param lines a jPanel with the lines
	 * @return the integrated jPanel
	 */
	private JPanel createSection(String name, JPanel lines) {
		TitledBorder title = BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), name);
		title.setTitleJustification(TitledBorder.CENTER);
		lines.setBorder(title);
		return lines;
	}
}
 