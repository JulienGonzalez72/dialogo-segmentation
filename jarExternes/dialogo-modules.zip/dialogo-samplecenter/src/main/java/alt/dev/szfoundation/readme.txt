WHAT

	More or less equivalent to java.util.Properties. 

	Uses "plist" serialization format instead of Sun's one:

	http://docs.sun.com/app/docs/doc/802-2112/6i63mn65o?a=view
	http://www.gnustep.org/resources/documentation/Developer/Base/Reference/NSPropertyList.html
	http://developer.apple.com/documentation/Cocoa/Conceptual/PropertyLists/Concepts/OldStylePListsConcept.html

	Notable differences from traditional property list: 

	- UTF-8 encoding
	- Only supports java.util.Collection and java.util.Map
	- Everything else is converted to java.lang.String
	- Mandatory quotation marks around java.lang.String


INSTALLATION

	Install szproperties.jar in your classpath.


DEPENDENCIES

	J2SE
	http://java.sun.com/j2se/

EXAMPLE

	Object	anObject = SZPropertiesReader.readObject( anInputStream );
	
	SZPropertiesWriter.writeObject( anObject, anOutputStream );
	
	// Alternatively
	
	SZProperties	someProperties = new SZProperties();
	
	someProperties.load( anInputStream );
	someProperties.store( anOutputStream );
                
FEEDBACKS

	mailto:zoe_info@mac.com

