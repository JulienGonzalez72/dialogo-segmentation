/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.file;

import helliker.id3.CorruptHeaderException;
import helliker.id3.ID3v2FormatException;
import helliker.id3.MP3File;
import helliker.id3.NoMPEGFramesException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.rmi.server.UID;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.samplecenter.SampleCenter;

/**
 * Wrapper around mp3 extracts
 *
 * @author Herv� Monot
 */
public class Mp3Wrapper implements Serializable {

	private static final Log log = LogFactory.getLog(Mp3Wrapper.class);
	private final File file;
	private MP3File mp3;
	private File maRKerFile;
	private String filtreExercice;
	static boolean logPlainly = false;
	private final String CHARSET = "ISO-8859-15";
	private List<Long> sentencesStartTimes;
	private final File propsFile;
	protected Properties props;
	private int niveauTitre;
	private String titreCorrige;
	public static final String SEGMENTATION_KEY = "Segmentation";
	public static final String LANGUAGE_KEY = "Language";
	public static final String UID_KEY = "UID";
	public static final String NAME_KEY = "Name";
	public static final String LEVEL_KEY = "Level";
	public static final String FORWRITING_KEY = "ForWriting";
	public static final String INSTRUCTIONS_KEY = "Instructions";
	public static final String TYPE_KEY = "Type";
	public static final String MUSIC_TYPE = "Music";
	private Boolean hasFullText;
	private String language;
	private List<Long> sentencesEndTimes;

	public Mp3Wrapper(File file) {
		assert file != null && file.exists();
		this.file = file;
		hasFullText = null;
		try {
			mp3 = new MP3File(file);
		} catch (NoMPEGFramesException | IOException | ID3v2FormatException | CorruptHeaderException ex) {
			log.error("", ex);
			mp3 = null;
		}
		maRKerFile = initMaRKerFile(file);
		if (maRKerFile == null) {
			File file2 = new File(file.getParentFile(), file.getName().replaceAll("T ", "Te "));
			maRKerFile = initMaRKerFile(file2);
		}
		propsFile = new File(getPropertiesAbsPath());
		props = null;
		niveauTitre = 0;
		filtreExercice = null;
		if (!propsFile.exists()) {
			setFieldsFromMetaDataAndTitle();
		} else {
			//checkRepetitionEcriteTypes();
		}
		if (titreCorrige == null) {
			String t = getFileName();
			int i = t.lastIndexOf('.');
			if (i > 0) {
				t = t.substring(0, i);
			}
			titreCorrige = t;
		}
	}

	private void setFieldsFromMetaDataAndTitle() {
		String t = getMp3Title();
		if (t == null || t.trim().isEmpty()) {
			t = getFileName();
			t = t.substring(0, t.length() - 4);
		}
		String[] decomp = SampleCenter.filters().getFiltreNomCorrigeEtNiveau(t);
		filtreExercice = decomp[0];
		if (filtreExercice.startsWith("a")) {
			language = "EN";
			filtreExercice = filtreExercice.substring(1);
		} else {
			language = SampleCenter.config().getLanguage();
		}
		titreCorrige = decomp[1];
		try {
			niveauTitre = Integer.parseInt(decomp[2]);
		} catch (NumberFormatException e) {
			niveauTitre = 0;
		}
	}

	/**
	 * When a string starts with numbers, returns these numbers.
	 *
	 * @param s the string
	 * @return the numbers
	 */
	public String getStartNumbers(String s) {
		if (s == null) {
			return null;
		}
		String numbers = "0123456789";
		String sortie = "";
		for (int i = 0; i < s.length(); i++) {
			if (numbers.contains("" + s.charAt(i))) {
				sortie += s.charAt(i);
			} else {
				return sortie;
			}
		}
		return sortie;
	}

	/**
	 * Tries to load (if file exists) this mp3's properties.
	 *
	 * @return the Properties
	 */
	public Properties getProperties() {
		if (props == null) {
			if (propsFile.exists()) {
				props = new Properties();
				try {
					//log.debug("loading properties");
					//long time = System.currentTimeMillis();
					BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(propsFile), Charset.forName(CHARSET)));
					String l;
					while ((l = br.readLine()) != null) {
						String[] t = l.split("=", 2);
						if (t.length > 1) {
							props.put(t[0], t[1]);
						}
					}
					br.close();
					//log.debug("read in " + (System.currentTimeMillis() - time) + "ms");
				} catch (IOException ex) {
					log.error("", ex);
				}
				if (!props.containsKey(FORWRITING_KEY)) {
					initForWritingProperty();
					saveProperties();
				}
				if (!props.containsKey(INSTRUCTIONS_KEY)) {
					props.setProperty(INSTRUCTIONS_KEY, "1");
					saveProperties();
				}
				if (!props.containsKey(TYPE_KEY)) {
					initTypeProperty();
					saveProperties();
				}
			} else {
				log.debug(" no properties for " + file.getAbsolutePath());//+);
				log.debug(" (" + propsFile.getAbsolutePath() + ")");
			}
		}
		return props;
	}

	protected void initForWritingProperty() {
		if (props != null) {
			props.setProperty(FORWRITING_KEY, filtreExercice != null
				&& (filtreExercice.startsWith("E") || (filtreExercice.startsWith("M") && !filtreExercice.startsWith("MO") && !filtreExercice.startsWith("MP"))
				|| filtreExercice.startsWith("P")) ? "1" : "0");
		}
	}

	/**
	 *
	 * @return the mp3 file
	 */
	public File getFile() {
		return file;
	}

	/**
	 *
	 * @return the MP3File object
	 */
	public MP3File getMp3() {
		return mp3;
	}

	/**
	 *
	 * @return the marker file
	 */
	public File getMaRKerFile() {
		//log.debug("getMaRKerFile : " + maRKerFile);
		return maRKerFile;
	}

	/**
	 * Tries to initialize the marker file from the mp3 file given in parameters
	 *
	 * @param file the mp3 file
	 * @return the marker file, or null
	 */
	public File initMaRKerFile(File file) {
		/*if (! file.exists()) {
			//throw new IllegalArgumentException("Can not read sound file: " + file);
			return null;
		}*/
		// Grab MaRKer data
		File markerFile = new File(file.getAbsolutePath().subSequence(0, file.getPath().lastIndexOf('.')) + ".MRK");
		if (!markerFile.exists() || !markerFile.canRead()) {
			return null;
		} else {
			return markerFile;
		}
	}

	/**
	 * Reads duration in marker file if exists; if not, in mp3's metadata.
	 *
	 * @return duration in seconds
	 */
	public int getDuration() {
		if (maRKerFile != null) {
			//try {
			//int duration = (int) (MP3Utils.getZonesWithPauseManager(this, 1, 0).getTotalDuration(0) / 1000);
			int duration = (int) (getZonesWithPauseManager(1, 0).getTotalDuration(0) / 1000);
			//zonesManager.getEndTime(zones.size() - 1);
			return duration;
			/*} catch (IOException ex) {
				log.error(ex);
			}*/
		}
		return (int) mp3.getPlayingTime();
	}

	/**
	 *
	 * @return TEXTLEVEL table primary key for this mp3
	 */
	public String getMp3NiveauPk() {
		try {
			return mp3.getGenre();
		} catch (ID3v2FormatException ex) {
			return null;
		}
	}

	/**
	 *
	 * @return the file name for this mp3
	 */
	public String getFileName() {
		return file.getName();
	}

	/**
	 *
	 * @return true if this extract has an associated properties file
	 */
	public boolean hasProperties() {
		return propsFile.exists();
	}

	/**
	 *
	 * @return the absolute path of this extract's properties file
	 */
	public String getPropertiesAbsPath() {
		String absName = file.getAbsolutePath();
		return absName.substring(0, absName.length() - 3) + "properties";
	}

	/**
	 *
	 * @return the List containing the sentences' start times
	 */
	public List<Long> getSentencesStartTimes() {
		if (sentencesStartTimes == null) {
			initMarkerTimes();
		}
		return sentencesStartTimes;
	}

	/**
	 *
	 * @return the List containing the sentences' end times
	 */
	public List<Long> getSentencesEndTimes() {
		if (sentencesEndTimes == null) {
			initMarkerTimes();
		}
		return sentencesEndTimes;
	}

	private void initMarkerTimes(){
		sentencesStartTimes = null;
		sentencesEndTimes = null;
		File mrk = getMaRKerFile();
			if (mrk != null) {
				List<Zone> zones = MaRKerFileReader.loadZonesFromMarkerFile(mrk);
				ZonesManager zonesManager = new ZonesManager(zones);
				zonesManager.setSampleRate(getMp3SampleRate());
				if (zones != null) {
					sentencesStartTimes = new ArrayList<>();
					sentencesEndTimes = new ArrayList<>();
					for (int i = 0; i < zones.size(); i++) {
						sentencesStartTimes.add(zonesManager.getStartTime(i));
						sentencesEndTimes.add(zonesManager.getEndTime(i));
					}
				}
			}
	}

	/**
	 *
	 * @return the extract's name, read from the properties
	 */
	public String getNameProperty() {
		Properties p = getProperties();
		if (p == null) {
			return null;
		}
		return p.getProperty(NAME_KEY);
	}

	/**
	 *
	 * @return this mp3's Segmentation, read from the properties
	 */
	public String getSegmentationProperty() {
		Properties p = getProperties();
		if (p == null) {
			return null;
		}
		return p.getProperty(SEGMENTATION_KEY);
	}

	/**
	 * Initializes the ZonesWithPauseManager object if marker file exists
	 *
	 * @param playerAutoPauseFactor
	 * @param playerAutoPauseConstant
	 * @return the ZonesWithPauseManager
	 */
	public ZonesWithPauseManager getZonesWithPauseManager(float playerAutoPauseFactor, int playerAutoPauseConstant) {
		if (getMaRKerFile() == null || !getMaRKerFile().canRead()) {
			return null;
		}
		//try {
		//return MP3Utils.getZonesWithPauseManager(this, playerAutoPauseFactor, playerAutoPauseConstant);
		return initZonesWithPauseManager(playerAutoPauseFactor, playerAutoPauseConstant);
		/*} catch (IOException ex) {
			log.warn(ex);
			return null;
		}*/
	}

	/**
	 *
	 * @return the List of Zones, if a marker file exists; null otherwise
	 */
	public List<Zone> getZones() {
		if (getMaRKerFile() == null) {
			return null;
		}
		return MaRKerFileReader.loadZonesFromMarkerFile(getMaRKerFile());
	}

	/**
	 *
	 * @return this extract's sample rate, read from the metadata
	 */
	public int getMp3SampleRate() {
		return mp3.getSampleRate();
	}

	/**
	 *
	 * @return the name of the extract, read from the metadata
	 */
	public String getMp3Title() {
		try {
			return mp3.getTitle();
		} catch (ID3v2FormatException ex) {
			ex.printStackTrace();
			return null;
		}
	}

	/**
	 *
	 * @return this mp3's Unique Identifier, read from the properties
	 */
	public String getUidProperty() {
		Properties p = getProperties();
		if (p == null) {
			return null;
		}
		return p.getProperty(UID_KEY);
	}

	/**
	 *
	 * @return the language for this mp3, read from the properties
	 */
	public String getLanguageProperty() {
		Properties p = getProperties();
		if (p == null) {
			return null;
		}
		return p.getProperty(LANGUAGE_KEY);
	}

	/**
	 *
	 * @return the TEXTLEVEL's number, read from the properties
	 */
	public int getLevelProperty() {
		Properties p = getProperties();
		if (p == null) {
			return 0;
		}
		String l = p.getProperty(LEVEL_KEY);
		try {
			return Integer.parseInt(l);
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	/**
	 *
	 * @return the name of the extract, read from the properties or from the
	 * metadata
	 */
	public String getName() {
		if (hasProperties()) {
			return getNameProperty();
		}
		String n = getMp3Title();
		if (n != null) {
			return n;
		}
		n = getFileName();
		return n.substring(0, n.length() - 4);
	}

	/**
	 *
	 * @return the TEXTLEVEL, read from the properties or from the metadata
	 */
	public int getLevel() {
		if (hasProperties()) {
			return getLevelProperty();
		}
		return getMp3Niveau();
	}

	/**
	 *
	 * @return the language, read from the properties or from the configuration
	 */
	public String getLanguage() {
		if (hasProperties()) {
			return getLanguageProperty();
		}
		return SampleCenter.config().getLanguage();
	}

	/**
	 *
	 * @return the segmentation, read from the properties or from the title
	 */
	public String getSegmentation() {
		if (hasProperties()) {
			return getSegmentationProperty();
		}
		return SampleCenter.filters().getSegmentationFromFiltre(filtreExercice);
	}

	/**
	 * Creates the Properties object
	 */
	protected void createProperties() {
		setFieldsFromMetaDataAndTitle();
		props = new Properties();
		UID uid = new UID();
		props.setProperty(LANGUAGE_KEY, language);
		props.setProperty(SEGMENTATION_KEY, SampleCenter.filters().getSegmentationFromFiltre(filtreExercice));
		props.setProperty(NAME_KEY, titreCorrige.replaceAll(" +", " ").trim());
		props.setProperty(LEVEL_KEY, "" + getMp3Niveau());
		props.setProperty(UID_KEY, uid.toString());
		props.setProperty(INSTRUCTIONS_KEY, "0");
		initTypeProperty();
		initForWritingProperty();
		log.debug("properties created : " + props);
		saveProperties();
	}

	/**
	 * Saves the properties file
	 *
	 * @return true if the properties are properly saved
	 */
	protected boolean saveProperties() {
		if (props == null) {
			props = new Properties();
		}
		try {
			File f = new File(getPropertiesAbsPath());
			if (!f.exists()) {
				f.createNewFile();
			}
			//p.store(new FileWriter(f), "");
			BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(f), Charset.forName(CHARSET)));
			//RandomAccessFile bw=new RandomAccessFile(f, "rw");
			//bw.seek(0);
			//bw.setLength(0);
			List<String> keys = getPropertiesKeys();
			for (int i = 0; i < keys.size(); i++) {
				String key = keys.get(i);
				bw.write(key + "=" + props.getProperty(key));
				if (i < keys.size() - 1) {
					bw.newLine();
				}
			}
			bw.flush();
			bw.close();
			log.debug("properties saved (bw)");
			return true;
		} catch (IOException ex) {
			log.error("", ex);
			return false;
		}
	}

	/**
	 *
	 * @return the number for this mp3's TEXTLEVEL, read from the mp3 metadata
	 */
	public int getMp3NiveauPkInt() {
		try {
			String s = getMp3NiveauPk();
			if (s == null) {
				return 0;
			}
			//debug(s);
			if (s.startsWith("NIV")) {
				s = s.substring(3);
			}
			//debug(" -> "+s);
			int n = Integer.parseInt(s);
			//debug(" -> "+s);
			return n;
		} catch (NumberFormatException ne) {
			log.error("", ne);
		}
		return 0;
	}

	/**
	 *
	 * @return the number for this mp3's TEXTLEVEL
	 */
	public int getMp3Niveau() {
		int n = getMp3NiveauPkInt();
		if (n > 0) {
			return n;
		}
		return niveauTitre;
	}

	/**
	 * Will create default properties if this mp3 doesn't have his own
	 */
	public void checkProperties() {
		//log.debug("checkProperties : " + (hasProperties() ? "ok" : "creating"));
		if (!hasProperties()) {
			createProperties();
		}
	}

	/**
	 *
	 * @param filename
	 * @return true if a folder with this mp3's name exists in the automatic
	 * texts folder, and contains the file filename.txt
	 */
	public boolean hasText(String filename) {

		String autoTextsRootPath = SampleCenter.config().getAutoTextRootPath();
		boolean hasText = false;
		if (autoTextsRootPath == null) {
			return false;
		}
		String base = getFile().getName();
		File autoTextsRootFolder = new File(autoTextsRootPath);
		File src = new File(autoTextsRootFolder, base);
		//File dest=new File(autoTextsRootFolder,getTitreCorrige()+".mp3");
		if (src.exists()) {
			File full = new File(src, filename + ".txt");
			if (full.exists() && full.canRead()) {
				//log.debug("hasAutomaticText: true "+full.getAbsolutePath());
				hasText = true;
			}//else log.debug("hasAutomaticText: false "+full.getAbsolutePath());
		}//else log.debug("hasAutomaticText: false "+src.getAbsolutePath()+" doesn't exist");
		return hasText;
	}

	public boolean hasFullText() {
		if (hasFullText == null) {
			hasFullText=hasText("full");
		}
		return hasFullText;
	}

	/**
	 *
	 * @param speedModifier
	 * @return the List containing the sentences' start times with this
	 * speedModifier
	 */
	public List<Long> getSentencesStartTimes(float speedModifier) {
		List<Long> times = null;
		ZonesWithPauseManager zonesWithPauseManager = getZonesWithPauseManager(0, 0);//MP3Utils.getZonesWithPauseManager(fSample, 0, 0);
		if (zonesWithPauseManager != null) {
			List<Zone> zones = zonesWithPauseManager.getZones();
			if (zones != null) {
				times = new ArrayList<>();
				for (int i = 0; i < zones.size(); i++) {
					times.add(zonesWithPauseManager.getStartTime(zones.get(i), speedModifier));
				}
			}
		}
		return times;
	}

	/**
	 *
	 * @return the UID of this wrapper
	 */
	public String getUid() {
		return getUidProperty();
	}

	/**
	 * From Properties.java Converts unicodes to encoded &#92;uxxxx and escapes
	 * special characters with a preceding slash
	 */
	private String saveConvert(String theString,
		boolean escapeSpace,
		boolean escapeUnicode) {
		int len = theString.length();
		int bufLen = len * 2;
		if (bufLen < 0) {
			bufLen = Integer.MAX_VALUE;
		}
		StringBuilder outBuffer = new StringBuilder(bufLen);

		for (int x = 0; x < len; x++) {
			char aChar = theString.charAt(x);
			// Handle common case first, selecting largest block that
			// avoids the specials below
			if ((aChar > 61) && (aChar < 127)) {
				if (aChar == '\\') {
					outBuffer.append('\\');
					outBuffer.append('\\');
					continue;
				}
				outBuffer.append(aChar);
				continue;
			}
			switch (aChar) {
				case ' ':
					if (x == 0 || escapeSpace) {
						outBuffer.append('\\');
					}
					outBuffer.append(' ');
					break;
				case '\t':
					outBuffer.append('\\');
					outBuffer.append('t');
					break;
				case '\n':
					outBuffer.append('\\');
					outBuffer.append('n');
					break;
				case '\r':
					outBuffer.append('\\');
					outBuffer.append('r');
					break;
				case '\f':
					outBuffer.append('\\');
					outBuffer.append('f');
					break;
				case '=': // Fall through
				case ':': // Fall through
				case '#': // Fall through
				case '!':
					outBuffer.append('\\');
					outBuffer.append(aChar);
					break;
				default:
					if (((aChar < 0x0020) || (aChar > 0x007e)) & escapeUnicode) {
						outBuffer.append('\\');
						outBuffer.append('u');
						outBuffer.append(toHex((aChar >> 12) & 0xF));
						outBuffer.append(toHex((aChar >> 8) & 0xF));
						outBuffer.append(toHex((aChar >> 4) & 0xF));
						outBuffer.append(toHex(aChar & 0xF));
					} else {
						outBuffer.append(aChar);
					}
			}
		}
		return outBuffer.toString();
	}

	/**
	 * Convert a nibble to a hex character
	 *
	 * @param nibble the nibble to convert.
	 */
	private static char toHex(int nibble) {
		return hexDigit[(nibble & 0xF)];
	}

	/**
	 * A table of hex digits
	 */
	private static final char[] hexDigit = {
		'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'
	};

	/**
	 *
	 * @return the keys used for Properties
	 */
	public static List<String> getPropertiesKeys() {
		return Arrays.asList(UID_KEY, NAME_KEY, SEGMENTATION_KEY, LANGUAGE_KEY, LEVEL_KEY, FORWRITING_KEY, INSTRUCTIONS_KEY, TYPE_KEY);
	}

	/**
	 * Delegates to this wrapper's Properties attribute.
	 *
	 * @param k the key
	 * @return the property, or null if no Properties available
	 */
	public String getProperty(String k) {
		return props == null ? null : props.getProperty(k);
	}

	public String getPropertiesAsStringWithCommas() {
		StringBuilder t = new StringBuilder();
		List<String> l = Mp3Wrapper.getPropertiesKeys();
		for (int i = 0; i < l.size(); i++) {
			String k = l.get(i);
			t.append(k).append('=').append(getProperty(k));
			if (i < l.size() - 1) {
				t.append(", ");
			}
		}
		return t.toString();
	}

	@Override
	public String toString() {
		return "Mp3Wrapper " + (hasProperties()
			? getProperties().toString()
			: file.getAbsolutePath());
	}

	/**
	 * Initializes the ZonesWithPauseManager object
	 *
	 * @param autoPauseFactor
	 * @param autoPauseConstant
	 * @return
	 */
	private ZonesWithPauseManager initZonesWithPauseManager(float autoPauseFactor, int autoPauseConstant) {
		File markerFile = getMaRKerFile();
		if (markerFile == null || !markerFile.canRead()) {
			log.warn("Non-existant MaRKer file: " + markerFile + " for mp3 " + getName());
			return null;
		}
		List<Zone> zones = MaRKerFileReader.loadZonesFromMarkerFile(markerFile);
		if (zones == null || zones.isEmpty()) {
			throw new IllegalArgumentException("Bad MaRKer file: " + markerFile);
		}
		ZonesManager zonesManager = new ZonesManager(zones);
		ZonesWithPauseManager zonesWithPauseManager = new ZonesWithPauseManager(zones, autoPauseFactor, autoPauseConstant);
		int sampleRate = getMp3SampleRate();
		zonesManager.setSampleRate(sampleRate);
		zonesWithPauseManager.setSampleRate(sampleRate);
		//log.trace("sample rate: " + sampleRate);
		/*if (_log.isDebugEnabled()) {
			_log.debug("All zones: " + zonesManager.toString());
		}*/
		//log.trace("" + zones.size() + " zones");
		//log.trace("Duration: " + zonesWithPauseManager.getTotalDuration(0) + " ms");
		return zonesWithPauseManager;
	}

	public boolean isForWriting() {
		String p = getProperty(FORWRITING_KEY);
		return "1".equals(p);
	}

	/*public boolean hasInstructions() {
		String p = getProperty(INSTRUCTIONS_KEY);
		return "1".equals(p);
	}*/
	public boolean hasMarkerFile() {
		return maRKerFile != null && maRKerFile.exists() && maRKerFile.canRead();
	}

	private void initTypeProperty() {
		if (props != null) {
			props.setProperty(TYPE_KEY, filtreExercice != null && filtreExercice.startsWith("MP") ? MUSIC_TYPE : "");
		}
	}

	public boolean isMusic() {
		return MUSIC_TYPE.equals(getTypeProperty());
	}

	public String getTypeProperty() {
		return getProperty(TYPE_KEY);
	}

	public String getInstructionsProperty() {
		return getProperty(INSTRUCTIONS_KEY);
	}

	private void checkRepetitionEcriteTypes() {
		String t = file.getName();
		if (t == null) {
			return;
		}
		if (StringUtils.isNotBlank(getTypeProperty())) {
			return;
		}
		String type = null;
		if (t.startsWith("Ec ")) {
			type = "c";
		} else if (t.startsWith("Ea ")) {
			type = "a";
		} else if (t.startsWith("Em ")) {
			type = "m";
		}
		if (type != null) {
			props.setProperty(TYPE_KEY, type);
			saveProperties();
		}
	}

	@Override
	public boolean equals(Object obj) {
		if(obj==null || !(obj instanceof Mp3Wrapper))return super.equals(obj);
		Mp3Wrapper w = (Mp3Wrapper)obj;
		if(w.getUid()==null||this.getUid()==null)return super.equals(obj);
		return w.getUid().equals(this.getUid());
	}


}
