/**
 * 
 */
package fr.lexiphone.reusable.util;

import java.beans.PropertyChangeListener;
import java.util.List;
import javax.swing.event.SwingPropertyChangeSupport;
import org.apache.commons.collections4.list.AbstractListDecorator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author C&eacute;drik LIME
 */
public class ObservableList<E> extends AbstractListDecorator<E> implements List<E> {
	public static final String ADD    = "ADD";//$NON-NLS-1$
	public static final String REMOVE = "REMOVE";//$NON-NLS-1$
	private static final Log log=LogFactory.getLog(ObservableList.class);

	private final SwingPropertyChangeSupport pcs = new SwingPropertyChangeSupport(this, true);

//	/**
//	 * Constructor only used in deserialization, do not use otherwise.
//	 */
//	public ObservableList() {
//		super();
//	}

	public ObservableList(final List<E> list) {
		super(list);
	}


	public void addPropertyChangeListener(PropertyChangeListener listener) {
		this.pcs.addPropertyChangeListener(listener);
	}
	public void addPropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		this.pcs.addPropertyChangeListener(propertyName, listener);
	}

	public void removePropertyChangeListener(PropertyChangeListener listener) {
		this.pcs.removePropertyChangeListener(listener);
	}
	public void removePropertyChangeListener(String propertyName, PropertyChangeListener listener) {
		this.pcs.removePropertyChangeListener(propertyName, listener);
	}


	@Override
	public boolean add(E element) {
		this.pcs.firePropertyChange(ADD, null, element);
		return super.add(element);
	}
	
	@Override
	public void add(int index, E element) {
		this.pcs.fireIndexedPropertyChange(ADD, index, null, element);
		super.add(index, element);
	}

	@Override
	public boolean remove(Object o) {
		if (contains(o)) {
			log.debug("remove(Object) "+o);
			this.pcs.firePropertyChange(REMOVE, o, null);
		}
		return super.remove(o);
	}
	
	@Override
	public E remove(int index) {
		// E = IENTWorkstationData pour liste patients
		log.debug("remove(IENTWorkstationData) "+index+" "+get(index));
		this.pcs.fireIndexedPropertyChange(REMOVE, index, get(index), null);
		return super.remove(index);
	}

//	@Override
//	public boolean removeAll(Collection<?> coll) {
//		return super.removeAll(coll);
//	}
	
	@Override
	public E set(int index, E element) {
		E oldElement = get(index);
		this.pcs.fireIndexedPropertyChange(REMOVE, index, oldElement, element);
		this.pcs.fireIndexedPropertyChange(ADD, index, oldElement, element);
		return super.set(index, element);
	}

//	@Override
//	public void clear() {
//		super.clear();
//	}
}
