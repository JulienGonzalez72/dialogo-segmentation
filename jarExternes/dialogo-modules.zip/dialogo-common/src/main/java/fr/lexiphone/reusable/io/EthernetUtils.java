package fr.lexiphone.reusable.io;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.Set;

/**
 * @author clime
 */
public final class EthernetUtils {

	private EthernetUtils() {
		super();
		throw new IllegalStateException("Can't instantiate an instance of class " + getClass().getName()); //$NON-NLS-1$
	}

	/**
	 * Attend qu'une interface r�seau autre que localhost soit active
	 */
	public static void waitForActiveNetwork() {
		try {
			Set<InetAddress> allInetAddresss = getAllInetAddresses(true, true);
			boolean found = false;
			do {
				for (InetAddress inetAddress : allInetAddresss) {
					if (! (inetAddress.isLoopbackAddress() || inetAddress.isLinkLocalAddress())) {
						found = true;
						break;
					}
				}
				if (! found) {
					Thread.sleep(1000);
				}
			} while (! found);
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	/**
	 * Attend qu'une interface r�seau soit active
	 * @param in_ifName name of network interface to wait for, e.g. lo, eth0, ppp0
	 * @deprecated wired is not always "eth0"...
	 */
	public static void waitForActiveNetwork(String in_ifName) {
		try {
			while (NetworkInterface.getByName(in_ifName) == null) {
				Thread.sleep(1000);
			}
			while (! NetworkInterface.getByName(in_ifName).getInetAddresses().hasMoreElements()) {
				Thread.sleep(1000);
			}
		} catch (SocketException se) {
			se.printStackTrace();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	/**
	 * Attend qu'une interface r�seau ne soit plus active
	 * @param in_ifName name of network interface to wait for, e.g. ppp0
	 */
	public static void waitForNoNetworkInterface(String in_ifName) {
		try {
			while (NetworkInterface.getByName(in_ifName) != null) {
				Thread.sleep(1000);
			}
		} catch (SocketException se) {
			se.printStackTrace();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	/**
	 * Retourne toutes les adresses locales � cet ordinateur.
	 * @return Set of InetAddress
	 */
	public static Set<InetAddress> getAllInetAddresses() {
		return getAllInetAddresses(false, false);
	}
	/**
	 * Retourne toutes les adresses locales � cet ordinateur.
	 * @return Set of InetAddress
	 */
	public static Set<InetAddress> getAllInetAddresses(boolean filterLoopback, boolean filterLinkLocal) {
		Set<InetAddress> result = new HashSet<InetAddress>();
		try {
			Enumeration lc_enum = NetworkInterface.getNetworkInterfaces();
			while (lc_enum.hasMoreElements()) {
				NetworkInterface lc_if = (NetworkInterface) lc_enum.nextElement();
				Enumeration lc_inetAddrsEnum = lc_if.getInetAddresses();
				while (lc_inetAddrsEnum.hasMoreElements()) {
					InetAddress lc_addr = (InetAddress) lc_inetAddrsEnum.nextElement();
					if (filterLoopback && lc_addr.isLoopbackAddress()) {
						continue;
					}
					if (filterLinkLocal && lc_addr.isLinkLocalAddress()) {
						continue;
					}
					result.add(lc_addr);
				}
			}
		} catch (SocketException se) {
			se.printStackTrace();
		}
		return result;
	}

	public static void main(String[] args) throws Exception {
		System.out.println("Found Network Interfaces:");
		Enumeration lc_enum = NetworkInterface.getNetworkInterfaces();
		while (lc_enum.hasMoreElements()) {
			NetworkInterface lc_if = (NetworkInterface) lc_enum.nextElement();
			System.out.println(lc_if);
			/*
			Enumeration lc_inetAddrsEnum = lc_if.getInetAddresses();
			while (lc_inetAddrsEnum.hasMoreElements()) {
				InetAddress lc_addr = (InetAddress) lc_inetAddrsEnum.nextElement();
				System.out.println("\t" + lc_addr);
			}
			*/
		}
		System.out.println("\nLocal Host: " + InetAddress.getLocalHost());
		System.out.print("\nWaiting for lo: ");
		waitForActiveNetwork("lo");
		System.out.println("ok.");
		System.out.print("\nWaiting for eth0: ");
		waitForActiveNetwork("eth0");
		System.out.println("ok.");
	}
}
