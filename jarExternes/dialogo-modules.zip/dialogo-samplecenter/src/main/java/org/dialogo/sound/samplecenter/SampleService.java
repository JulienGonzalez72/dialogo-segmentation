/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author obicho
 */
public class SampleService implements ISampleService {

	private static final Log log = LogFactory.getLog(SampleService.class);

	public SampleService() {
	}

	@Override
	public void deleteSample(Mp3Wrapper sample) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void renameSample(Mp3Wrapper sample, String newName) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public Map<String, String> checkAllMp3Properties() {
		log.debug("checkAllMp3Properties");
		long t = System.currentTimeMillis();
		Map<String, String> m = new HashMap<>();
		List<Mp3Wrapper> l = SampleCenter.locator().getMp3FilesList(false);
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper s = l.get(i);
			s.checkProperties();
			m.put(s.getMp3Title(), s.getUid());
		}
		long d = System.currentTimeMillis() - t;
		log.debug(l.size() + " properties checked in " + d + " ms.");
		return m;
	}

	/*@Override
	public Map<String,String> getUidsForNames() {
		log.debug("getUidsForNames");
		long t = System.currentTimeMillis();
		List<Mp3Wrapper> l = SampleCenter.locator().getMp3FilesList();
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper s = l.get(i);
			s.checkProperties();
		}
		long d=System.currentTimeMillis()-t;
		log.debug(l.size()+" uids found in "+d+" ms.");
		return m;
	}
	@Override
	public Map<String, String> getMp3PropertiesAsStrings(List<String> mp) {
		Map<String, String> m = new HashMap<>();
		if (mp != null) {
			for (int i = 0; i < mp.size(); i++) {
				String name = mp.get(i);
				Mp3Wrapper w = SampleCenter.locator().findByFileName(name);
				String s=w.getPropsAsString();
				m.put(name,s);
			}
		}
		return m;
	}*/

}
