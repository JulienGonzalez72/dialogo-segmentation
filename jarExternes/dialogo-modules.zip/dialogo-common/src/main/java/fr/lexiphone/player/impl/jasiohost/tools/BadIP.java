package fr.lexiphone.player.impl.jasiohost.tools;

public enum BadIP {
	localhost ("127.0.0.1"),
	empty ("0.0.0.0");
	
	private final String ip;
	
	private BadIP(String ip) {
		this.ip = ip;
	}
	
	String getIp() { return this.ip; }
	
	public static boolean isBad(String ip) {
		for(BadIP anIp : BadIP.values())
			if( anIp.getIp().equals(ip))
				return true;
		return false;
	}
}
