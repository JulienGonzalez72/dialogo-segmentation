package fr.lexiphone.reusable.io;

import java.io.*;
import java.util.Properties;


/**
 * @author clime
 */
public class FileUtils {
	static final int BUFF_SIZE = 49152;

	/**
	 * 
	 */
	private FileUtils() {
		super();
	}

	/**
	 * Copy from <tt>source</tt> to <tt>destination</tt>
	 *
	 * @param source Source file
	 * @param dest Destination file (directory if source is directory)
	 */
	public static void copy(String source, String dest) throws IOException {
		copy(new File(source), new File(dest));
	}

	/**
	 * Copy from <tt>source</tt> to <tt>destination</tt>
	 *
	 * @param source Source file
	 * @param dest Destination file (directory if source is directory)
	 */
	public static void copy(File source, File dest) throws IOException {
		// case: source is a directory
		if (source.isDirectory()) {
			// assume dest is a directory too
			if (! dest.exists()) {
				dest.mkdirs();
			}
			File[] lc_files = source.listFiles();
			for (int i = 0; i < lc_files.length; i++) {
				File lc_file = lc_files[i];
				File lc_fileDest = new File(dest, lc_file.getName());
				copy(lc_file, lc_fileDest);
			}
			// end of processing
			return;
		}

		// case: source is a file
		FileInputStream in = null;
		FileOutputStream out = null;

		try {
			// Create streams
			/*
			in = new BufferedInputStream(new FileInputStream(source), BUFF_SIZE);
			out = new BufferedOutputStream(new FileOutputStream(dest), BUFF_SIZE);
			*/
			in = new FileInputStream(source);
			// One must create intermediate directories first!
			if (dest.getParentFile() != null && ! dest.getParentFile().exists()) {
				dest.getParentFile().mkdirs();
			}
			if (dest.isDirectory()) {
				// Assume we want to copy 'source' file into 'dest' directory
				out = new FileOutputStream(new File(dest, source.getName()));
			} else {
				if(!dest.exists())dest.createNewFile();
				out = new FileOutputStream(dest);
			}

			// copy bytes
			/*
			int data = in.read();
			while (data != -1) {
				out.write(data);
				data = in.read();
			}
			*/
			/*
			while (in.available() != 0) {
				out.write(in.read());
			}
			*/
			final byte[] buffer = new byte[BUFF_SIZE];
			int amountRead = in.read(buffer);
			while (amountRead != -1) {
				out.write(buffer, 0, amountRead);
				amountRead = in.read(buffer);
			}

			out.flush();
		} catch (IOException ioe) {
			throw ioe;
		} finally {
			try {
				if (in != null) {
					in.close();
				}
				if (out != null) {
					out.close();
				}
			} catch (IOException ioe) {
			}
		}
		// JDK 1.4:
		/*
		FileChannel l_in = new FileInputStream( source ).getChannel();
		FileChannel l_out = new FileOutputStream(dest).getChannel();
		try {
			l_in.transferTo(0, l_in.size(), l_out);
		} catch (IOException ioe) {
			ioe.printStackTrace();
		} finally {
			l_in.close();
			l_out.close();
		}
		*/
		// Recopie des attributs
		dest.setLastModified(source.lastModified());
		if (! source.canWrite()) {
			dest.setReadOnly();
		}
	}

	/**
	 * Reads a file and return its content as a String, <em>using plateform default charset</em>.
	 * WARNING: this method is potentially dangerous and can fill up all memory!
	 * @param file File to read
	 * @return String the content of the file
	 * @deprecated use org.apache.commons.io.FileUtils.readFileToString(file, encoding)
	 */
	@Deprecated
	public static String getTextFileContentAsString(File file) {
		try {
			return org.apache.commons.io.FileUtils.readFileToString(file);
		} catch (IOException ioe) {
			return null;
		}
	}

	/**
	 * Get a Properties file
	 * @param file
	 * @return file content as Properties, null if file does not exist
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static Properties getPropertiesFile(File file) {
		Properties props = null;
		if (file.canRead()) {
			props = new Properties();
			try {
				props.load(new FileInputStream(file));
			} catch (IOException ioe) {
				return null;
			}
		}
		return props;
	}
}
