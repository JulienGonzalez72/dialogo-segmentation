/**
 * 
 */
package fr.lexiphone.player.impl;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.PlayerListener;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 * @author C&eacute;drik LIME
 */
public abstract class AbstractDelegatingBasicController<T extends BasicController> implements BasicController {
	protected T delegate;
	protected Mp3Wrapper sample;

	protected AbstractDelegatingBasicController(T delegate) {
		this.delegate = delegate;
	}
	protected AbstractDelegatingBasicController(T delegate,Mp3Wrapper sample) {
		this.delegate = delegate;
		this.sample = sample;
	}
	public Mp3Wrapper getSample(){
		return sample;
	}
	protected T getDelegate() {
		return delegate;
	}
	protected void setDelegate(T delegate) {
		this.delegate = delegate;
	}

	@Override
	public float getLeftLevel() {
		return delegate.getLeftLevel();
	}

	@Override
	public void setLeftLevel(float leftOutput) {
		delegate.setLeftLevel(leftOutput);
	}

	@Override
	public float getRightLevel() {
		return delegate.getRightLevel();
	}

	@Override
	public void setRightLevel(float rightOutput) {
		delegate.setRightLevel(rightOutput);
	}

	@Override
	public float getSoundLevelBoost() {
		return delegate.getSoundLevelBoost();
	}
	
	@Override
	public void setSoundLevelBoost(float soundLevelBoost) {
		delegate.setSoundLevelBoost(soundLevelBoost);
	}

	@Override
	public boolean getMute() {
		return delegate.getMute();
	}

	@Override
	public void setMute(boolean mute) {
		delegate.setMute(mute);
	}

	@Override
	public void addPlayerListener(PlayerListener listener) {
		delegate.addPlayerListener(listener);
	}

	@Override
	public void removePlayerListener(PlayerListener listener) {
		delegate.removePlayerListener(listener);
	}

	@Override
	public PlayerState getState() {
		return delegate.getState();
	}

	@Override
	public long getDuration() throws BasicPlayerException {
		return delegate.getDuration();
	}

	@Override
	public long getPosMilliSeconds() throws BasicPlayerException {
		return delegate.getPosMilliSeconds();
	}

	@Override
	public synchronized void setPosMilliSeconds(long milliSeconds)
			throws BasicPlayerException {
		delegate.setPosMilliSeconds(milliSeconds);
	}

	@Override
	public float getPositionAsPercent() throws BasicPlayerException {
		return delegate.getPositionAsPercent();
	}

	@Override
	public synchronized void open(InputStream in) throws BasicPlayerException {
		delegate.open(in);
	}

	@Override
	public synchronized void setPositionAsPercent(float percent) throws BasicPlayerException {
		delegate.setPositionAsPercent(percent);
	}

	@Override
	public Integer getPosSentenceNumber() throws BasicPlayerException {
		return delegate.getPosSentenceNumber();
	}

	@Override
	public Integer getTotalSentencesNumber() throws BasicPlayerException {
		return delegate.getTotalSentencesNumber();
	}

	@Override
	public synchronized void open(File file) throws BasicPlayerException {
		delegate.open(file);
	}

	@Override
	public void open(Mp3Wrapper sample) throws BasicPlayerException {
		delegate.open(sample);
	}

	/*@Override
	public void open(Mp3Wrapper sample, File intro) throws BasicPlayerException {
		delegate.open(sample, intro);
	}*/

	@Override
	public synchronized void setPosSentenceNumber(int n) throws BasicPlayerException {
		delegate.setPosSentenceNumber(n);
	}

	@Override
	public synchronized void open(URL url) throws BasicPlayerException {
		delegate.open(url);
	}

	@Override
	public synchronized void recurrenceJump() throws BasicPlayerException {
		delegate.recurrenceJump();
	}

	@Override
	public synchronized long seek(long milliseconds) throws BasicPlayerException {
		return delegate.seek(milliseconds);
	}

	@Override
	public synchronized void play() throws BasicPlayerException {
		delegate.play();
	}

	@Override
	public synchronized void stop() throws BasicPlayerException {
		delegate.stop();
	}

	@Override
	public synchronized void play(long milliseconds) throws BasicPlayerException {
		delegate.play(milliseconds);
	}

	@Override
	public synchronized void pause() throws BasicPlayerException {
		delegate.pause();
	}

	@Override
	public synchronized void resume(long milliseconds) throws BasicPlayerException {
		delegate.resume(milliseconds);
	}

	@Override
	public synchronized void resume() throws BasicPlayerException {
		delegate.resume();
	}

	@Override
	public void setPan(double pan) throws BasicPlayerException {
		delegate.setPan(pan);
	}

	@Override
	public synchronized void pauseOrResume() throws BasicPlayerException {
		delegate.pauseOrResume();
	}

	@Override
	public synchronized void playOrResume() throws BasicPlayerException {
		delegate.playOrResume();
	}

	@Override
	public synchronized void playOrResume(long milliseconds) throws BasicPlayerException {
		delegate.playOrResume(milliseconds);
	}

	@Override
	public float getOutputVUMeterLevel() {
		return delegate.getOutputVUMeterLevel();
	}

	@Override
	public void setGain(double gain) throws BasicPlayerException {
		delegate.setGain(gain);
	}

}
