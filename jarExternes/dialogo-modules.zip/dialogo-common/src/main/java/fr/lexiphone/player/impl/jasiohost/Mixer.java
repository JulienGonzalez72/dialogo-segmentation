package fr.lexiphone.player.impl.jasiohost;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ServiceConfigurationError;
import java.util.ServiceLoader;

import javax.swing.JComboBox;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.synthbot.jasiohost.AsioDriver;

import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.bus.BusListener;
import fr.lexiphone.player.impl.jasiohost.bus.LeaderBus;
import fr.lexiphone.player.impl.jasiohost.bus.asio.Asio;
import fr.lexiphone.player.impl.jasiohost.bus.asio.AsioBus;
import fr.lexiphone.player.impl.jasiohost.effect.Effect;
import fr.lexiphone.player.impl.jasiohost.effect.ParametricEffect;
import fr.lexiphone.player.impl.jasiohost.ihm.MixerIhm;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import fr.lexiphone.player.impl.jasiohost.provider.jlPlayer.JlayerPlayer;
import fr.lexiphone.player.impl.jasiohost.provider.microphone.Microphone;
import fr.lexiphone.player.impl.jasiohost.provider.microphone.MicrophoneTH;
import fr.lexiphone.player.impl.jasiohost.tools.LexiTools;
import fr.lexiphone.player.impl.jasiohost.tools.parameters.Parameters;

public class Mixer implements BusListener, AutoCloseable {
	
	private List<BaseProvider> discoveredDevices = null;
	private Map<String, Effect> availableEffects = null;

	protected float oldDevicesRightLevel, devicesRightLevel, oldDevicesLeftLevel, devicesLeftLevel = 1;
	
	//Bus gesture
	private List<BaseBus> allBus = null;
	//one bus to rule them all ;)
	private LeaderBus leaderBus = null; 

	private int bufferSize = 0;
	private MixerIhm aMixerIhm = null;
	
	private static Log log=LogFactory.getLog(Mixer.class);
	
	private static Mixer mixerInstance = null;
	
	private Mixer() {
		this.discoveredDevices = new ArrayList<BaseProvider>();
		this.availableEffects = new HashMap<String, Effect>();
		this.availableEffects.put(ParametricEffect.ID, new ParametricEffect());
		
		loadParameters();
		if (log.isDebugEnabled()) {
			log.debug("ASIO driver names:");
			for (String name : AsioDriver.getDriverNames()) {
				log.debug(name);
			}
		}
		discoverDevices();
//		discoveredDevices.add(new DistantMicrophone("localhost", 6969));//FIXME magic number; find free port instead.
		discoveredDevices.add(new Microphone());
		if (new Asio().validInputLine(3)) { // (0-based); more than 1 sound card; 2 input lines (left / right) per sound card!
			discoveredDevices.add(new MicrophoneTH());
		} else {
			log.info("Not loading TH microphone since there are not enought ASIO input lines!");
		}
		discoveredDevices.add(new JlayerPlayer());
		
		this.allBus = new ArrayList<BaseBus>();
//		this.allBus.add(new JavaSoundBus());
//		this.allBus.add(new DistantHPBus("localhost", 6969));//FIXME magic number; find free port instead.
		this.allBus.add(new AsioBus());
	}
	
	/**
	 * give the uniq instance of the mixer
	 * @return
	 */
	public synchronized static Mixer getInstance(){
		if (mixerInstance == null)
			mixerInstance = new Mixer();
		return mixerInstance;
	}
	
	/**
	 * this method init all bus and their devices
	 */
	public void initDrivers(){
		//TODO : only one leaderBus the first is selected
		//initAllBus
		for(BaseBus aBus : allBus) {
			if(aBus instanceof LeaderBus) {
				leaderBus = (LeaderBus)aBus;
				leaderBus.setBusListener(this);
			}
			//init each devices of each bus
			for(BaseProvider aDevices : aBus.getDevices()) {
				aDevices.init(aBus);
			}
			
			aBus.initDriver();
		}
		
		if (this.leaderBus == null)
			throw new IllegalStateException("Mixer must have a leader bus");
		
		//getbuffersize
		this.bufferSize = leaderBus.getBufferSize();
		
		//open ihm if needed
		if (aMixerIhm == null && Parameters.getInstance().openIhm())
			startIhm();
	}
	
	private void loadParameters() {
	}
	
	/**
	 * to get bus by his ID or name
	 * @param name string that represent bus ID
	 * @return null the bus is not found otherwise the bus
	 */
	public BaseBus getBus(String name){
		for(BaseBus aBus : this.allBus){
			if(aBus.getName().equals(name)) {
				return aBus;
			}
		}
		return null;
	}
	
	/**
	 * to get the available effect
	 * @return an array of Effect Name
	 */
	private String [] getAvailableEffectsNames(){
		List<String> stringArray = new ArrayList<String>();
		for(String key : this.availableEffects.keySet()) {
			stringArray.add(this.availableEffects.get(key).getName());
		}
		String [] output = new String[stringArray.size()];
		return stringArray.toArray(output);
	}
	
	/**
	 * this method start the ihm to configure the mixer
	 */
	public void startIhm(){
		aMixerIhm = new MixerIhm(this);
		
		//link panel on mixing table
		aMixerIhm.addDevicesOnMixer(discoveredDevices);
		
		//link control panel for all bus
		for(BaseBus aBus : allBus)
			aMixerIhm.addBusOnMixer(aBus);
		
		//add gesture for ihm panel
		aMixerIhm.setEffectIhm(getAvailableEffectsNames(), new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox aBox = (JComboBox)e.getSource();
				String effectName = (String)aBox.getSelectedItem();
				if(availableEffects.containsKey(effectName)){
					if (leaderBus.getEffect() != null)
						aMixerIhm.removePanelEffect();
					leaderBus.setEffect(availableEffects.get(effectName));
					aMixerIhm.setPanelEffectIhm(leaderBus.getEffect().getIhm());
				} else if(effectName.equals("none")){
					if (leaderBus.getEffect() != null)
						aMixerIhm.removePanelEffect();
					leaderBus.setEffect((Effect)null);
				}
			}
		});
		
		//select if needed OpenIHM
		if(Parameters.getInstance().openIhm())
			aMixerIhm.selectOpenIhm();
		
		//init
		aMixerIhm.init(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				Parameters.getInstance().save();
				
				//DEBUG
//				stopMixingTable();
//				System.exit(0);
			}
		});
	}
	
	/**
	 * this method stop the mixer
	 */
	@Override
	public void close() {
		//kill all bus correctly
		for(BaseBus aBus : allBus) {
			aBus.stopDriver();
		}
	}
	
	/**
	 * Convenience method to stop the Mixer even if not initialized
	 */
	public static void stopMixingTable() {
		if (mixerInstance != null) {
			mixerInstance.close();
		}
	}
	
	/**
	 * check if a bus is currently in used
	 * @param busID a string that represent the bus ID
	 * @return true if it's an active bus, otherwise false
	 */
	public boolean busIsActive(String busID) {
		for(BaseBus bus : allBus) {
			if (bus.getName().equals(busID))
				return true;
		}
		return false;
	}
	
	/**
	 * test if the parameters is valid
	 * @param aSoundProvider a sound Provider
	 * @param bus a bus
	 */
	private void checkValidParametersForDevice(BaseProvider aSoundProvider, String bus) {
		if (aSoundProvider == null)
			throw new IllegalArgumentException("soundProvider can be null");
		if (!busIsActive(bus))
			throw new IllegalArgumentException("Bus must be initialized in the mixer");
	}
	
	/**
	 * call this method to activate a device for the mix
	 * @param aSoundProvider the SoundProvider to activate
	 */
	public void activateDevice(BaseProvider aSoundProvider, String bus){
		checkValidParametersForDevice(aSoundProvider, bus);
		getBus(bus).addDevice(aSoundProvider);
	}
	
	/**
	 * call this method to deactivate a device for the mix
	 * @param aSoundProvider the SoundProvider to disable
	 */
	public void deactivateDevice(BaseProvider aSoundProvider, String bus){
		checkValidParametersForDevice(aSoundProvider, bus);
		getBus(bus).removeDevice(aSoundProvider);
	}
	
	/**
	 * this method give you all discoveredDevices
	 * @return a list of BaseProvider that represents the devices
	 */
	public List<BaseProvider> getDiscoveredDevices(){
		return new ArrayList<BaseProvider>(discoveredDevices);
	}
	
	/**
	 * return a discovered devices for the given ID
	 * @param id the device ID or name
	 * @return null if the device isn't found otherwise the devices
	 */
	public BaseProvider getDiscoveredDevice(String id){
		for(BaseProvider aProvider : this.discoveredDevices)
			if(aProvider.getName().equals(id))
				return aProvider;
		return null;
	}

	/**
	 * return a discovered effect for the given ID
	 * @param id the effect ID or name
	 * @return null if the effect isn't found
	 */
	public Effect getAvailableEffect(String id) {
		return availableEffects.get(id);
	}
	
	/**
	 * return all the activated devices for a bus
	 * @param bus the id or name of the device
	 * @return the list of devices in BaseProvider type
	 */
	public List<BaseProvider> getActivatedDevices(String bus){
		return new ArrayList<BaseProvider>(getBus(bus).getDevices());
	}
	
	/**
	 * Here we can discover all the devices who can be mixed
	 */
	private void discoverDevices() {
		ServiceLoader<BaseProvider> service = ServiceLoader.load(BaseProvider.class);
		try {
			Iterator<BaseProvider> soundProviders = service.iterator();
			while (soundProviders.hasNext()) {
				this.discoveredDevices.add(soundProviders.next());
			}
		} catch (ServiceConfigurationError serviceError) {
			serviceError.printStackTrace();
		}//*/
	}

	/**
	 * set an effect on a bus
	 * @param name the effect ID for an effect present in the available effects list
	 * @param bus the bus ID
	 */
	public void setEffect(String name, String bus){
		getBus(bus).setEffect(availableEffects.get(name));
	}
	
	/**
	 * set an effect to the desired bus
	 * @param anEffect the effect to add 
	 * @param bus the ID of the bus to add the effect
	 */
	public void setEffect(Effect anEffect, String bus) {
		getBus(bus).setEffect(anEffect);
	}
	
	/**
	 * this method call all provider for refreshing their buffer
	 */
	private void refreshAllNeededDevices() {
		List<BaseProvider> providers = new ArrayList<BaseProvider>();
		for(BaseBus aBus : this.allBus) {
			providers = LexiTools.mergeList(providers, aBus.getDevices());
		}
		for(BaseProvider provider : providers){
			provider.refreshBuffer(this.bufferSize);
		}
	}

	@Override
	public void bufferSwitch() {
		refreshAllNeededDevices();
		for(BaseBus aBus : this.allBus) {
			aBus.write(aBus.mixDevices(this.bufferSize, this.devicesLeftLevel, this.devicesRightLevel));
		}
	}

	@Override
	public void bufferSizeChanged(int newBufferSize) {
		this.bufferSize = newBufferSize;
	}

	/**
	 * % du signal � 0 dans une p�riode
	 * @see fr.lexiphone.player.IEntrepriseSignalProcessingService#setMtvPrc(float)
	 */
	public void setMtvPrc(float mtvPrc) {
		for(BaseBus aBus : this.allBus) {
			aBus.setMtvPrc(mtvPrc);
		}
	}

	/**
	 * p�riode du multivibrateur en millisecondes
	 * @see fr.lexiphone.player.IEntrepriseSignalProcessingService#setMtvPrd(float)
	 */
	public void setMtvPrd(float mtvPrd) {
		if (mtvPrd == 0) {
			mtvPrd = 0.01f;
		}
		for(BaseBus aBus : this.allBus) {
			aBus.setMtvPrd(mtvPrd);
		}
	}

	/**
	 * @return the nonProsodicLeftLevel
	 */
	public float getDevicesLeftLevel() {
		return devicesLeftLevel;
	}
	/**
	 * @param devicesLeftLevel the nonProsodicLeftLevel to set
	 */
	public void setDevicesLeftLevel(float devicesLeftLevel) {
		this.devicesLeftLevel = devicesLeftLevel;
		this.oldDevicesLeftLevel = devicesLeftLevel;
		if (aMixerIhm != null) {
			aMixerIhm.getJSliderDevicesLeft().setValue((int)(devicesLeftLevel * 10));
		}
	}

	/**
	 * @return the nonProsodicRightLevel
	 */
	public double getDevicesRightLevel() {
		return devicesRightLevel;
	}
	/**
	 * @param devicesRightLevel the nonProsodicRightLevel to set
	 */
	public void setDevicesRightLevel(float devicesRightLevel) {
		this.devicesRightLevel = devicesRightLevel;
		this.oldDevicesRightLevel = devicesRightLevel;
		if (aMixerIhm != null) {
			aMixerIhm.getJSliderDevicesRight().setValue((int)(devicesRightLevel * 10));
		}
	}
}
