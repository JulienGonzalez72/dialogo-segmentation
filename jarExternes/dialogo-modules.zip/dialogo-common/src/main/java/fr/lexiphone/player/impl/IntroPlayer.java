/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lexiphone.player.impl;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.PlayerEvent;
import fr.lexiphone.player.PlayerListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import javax.swing.Timer;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author haerwynn
 */
public class IntroPlayer implements BasicController, PlayerListener, Closeable {

	private final BasicController delegate;
	private static final Log log = LogFactory.getLog(IntroPlayer.class);
	//private final Mp3Wrapper sample;
	private boolean played;
	private PlayerState playerState;
	private boolean isPlaying;

	public IntroPlayer(BasicController playerDelegate/*, Mp3Wrapper sample*/) {
		delegate = playerDelegate;
		playerState = null;
		isPlaying = false;
	}

	@Override
	public void addPlayerListener(PlayerListener listener) {
		delegate.addPlayerListener(listener);
	}

	@Override
	public void removePlayerListener(PlayerListener listener) {
		delegate.removePlayerListener(listener);
	}

	@Override
	public PlayerState getState() {
		if (playerState == null) {
			return delegate.getState();
		}
		return playerState;
	}

	@Override
	public long getDuration() throws BasicPlayerException {
		return delegate.getDuration();
	}

	@Override
	public long getPosMilliSeconds() throws BasicPlayerException {
		return delegate.getPosMilliSeconds();
	}

	@Override
	public void setPosMilliSeconds(long milliSeconds) throws BasicPlayerException {
		delegate.setPosMilliSeconds(milliSeconds);
	}

	@Override
	public float getPositionAsPercent() throws BasicPlayerException {
		return delegate.getPositionAsPercent();
	}

	@Override
	public void setPositionAsPercent(float percent) throws BasicPlayerException {
		delegate.setPositionAsPercent(percent);
	}

	@Override
	public Integer getPosSentenceNumber() throws BasicPlayerException {
		return delegate.getPosSentenceNumber();
	}

	@Override
	public void setPosSentenceNumber(int n) throws BasicPlayerException {
		delegate.setPosSentenceNumber(n);
	}

	@Override
	public Integer getTotalSentencesNumber() throws BasicPlayerException {
		return delegate.getTotalSentencesNumber();
	}

	@Override
	public void recurrenceJump() throws BasicPlayerException {
		delegate.recurrenceJump();
	}

	@Override
	public long seek(long milliseconds) throws BasicPlayerException {
		return delegate.seek(milliseconds);
	}

	@Override
	public void play(long milliseconds) throws BasicPlayerException {
		delegate.play(milliseconds);
	}

	@Override
	public void resume(long milliseconds) throws BasicPlayerException {
		delegate.resume(milliseconds);
	}

	@Override
	public void playOrResume() throws BasicPlayerException {
		delegate.playOrResume();
	}

	@Override
	public void playOrResume(long milliseconds) throws BasicPlayerException {
		delegate.playOrResume(milliseconds);;
	}

	@Override
	public void pauseOrResume() throws BasicPlayerException {
		delegate.pauseOrResume();
	}

	@Override
	public void open(Mp3Wrapper sample) throws BasicPlayerException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	/*@Override
	public void open(Mp3Wrapper sample, File intro) throws BasicPlayerException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}*/

	@Override
	public void open(InputStream in) throws BasicPlayerException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void open(File file) throws BasicPlayerException {
		log.debug("open " + file + " delegate=" + delegate.getClass().getSimpleName());
		if (delegate instanceof AutoPauseMarkerFilePlayer) {
			((AutoPauseMarkerFilePlayer) delegate).openDirectly(file);
		} else {
			delegate.open(file);
		}
		delegate.addPlayerListener(this);
	}

	@Override
	public void open(URL url) throws BasicPlayerException {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public void play() throws BasicPlayerException {
		log.debug("play");
		isPlaying = true;
		delegate.play();
	}

	@Override
	public void stop() throws BasicPlayerException {
		log.debug("stop");
		delegate.stop();
	}

	@Override
	public void pause() throws BasicPlayerException {
		log.debug("pause");
		delegate.pause();
	}

	@Override
	public void resume() throws BasicPlayerException {
		log.debug("resume");
		delegate.resume();
	}

	@Override
	public void opened(String streamName) {
		log.debug("opened " + streamName);
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		final PlayerEvent event = (PlayerEvent) evt;
		long pos = 0;
		try {
			boolean stateIsSet = false;
			pos = getPosMilliSeconds();
			final long finalPos=pos;
			log.debug("propertyChange pos=" + pos + " " + event);
			//if (delegate instanceof AutoPauseMarkerFilePlayer) {
			if (pos == 0 && event.getOldValue() == PlayerState.STOPPED && event.getNewValue() == PlayerState.PLAYING) {
				log.debug("pos == 0 && event.getOldValue() == PlayerState.STOPPED && event.getNewValue() == PlayerState.PLAYING");
				setState(PlayerState.INTRO_PLAYING);
				stateIsSet = true;
			} else if (playerState!=null && PlayerState.INTRO_PLAYING==playerState && event.getNewValue() == PlayerState.PAUSED) {
				log.debug("PlayerState.INTRO_PLAYING==playerState && event.getNewValue() == PlayerState.PAUSED");
				//((AutoPauseMarkerFilePlayer) delegate).setState(PlayerState.INTRO_FINISHED);
				//setState(PlayerState.INTRO_FINISHED);
				setState(PlayerState.INTRO_PAUSED);
				stateIsSet = true;
				delegate.removePlayerListener(this);
				final Timer timer=new Timer(2000, new ActionListener() {
					@Override
					public void actionPerformed(ActionEvent e) {
						propertyChange(new PlayerEvent(IntroPlayer.this, event.getOldValue(), playerState, (short)0, finalPos));
					}
				});
				timer.setRepeats(false);
				timer.start();
			}else if(playerState!=null && PlayerState.INTRO_PAUSED==playerState){
				log.debug("PlayerState.INTRO_PAUSED==playerState");
				setState(PlayerState.INTRO_FINISHED);
				stateIsSet = true;
				//delegate.removePlayerListener(this);
			}
			//}
			if (!stateIsSet) {
				setState(event.getNewValue());
			}
		} catch (BasicPlayerException ex) {
			log.error("",ex);
		}

		if (event.getOldValue() == PlayerState.INTRO_PLAYING/*&&event.getNewValue()==PlayerState.STOPPED*/) {
			played = true;
		}
	}

	@Override
	public void recurrenceJump(PlayerEvent evt) {
		try {
			log.debug("recurrenceJump " + evt + " posMilliseconds=" + delegate.getPosMilliSeconds());
		} catch (BasicPlayerException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void seek(PlayerEvent evt) {
		try {
			log.debug("seek " + evt + " posMilliseconds=" + delegate.getPosMilliSeconds());
		} catch (BasicPlayerException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void close() throws IOException {
		try {
			stop();
		} catch (BasicPlayerException ignore) {
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getLeftLevel() {
		return delegate.getLeftLevel();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setLeftLevel(float leftOutput) {
		delegate.setLeftLevel(leftOutput);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getRightLevel() {
		return delegate.getRightLevel();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setRightLevel(float rightOutput) {
		delegate.setRightLevel(rightOutput);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getSoundLevelBoost() {
		return delegate.getSoundLevelBoost();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSoundLevelBoost(float soundLevelBoost) {
		delegate.setSoundLevelBoost(soundLevelBoost);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean getMute() {
		return delegate.getMute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setMute(boolean mute) {
		delegate.setMute(mute);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setGain(double gain) throws BasicPlayerException {
		delegate.setGain(gain);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setPan(double pan) throws BasicPlayerException {
		delegate.setPan(pan);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getOutputVUMeterLevel() {
		return delegate.getOutputVUMeterLevel();
	}

	boolean playAndWait() {
		played = false;
		try {
			play();
		} catch (BasicPlayerException ex) {
			log.error("",ex);
		}
		while (!played) {
			log.debug("playing and waiting state=" + getState());
			try {
				Thread.sleep(200);
			} catch (InterruptedException ex) {
				log.error("",ex);
			}
		}
		return played;
	}

	private void setState(PlayerState playerState) {
		this.playerState = playerState;
		//delegate.sets
	}

	public boolean isPlaying() {
		return isPlaying;
	}

	public void setPlaying(boolean b) {
		isPlaying = b;
	}

	@Override
	public void reactivateControls() {
	}

	@Override
	public void disactivateControls() {
	}

}
