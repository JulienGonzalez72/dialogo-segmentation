/**
 * 
 */
package fr.lexiphone.player.impl.jasiohost;

import java.util.List;

import com.synthbot.jasiohost.AsioChannel;
import com.synthbot.jasiohost.AsioDriver;

/**
 * jAsioHost manager
 * @author C&eacute;drik LIME
 */
public class JAsioHost {//implements AsioDriverListener, Closeable {
//	private static final Log log = LogFactory.getLog(JAsioHost.class);
//	private static JAsioHost INSTANCE;
//
//	private AsioDriver asioDriver;
//	private AsioChannel inputChannel;
//	private AsioChannel outputLeftChannel;
//	private AsioChannel outputRightChannel;
//	private Set<AsioChannel> activeOutputChannels = new HashSet<AsioChannel>();
//	private int bufferSize;
//	private double sampleRate;
//	private MicrophoneProducer player;
//
//	/**
//	 * 
//	 */
//	private JAsioHost() {
//		super();
//		initialize();
//	}
//
//	public static synchronized JAsioHost getInstance() {
//		if (INSTANCE == null) {
//			INSTANCE = new JAsioHost();
//		}
//		return INSTANCE;
//	}
//
//	private void initialize() {
//		EntrepriseLayerConfiguration configuration = EntrepriseLayerConfiguration.getInstance();
//		final int asioDriverPos = configuration.getAsioDriverPos();
//		final int inputChannelPos = configuration.getAsioInputChannelPos();
//		final int outputLeftChannelPos = configuration.getAsioOutputLeftChannelPos();
//		final int outputRightChannelPos = configuration.getAsioOutputRightChannelPos();
//		final boolean showControlPanel = configuration.isAsioShowControlPanel();
//
//		asioDriver = AsioDriver.getDriver(AsioDriver.getDriverNames().get(asioDriverPos).toString());
//		log.info("Driver Name: " + asioDriver.getName());
//		log.info("Driver Version: " + asioDriver.getVersion());
//		log.info("ASIO Version: " + asioDriver.getAsioVersion());
//		asioDriver.addAsioDriverListener(this);
//
//		inputChannel = asioDriver.getChannelInput(inputChannelPos);
//		assert inputChannel.isInput();
//		log.info("Using input channel "+inputChannelPos+":\t"+inputChannel.toString());
//
//		outputLeftChannel = asioDriver.getChannelOutput(outputLeftChannelPos);
//		assert ! outputLeftChannel.isInput();
//		log.info("Using left output channel "+outputLeftChannelPos+":\t"+outputLeftChannel.toString());
//		activeOutputChannels.add(outputLeftChannel);
//		outputRightChannel = asioDriver.getChannelOutput(outputRightChannelPos);
//		assert ! outputRightChannel.isInput();
//		log.info("Using right output channel "+outputRightChannelPos+":\t"+outputRightChannel.toString());
//		activeOutputChannels.add(outputRightChannel);
//
//		bufferSize = asioDriver.getBufferPreferredSize();
//		log.info("Buffer size: " + bufferSize
//			+ " (min: " + asioDriver.getBufferMinSize() + "; max: " + asioDriver.getBufferMaxSize()
//			+ "; granularity: " + asioDriver.getBufferGranularity() + ')');
//		sampleRate = asioDriver.getSampleRate();
//		log.info("Sample rate: " + sampleRate);
//
//		player = new MicrophoneProducer(bufferSize, inputChannel, outputLeftChannel, outputRightChannel);
//
//		Set<AsioChannel> activeChannels = new HashSet<AsioChannel>();
//		activeChannels.add(inputChannel);
//		activeChannels.addAll(activeOutputChannels);
//		asioDriver.createBuffers(activeChannels);
//
//		log.info("Latency input (samples):\t" + asioDriver.getLatencyInput());
//		log.info("Latency output (samples):\t" + asioDriver.getLatencyOutput());
//
//		asioDriver.start();
//		if (showControlPanel) {
//			log.debug("Opening ASIO control panel");
//			asioDriver.openControlPanel();
//		}
//	}
//
//	@Override
//	public void close() {
//		player = null;
//		if (asioDriver != null) {
//			try {
//				asioDriver.stop();
//			} catch (IllegalStateException ignore) {}
//			try {
//				asioDriver.disposeBuffers();
//			} catch (IllegalStateException ignore) {}
//			try {
//				asioDriver.exit();
//			} catch (IllegalStateException ignore) {}
//			asioDriver.shutdownAndUnloadDriver();
//		}
//		inputChannel = null;
//		outputLeftChannel = null;
//		outputRightChannel = null;
//		activeOutputChannels.clear();
//		asioDriver = null;
//	}
//
//	/** {@inheritdoc} */
//	public void bufferSwitch(long systemTime, long samplePosition, Set<AsioChannel> channels) {
//		if (player != null) {
//			player.bufferSwitch(systemTime, samplePosition, channels);
//		}
//	}
//
//	/** {@inheritdoc} */
//	public void bufferSizeChanged(int bufferSize) {
//		log.info("New buffer size: " + bufferSize);
//		if (player != null) {
//			player.setBufferSize(bufferSize);
//		}
//	}
//
//	/** {@inheritdoc} */
//	public void latenciesChanged(int inputLatency, int outputLatency) {
//		log.info("New Latency: Input: " + inputLatency + "; Output: " + outputLatency);
//	}
//
//	/** {@inheritdoc} */
//	public void resetRequest() {
//		log.info("reset");
//		/*
//		 * This thread will attempt to shut down the ASIO driver. However, it will
//		 * block on the AsioDriver object at least until the current method has returned.
//		 */
//		new Thread("ASIO reset") {
//			@Override
//			public void run() {
//				close();
//				asioDriver.returnToState(AsioDriverState.INITIALIZED);
//				initialize();
//			}
//		}
//		.start();
//	}
//
//	/** {@inheritdoc} */
//	public void resyncRequest() {
//		log.debug("resync");
//	}
//
//	/** {@inheritdoc} */
//	public void sampleRateDidChange(double sampleRate) {
//		log.info("New sample rate: " + sampleRate);
//	}

	/**
	 * List all available ASIO drivers
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("======================");
		System.out.println("Available Asio Drivers");
		System.out.print("======================");
		List<String> driverNames = AsioDriver.getDriverNames();
		int driverPos = 0;
		for (String driverName : driverNames) {
			System.out.println();
			System.out.println();
			System.out.println(""+driverPos+": "+driverName);
			AsioDriver asioDriver = AsioDriver.getDriver(driverName);
//			System.out.println("Driver Name: " + asioDriver.getName());
//			System.out.println("Driver Version: " + asioDriver.getVersion());
//			System.out.println("ASIO Version: " + asioDriver.getAsioVersion());
			
			System.out.println();
			System.out.println("Buffer size: " + asioDriver.getBufferPreferredSize()
					+ " (min: " + asioDriver.getBufferMinSize() + "; max: " + asioDriver.getBufferMaxSize()
					+ "; granularity: " + asioDriver.getBufferGranularity() + ')');
			System.out.println("Sample rate: " + asioDriver.getSampleRate());
			
			System.out.println();
			System.out.println("Latency input (samples):\t" + asioDriver.getLatencyInput());
			System.out.println("Latency output (samples):\t" + asioDriver.getLatencyOutput());

			System.out.println();
			System.out.println("Input channels:");
			int numChannelsInput = asioDriver.getNumChannelsInput();
			for (int i = 0; i < numChannelsInput; ++i) {
				AsioChannel channel = asioDriver.getChannelInput(i);
				assert channel.isInput();
				System.out.println(""+i+": "+channel.toString());
			}
			
			System.out.println();
			System.out.println("Output channels:");
			int numChannelsOutput = asioDriver.getNumChannelsOutput();
			for (int i = 0; i < numChannelsOutput; ++i) {
				AsioChannel channel = asioDriver.getChannelOutput(i);
				assert ! channel.isInput();
				System.out.println(""+i+": "+channel.toString());
			}
			
			++driverPos;
		}

	}
}
