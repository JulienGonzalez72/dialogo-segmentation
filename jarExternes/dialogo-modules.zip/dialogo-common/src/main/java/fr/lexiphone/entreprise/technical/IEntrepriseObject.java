
package fr.lexiphone.entreprise.technical;

/**
 * <P>
 *  Interface de marquage des entit�s Entreprise.
 * </P>
 * @author pprimot
 */

public interface IEntrepriseObject {

}
