package fr.lexiphone.player.impl.jasiohost.bus.javaSound;

import java.util.ArrayList;
import java.util.List;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.Line;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.Mixer;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;

import fr.lexiphone.player.impl.jasiohost.tools.parameters.JavaSoundParameterHelper;

public class JavaSound {

	private int bufferSize = 1200;
	
	private JavaSoundBus theBus = null;
	
	private Mixer mixer = null;

	private ArrayList<TargetDataLine> inputChannels = null;
	private ArrayList<SourceDataLine> outputChannels = null;
	
	//the outputChannel used to play sounds
	private SourceDataLine outputChannel = null;
	
	/**
	 * Runnable who get data to write on buffer
	 * @author Ashita
	 */
	private class BufferSwitch implements Runnable{
		@Override
		public void run() {
			while(true) {
				theBus.bufferSwitch();
			}
		}
	}

	public JavaSound(JavaSoundBus aBus){
		//change the bus
		this.theBus = aBus;
		
		//initialisation des variables
		this.inputChannels = new ArrayList<TargetDataLine>();
		this.outputChannels = new ArrayList<SourceDataLine>();
//		this.extraChannel = new HashSet<AsioChannel>();
		
		//print all mixers
		System.out.println("Mixer : ");
		for (String name : getMixersNamesList()) {
			System.out.println(name);
		}
		System.out.println("-----------");
		
		//define the mixer
		if (JavaSoundParameterHelper.hasMixerName()) {
			this.mixer = getMixer(JavaSoundParameterHelper.getMixerName());
		} else {
			this.mixer = getDefaultMixer();
			JavaSoundParameterHelper.setMixerName(this.mixer.getMixerInfo().getName());
		}
		
		System.out.println("Selected Mixer");
		System.out.println(this.mixer.getMixerInfo().getName());
		System.out.println("-----------");
		
		//discover the input and output lines
		discoverLines();
	}
	
	/**
	 * return mixer who have the given name
	 * @param mixerName the mixer name as a String
	 * @return the Mixer
	 */
	private Mixer getMixer(String mixerName) {
		for (Mixer.Info mixer : AudioSystem.getMixerInfo()) {
			if (mixer.getName().equals(mixerName))
				return AudioSystem.getMixer(mixer);
		}
		return getDefaultMixer();
	}
	
	/**
	 * get the first mixer available on this system
	 * @return the first mixer
	 */
	private Mixer getDefaultMixer() {
		Mixer.Info [] mixers = AudioSystem.getMixerInfo();
		if(mixers.length == 0)
			throw new IllegalStateException("No available Mixer on this System");
		return AudioSystem.getMixer(mixers[0]);
	}
	
	/**
	 * give the name of all the mixer present on the system
	 * @return a list of String that represent the name of each mixer
	 */
	private List<String> getMixersNamesList() {
		ArrayList<String> mixerNames = new ArrayList<String>();
		for(Mixer.Info info : AudioSystem.getMixerInfo()) {
			mixerNames.add(info.toString());
		}
		return mixerNames;
	}
	
	/**
	 * discovers the lines for the mixer of this instance
	 */
	private void discoverLines(){
		if (this.mixer == null) {
			return;
		}
		discoverLines(this.mixer);
	}
	
	/**
	 * fill the list of input and output lines for the specified Mixer
	 * @param aMixer the mixer
	 */
	private void discoverLines(Mixer aMixer) {
		System.out.println("output Lines : ");
		for (Line aLine : aMixer.getSourceLines()) {
			this.outputChannels.add((SourceDataLine)aLine);
			System.out.println(aLine);
		}
		System.out.println("---------------");
		System.out.println("input Lines : ");
		for (Line aLine : aMixer.getTargetLines()) {
			this.inputChannels.add((TargetDataLine)aLine);
		}
		System.out.println("---------------");
	}
	
	/**
	 * find the best audio format for the selected output line
	 * @return an AudioFormat which is the best for this line
	 */
	private AudioFormat getBestSupportedAudioFormatForCurrentOutput() {
		return getBestSupportedAudioFormat((DataLine.Info)this.outputChannels.get(0).getLineInfo());
	}
	
	/**
	 * find the best audio format for the given line
	 * @param line the line to analyze
	 * @return an AudioFormat which is the best for the given line
	 */
	private AudioFormat getBestSupportedAudioFormat(DataLine.Info line) {
		AudioFormat bestFormat = null;
		for(AudioFormat supportedFormats : line.getFormats()) {
			System.out.println(supportedFormats);
			if (bestFormat == null) {
				bestFormat = supportedFormats;
				continue;
			}
			if (!supportedFormats.isBigEndian()) {
				bestFormat = supportedFormats;
				continue;
			}
			if (supportedFormats.getFrameRate() > bestFormat.getFrameRate()) {
				bestFormat = supportedFormats;
				continue;
			}
			if (supportedFormats.getSampleRate() > bestFormat.getSampleRate()) {
				bestFormat = supportedFormats;
				continue;
			}
			if (supportedFormats.getChannels() > bestFormat.getChannels()) {
				bestFormat = supportedFormats;
				continue;
			}
			if (supportedFormats.getSampleSizeInBits() > bestFormat.getSampleSizeInBits()) {
				bestFormat = supportedFormats;
				continue;
			}
		}
		System.out.println("best = " +bestFormat);
		System.out.println("----------");
		return bestFormat;
	}
	
	public void init() {
		//get output format
		AudioFormat speakersAudioFormat = new AudioFormat(48000, 16, 2, true, false);//FIXME magic numbers (especially 44100)
		
		//get the input line
		DataLine.Info speakerLineInfo = new DataLine.Info(SourceDataLine.class, speakersAudioFormat);
		AudioFormat bestAudioFormat = getBestSupportedAudioFormat(speakerLineInfo);
		try {
			if (speakersAudioFormat.equals(bestAudioFormat))
				outputChannel = (SourceDataLine) mixer.getLine(speakerLineInfo);
			else 
				outputChannel = (SourceDataLine) mixer.getLine(new DataLine.Info(SourceDataLine.class, bestAudioFormat));
			
			//open the line
			if (! outputChannel.isOpen()) {
				outputChannel.open(speakersAudioFormat);
				this.bufferSize = outputChannel.getBufferSize();
			}
			outputChannel.start();
			
			//start the thread who call do the job
			if (theBus != null) {
				new Thread(new BufferSwitch()).start();
			}
		} catch (LineUnavailableException e) {
			e.printStackTrace();
		}
		
//		JavaSoundParameterHelper.setOutput(outputChannel.))
		
		for (Line aLine : mixer.getSourceLines()) {
			System.out.println(aLine.getLineInfo());
		}
		
	}
	
	/**
	 * give the Source line selected to playing sounds
	 * @return
	 */
	public SourceDataLine getOutputLine() {
		return outputChannel;
	}
	
	/**
	 * clean method to stop the driver
	 */
	public void stopDriver() {
		outputChannel.stop();
		outputChannel.close();
	}
	
	/**
	 * get the buffer Size
	 * @return an integer that represents the size of the buffer in bytes
	 */
	public int getBufferSize() {
		return bufferSize;
	}
	
	/**
	 * Tranform float stream to byte stream in pcm 16bit
	 * @param leftChannel
	 * @param rightChannel
	 * @return
	 */
	public static byte [] sampleToDataLineFormat(float [] leftChannel, float [] rightChannel) {
		if (leftChannel.length != rightChannel.length)
			return null;
		//outputBuffer take 
		byte[] outputByteArray = new byte [leftChannel.length * 4];
		//TODO : can change with another format : here, this is little endian ;)
		for(int i = 0,offset = 0; i < leftChannel.length; ++i, offset += 4){
			int lSample = Math.round(Math.min(1.0F, Math.max(-1.0F, leftChannel[i])) * 32768.0F);
			int rSample = Math.round(Math.min(1.0F, Math.max(-1.0F, rightChannel[i])) * 32768.0F);
			outputByteArray[offset] = (byte) (lSample & 0xFF);
			outputByteArray[offset+1] = (byte) ((lSample >> 8) & 0xFF);
			outputByteArray[offset+2] = (byte) (rSample & 0xFF);
			outputByteArray[offset+3] = (byte) ((rSample >> 8) & 0xFF);
		}
		return outputByteArray;
	}
}
