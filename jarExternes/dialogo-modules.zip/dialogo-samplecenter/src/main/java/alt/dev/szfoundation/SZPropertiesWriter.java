//
//      ===========================================================================
//
//      Title:          SZPropertiesWriter.java
//      Description:    More or less related to OPENSTEP property lists (aka plist):
//
//                      http://docs.sun.com/app/docs/doc/802-2112/6i63mn65o?a=view
//                      http://www.gnustep.org/resources/documentation/Developer/Base/Reference/NSPropertyList.html
//                      http://developer.apple.com/documentation/Cocoa/Conceptual/PropertyLists/Concepts/OldStylePListsConcept.html
//
//                      Notable differences: 
//
//                      - UTF-8 encoding
//                      - Only supports java.util.Collection and java.util.Map
//                      - Everything else is converted to java.lang.String
//                      - Mandatory quotation marks around java.lang.String
//
//      Author:         Rapha�l Szwarc <zoe (underscore) info (at) mac (dot) com>
//      Creation Date:  Thu Dec 09 2004
//      Legal:          Copyright (C) 2004 Rapha�l Szwarc
//
//      This software is provided 'as-is', without any express or implied warranty. 
//      In no event will the author be held liable for any damages arising from 
//      the use of this software.
//
//      Permission is granted to anyone to use this software for any purpose, 
//      including commercial applications, and to alter it and 
//      redistribute it freely, subject to the following restrictions:
//
//      1. The origin of this software must not be misrepresented; 
//      you must not claim that you wrote the original software. 
//      If you use this software in a product, an acknowledgment
//      in the product documentation would be appreciated but is not required.
//
//      2. Altered source versions must be plainly marked as such, 
//      and must not be misrepresented as being the original software.
//
//      3. This notice may not be removed or altered from any source distribution.
//
//      ---------------------------------------------------------------------------
//

package alt.dev.szfoundation;

import java.io.OutputStream;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.IOException;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

public abstract class SZPropertiesWriter extends Object
{

//      ===========================================================================
//      Constant(s)
//      ---------------------------------------------------------------------------

        public static final String                      Encoding = "UTF-8";
        
        private static final char                       Indent = '\t';
        
        private static final Class[]                    Classes = 
                                                        { 
                                                                MapWriter.class,
                                                                CollectionWriter.class,
                                                                StringWriter.class
                                                        };

//      ===========================================================================
//      Class variable(s)
//      ---------------------------------------------------------------------------

        private static final SZPropertiesWriter[]       _writers = new SZPropertiesWriter[ SZPropertiesWriter.Classes.length ];

//      ===========================================================================
//      Instance variable(s)
//      ---------------------------------------------------------------------------

//      ===========================================================================
//      Constructor method(s)
//      ---------------------------------------------------------------------------

        protected SZPropertiesWriter()
        {
                super();
        }

//      ===========================================================================
//      Class method(s)
//      ---------------------------------------------------------------------------

        static 
        {
                Class[] someClasses = SZPropertiesWriter.Classes;
                int     count = someClasses.length;
                
                for ( int index = 0; index < count; index++ )
                {
                        Class   aClass = someClasses[ index ];
                        
                        try
                        {
                                SZPropertiesWriter   aWriter = (SZPropertiesWriter) aClass.newInstance();
                                
                                _writers[ index ] = aWriter;
                        }
                        catch (Exception anException)
                        {
                                throw new RuntimeException( anException.getMessage(), anException );
                        }
                }
        }
        
        private static SZPropertiesWriter[] writers()
        {
                return _writers;
        }

        public static void writeObject(final Object anObject, final OutputStream anOutputStream) throws IOException
        {
                if ( anObject != null )
                {
                        if ( anOutputStream != null )
                        {
                                BufferedWriter  aWriter = new BufferedWriter( new OutputStreamWriter( anOutputStream, SZPropertiesWriter.Encoding ) );
                                int             aLevel = 0;
                                
                                SZPropertiesWriter.writeObject( anObject, aWriter, aLevel );
                                
                                aWriter.flush();
                                aWriter.close();
                        
                                return;
                        }

                        throw new IllegalArgumentException( "SZPropertiesWriter.writeObject: null output stream" );
                }
                
                throw new IllegalArgumentException( "SZPropertiesWriter.writeObject: null object" );
        }
        
        protected static void writeObject(final Object anObject, final BufferedWriter aWriter, int aLevel) throws IOException
        {
                if ( anObject != null )
                {
                        if ( aWriter != null )
                        {
                                SZPropertiesWriter[]    someWriters = SZPropertiesWriter.writers();
                                int                     count = someWriters.length;
                                
                                for ( int index = 0; index < count; index++ )
                                {
                                        SZPropertiesWriter      aPropertiesWriter = someWriters[ index ];
                                        
                                        if ( aPropertiesWriter.canHandleObject( anObject ) == true )
                                        {
                                                aPropertiesWriter.write( anObject, aWriter, aLevel );
                                                
                                                break;
                                        }
                                }
                                
                                return;
                        }

                        throw new IllegalArgumentException( "SZPropertiesWriter.writeObject: null writer" );
                }
        }

//      ===========================================================================
//      Instance method(s)
//      ---------------------------------------------------------------------------

        protected abstract Class type();

        protected boolean canHandleObject(final Object anObject)
        {
                if ( anObject != null )
                {
                        Class   aType = this.type();
                        
                        if ( aType.isAssignableFrom( anObject.getClass() ) == true )
                        {
                                return true;
                        }
                }
                
                return false;
        }
        
        protected void indent(final BufferedWriter aWriter, final int aLevel) throws IOException
        {
                for ( int index = 0; index < aLevel; index++ )
                {
                        aWriter.write( SZPropertiesWriter.Indent );
                }
        }

        protected abstract void write(final Object anObject, final BufferedWriter aWriter, int aLevel) throws IOException;

//      ===========================================================================
//      MapWriter method(s)
//      ---------------------------------------------------------------------------

        private static final class MapWriter extends SZPropertiesWriter
        {
        
                private static final Class      Type = Map.class;
                private static final String     Open = "{";
                private static final String     Close = "}";
                private static final String     Separator = " = ";
                private static final String     End = ";";
        
                protected MapWriter()
                {
                        super();
                }
                
                protected Class type()
                {
                        return MapWriter.Type;
                }
                
                protected void write(final Object anObject, final BufferedWriter aWriter, int aLevel) throws IOException
                {
                        Map     aMap = (Map) anObject;
                        
                        if ( aMap.isEmpty() == false )
                        {
                                if ( aLevel > 0 )
                                {
                                        aWriter.newLine();
                                        this.indent( aWriter, aLevel );
                                }
                                
                                aWriter.write( MapWriter.Open );
                        
                                for ( Iterator anIterator = aMap.keySet().iterator(); anIterator.hasNext(); )
                                {
                                        Object  aKey = anIterator.next();
                                        
                                        if ( aKey != null )
                                        {
                                                Object  aValue = aMap.get( aKey );
                                                
                                                if ( aValue != null )
                                                {
                                                        aWriter.newLine();
                                                        this.indent( aWriter, aLevel + 1 );
                                                        
                                                        SZPropertiesWriter.writeObject( aKey, aWriter, aLevel + 1 );
                                                        aWriter.write( MapWriter.Separator );
                                                        
                                                        SZPropertiesWriter.writeObject( aValue, aWriter, aLevel + 1 );
                                                        aWriter.write( MapWriter.End );
                                                }
                                        }
                                }

                                aWriter.newLine();
                                this.indent( aWriter, aLevel );
                                aWriter.write( MapWriter.Close );
                        }
                        else
                        {
                                aWriter.write( MapWriter.Open );
                                aWriter.write( MapWriter.Close );
                        }

                }
                
        }

//      ===========================================================================
//      CollectionWriter method(s)
//      ---------------------------------------------------------------------------

        private static final class CollectionWriter extends SZPropertiesWriter
        {
        
                private static final Class      Type = Collection.class;
                private static final String     Open = "(";
                private static final String     Close = ")";
                private static final String     Separator = ",";
        
                protected CollectionWriter()
                {
                        super();
                }

                protected Class type()
                {
                        return CollectionWriter.Type;
                }
                
                protected Collection values(final Collection aCollection)
                {
                        if ( aCollection.contains( null ) == true )
                        {
                                Collection      someValues = new ArrayList( aCollection.size() );

                                for ( Iterator anIterator = aCollection.iterator(); anIterator.hasNext(); )
                                {
                                        Object  aValue = anIterator.next();

                                        if ( aValue != null )
                                        {
                                                someValues.add( aValue );
                                        }
                                }
                                
                                return someValues;
                        }
                        
                        return aCollection;
                }

                protected void write(final Object anObject, final BufferedWriter aWriter, int aLevel) throws IOException
                {
                        Collection      aCollection = (Collection) anObject;
                        
                        aCollection = this.values( aCollection );

                        if ( aCollection.isEmpty() == false )
                        {
                                if ( aLevel > 0 )
                                {
                                        aWriter.newLine();
                                        this.indent( aWriter, aLevel );
                                }
                                
                                aWriter.write( CollectionWriter.Open );
                        
                                for ( Iterator anIterator = aCollection.iterator(); anIterator.hasNext(); )
                                {
                                        Object  aValue = anIterator.next();
                                        
                                        aWriter.newLine();
                                        this.indent( aWriter, aLevel + 1 );
                                        
                                        SZPropertiesWriter.writeObject( aValue, aWriter, aLevel + 1 );
                                        
                                        if ( anIterator.hasNext() == true )
                                        {
                                                aWriter.write( CollectionWriter.Separator );
                                        }
                                }

                                aWriter.newLine();
                                this.indent( aWriter, aLevel );
                                aWriter.write( CollectionWriter.Close );
                        }
                        else
                        {
                                aWriter.write( CollectionWriter.Open );
                                aWriter.write( CollectionWriter.Close );
                        }

                }
                
        }
//      ===========================================================================
//      StringWriter method(s)
//      ---------------------------------------------------------------------------

        private static final class StringWriter extends SZPropertiesWriter
        {
        
                private static final char       Open = '\"';
                private static final char       Close = '\"';
                
                private static final char[]     EscapeChars = { '\n', '\r', '\t', '"', '\\', '\f', '\b', '\007', '\013' };
                private static final String[]   EscapeValues = { "\\n", "\\r", "\\t", "\\\"", "\\\\", "\\f", "\\b", "\\a", "\\v" };
                private static final Map        EscapeMap = new HashMap( EscapeChars.length );
        
                protected StringWriter()
                {
                        super();
                }
                
                static
                {
                        int     count = StringWriter.EscapeChars.length;
                        
                        for ( int index = 0; index < count; index++ )
                        {
                                char            aChar = StringWriter.EscapeChars[ index ];
                                Character       aCharacter = new Character( aChar );
                                String          aValue = StringWriter.EscapeValues[ index ];
                                
                                StringWriter.EscapeMap.put( aCharacter, aValue );
                        }
                
                        Arrays.sort( StringWriter.EscapeChars );
                }
                
                protected Class type()
                {
                        return null;
                }

                protected boolean canHandleObject(final Object anObject)
                {
                        if ( anObject != null )
                        {
                                return true;
                        }
                        
                        return false;
                }

                private String escapeValueForChar(final char aChar)
                {
                        int     anIndex = Arrays.binarySearch( StringWriter.EscapeChars, aChar );
                        
                        if ( anIndex >= 0 )
                        {
                                Character       aCharacter = new Character( aChar );
                                String          aValue = (String) StringWriter.EscapeMap.get( aCharacter );
                                
                                return aValue;
                        }
                
                        return null;
                }

                protected void write(final Object anObject, final BufferedWriter aWriter, int aLevel) throws IOException
                {
                        String  aString = anObject.toString();
                        
                        if ( aString != null )
                        {
                                char[]  someChars = aString.toCharArray();
                                int     count = someChars.length;

                                aWriter.write( StringWriter.Open );
                                
                                for ( int index = 0; index < count; index++ )
                                {
                                        char    aChar = someChars[ index ];
                                        String  anEscapeValue = this.escapeValueForChar( aChar );
                                        
                                        if ( anEscapeValue != null )
                                        {
                                                aWriter.write( anEscapeValue );
                                        }
                                        else
                                        {
                                                aWriter.write( aChar );
                                        }
                                }
                                
                                aWriter.write( StringWriter.Close );
                        }
                }
                
        }

}
