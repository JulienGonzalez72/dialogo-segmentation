package fr.lexiphone.player.impl.jasiohost.effect;

import javax.swing.JPanel;

import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;

public interface Effect {

	public float [] soundModification(float inLeft, float inRight);
	public String getName();
	public JPanel getIhm();
	public void setBus(BaseBus aBus);
	
}
