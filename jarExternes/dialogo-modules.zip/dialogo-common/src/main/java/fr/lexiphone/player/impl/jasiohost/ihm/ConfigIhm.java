package fr.lexiphone.player.impl.jasiohost.ihm;

import java.awt.BorderLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

@SuppressWarnings("serial")
public abstract class ConfigIhm extends JFrame {

	protected JPanel jPanelSoundLevelBoost = null; 
	protected JLabel jLabelSoundLevelBoost = null;
	protected JSlider jSliderSoundLevelBoost = null;

	public abstract void initAndShowIhm();

	/**
	 * This method initializes jPanelSoundVolumeBoost	
	 * 	
	 * @return javax.swing.JPanel
	 */
	protected JPanel getJPanelSoundLevelBoost() {
		if (jPanelSoundLevelBoost == null) {
			jPanelSoundLevelBoost = new JPanel();
			jPanelSoundLevelBoost.setLayout(new BorderLayout());
			JLabel jLabel = new JLabel();
			jLabel.setText("Volume boost : ");
			jPanelSoundLevelBoost.add(jLabel, BorderLayout.WEST);
			jPanelSoundLevelBoost.add(getJLabelSoundLevelBoost(), BorderLayout.CENTER);
			jPanelSoundLevelBoost.add(getJSliderSoundLevelBoost(), BorderLayout.EAST);
		}
		return jPanelSoundLevelBoost;
	}
	
	protected JSlider getJSliderSoundLevelBoost() {
		if(jSliderSoundLevelBoost  == null) {
			jSliderSoundLevelBoost = new JSlider(SwingConstants.HORIZONTAL);
			jSliderSoundLevelBoost.setMinimum(1);
			jSliderSoundLevelBoost.setMaximum(96);
			jSliderSoundLevelBoost.setValue(1);
			jSliderSoundLevelBoost.setMajorTickSpacing(16);
			jSliderSoundLevelBoost.setPaintTicks(true);
			jSliderSoundLevelBoost.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					SwingUtilities.invokeLater(new Runnable() {
						@Override
						public void run() {
							getJLabelSoundLevelBoost().setText(Integer.toString(jSliderSoundLevelBoost.getValue()));
						}
					});
				}
			});
		}
		return jSliderSoundLevelBoost;
	}
	
	protected JLabel getJLabelSoundLevelBoost() {
		if (jLabelSoundLevelBoost == null) {
			jLabelSoundLevelBoost = new JLabel("1");
		}
		return jLabelSoundLevelBoost;
	}
	
	public float getSoundLevelBoost() {
		return getJSliderSoundLevelBoost().getValue();
	}
	
	public void setSoundLevelBoost(double aValue) {
		getJSliderSoundLevelBoost().setValue((int)aValue);
	}

	public void addSoundLevelBoostChangeListener(ChangeListener changeListener) {
		getJSliderSoundLevelBoost().addChangeListener(changeListener);
	}
}
