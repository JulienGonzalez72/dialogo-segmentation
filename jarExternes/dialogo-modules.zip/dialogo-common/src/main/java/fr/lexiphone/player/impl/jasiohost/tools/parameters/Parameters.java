package fr.lexiphone.player.impl.jasiohost.tools.parameters;

import fr.lexiphone.configuration.DLGConfiguration;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

// FIXME use commons-configuration to manage persistance (less code for us)
@SuppressWarnings("serial")
public class Parameters{

	private final static String MIXER_IHM = "mixer.ihm";
	private final static String MIXER_EFFECT = "mixer.effect";
	private final static String MIXER_PROVIDER_PREFIX = "mixer.provider.";
	
	private static Parameters INSTANCE = null;
	private static DLGConfiguration config = null;
	private static final Log log=LogFactory.getLog(Parameters.class);
	
	private Parameters() {
		super();
		reload();
	}
	
	public void save() {
		log.info("saving mixer parameters...");
		try {
			config.save();
			log.info("saved in "+config.getFile().getAbsolutePath());
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void reload() {
		log.info("(re)loading mixer parameters...");
		try {
			config.refresh();
			log.info(config.getFile().getAbsolutePath()+" loaded.");
		} catch (ConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void setFile(DLGConfiguration propertiesFile) {
		/*if(!propertiesFile.exists()) {
			try {
				propertiesFile.createNewFile();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
		config = propertiesFile;
	}
	
	public static synchronized Parameters getInstance() {
		if (config == null) {
			//Parameters.setFile(new File("params.properties"));
			throw new NullPointerException();
		}
		if (INSTANCE == null) {
			INSTANCE = new Parameters();
		}
		return INSTANCE;
	}

	
	/**
	 *helpers to access data stored in properties 
	 */
	public boolean openIhm() {
		return config.getBoolean(MIXER_IHM, true);
	}
	
	public void openIhm(boolean bool) {
		config.setProperty(MIXER_IHM, bool);
	}
	
	public void activeEffect() {
		config.setProperty(MIXER_EFFECT, true);
	}
	
	public void deactiveEffec() {
		config.setProperty(MIXER_EFFECT, false);
	}
	
	public boolean getEffect() {
		return config.getBoolean(MIXER_EFFECT, false);
	}
	
	/**
	 * add all the parameters of the bus given in the map to the global parameters
	 * @param aBus the bus
	 * @param properties the map which contains the parameters to add
	 */
	public void setBusParameters(BaseBus aBus, Map<String, String> properties) {
		//Map<String, String> aMap = new HashMap<>();
		Objects.requireNonNull(aBus, "bus can't be null");
		Objects.requireNonNull(properties, "properties can't be null");
		for (String key : properties.keySet()) {
			config.setProperty(concatProviderKey(aBus.getName(), key), properties.get(key));
		}
		//config.putAll(aMap);
	}
	
	/**
	 * get the parameters for a bus
	 * @param aBus the bus
	 * @return a map which contains all the params saved by the provider
	 */
	public Map<String, String> getBusParameters(BaseBus aBus) {
		Objects.requireNonNull(aBus, "bus can't be null");
		Map<String, String> aMap = new HashMap<>();
		String providerPrefix = concatProviderKey(aBus.getName(), "");
		log.debug("getBusParameters("+aBus.getName()+") provider prefix->"+providerPrefix);
		log.debug("getBusParameters("+aBus.getName()+") keys->"+getKeys());
		/*
		Iterator<String> keys = config.getKeys(providerPrefix);
		while(keys.hasNext()) {
		String key=keys.next();
		aMap.put(getProviderKey(key, aBus.getName()), config.getString(key));//map vide alors qu'il y a des keys correspondantes?
		}
		 */
		List<String> keys = getKeys();
		for(String key:keys){
			if(key.startsWith(providerPrefix)){
				log.debug(" adding "+key);
				aMap.put(getProviderKey(key, aBus.getName()), config.getString(key));
			}else{
				log.debug(" ignoring "+key);
			}
		}

		log.debug("getBusParameters("+aBus.getName()+")->"+aMap);
		return aMap;
	}
	
	/**
	 * add all the parameters of the providers given in the map to the global parameters
	 * @param aProvider the provider
	 * @param properties the map which contains the parameters to add
	 */
	public void setProviderParameters(BaseProvider aProvider, Map<String, String> properties) {
		//Map<String, String> aMap = new HashMap<String, String>();
		Objects.requireNonNull(aProvider, "provider name can't be null");
		Objects.requireNonNull(properties, "properties can't be null");
		for (String key : properties.keySet()) {
			config.setProperty(concatProviderKey(aProvider.getName(), key), properties.get(key));
		}
		//this.putAll(aMap);
	}
	
	/**
	 * get the parameters for a provider
	 * @param aProvider the provider
	 * @return a map which contains all the params saved by the provider
	 */
	public Map<String, String> getProviderParameters(BaseProvider aProvider) {
		if(aProvider == null) {
			throw new IllegalArgumentException("provider name can't be null");
		}
		Map<String, String> aMap = new HashMap<>();
		String providerPrefix = concatProviderKey(aProvider.getName(), "");
		/*
		Iterator<String> keys = config.getKeys(providerPrefix);
		while(keys.hasNext()) {
			String key = keys.next();
			aMap.put(getProviderKey(key, aProvider.getName()), config.getString(key));
		}
		*/
		List<String> keys = getKeys();
		for(String key:keys){
			if(key.startsWith(providerPrefix)){
				log.debug(" adding "+key);
				aMap.put(getProviderKey(key, aProvider.getName()), config.getString(key));
			}else{
				log.debug(" ignoring "+key);
			}
		}

		return aMap;
	}
	
	/**
	 * concat the provider key with the constants key for provider and the provider name
	 * @param providerName the provider name
	 * @param key the key to concatenate
	 * @return a String which is the concatenated key
	 */
	private String concatProviderKey(String providerName, String key) {
		return MIXER_PROVIDER_PREFIX.concat(providerName + '.').concat(key);
	}
	
	/**
	 * retrieve key without any useless information
	 * @param concatenedKey the complete key
	 * @param providerName the provider name
	 * @return a String which is a cleaned key
	 */
	private String getProviderKey(String concatenedKey, String providerName) {
		assert concatenedKey.startsWith(concatProviderKey(providerName, "")) : "Not a " + providerName + " key: " + concatenedKey;
		return concatenedKey.substring(providerName.length() + MIXER_PROVIDER_PREFIX.length() + 1);
	}

	public void setProperty(String key, String value) {
		config.setProperty(key, value);
	}

	public String getProperty(String key) {
		return config.getString(key);
	}

	public boolean containsKey(String key) {
		return config.containsKey(key);
	}

	public String getProperty(String key, String defaultValue) {
		return config.getString(key, defaultValue);
	}

	private List<String> getKeys() {
		List<String> l=new ArrayList<>();
		Iterator<String> ik = config.getKeys();
		while (ik.hasNext()) {
			l.add(ik.next());
		}
		return l;
	}
}
