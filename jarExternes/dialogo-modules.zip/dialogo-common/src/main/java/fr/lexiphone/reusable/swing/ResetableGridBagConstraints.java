package fr.lexiphone.reusable.swing;

import java.awt.GridBagConstraints;
import java.awt.Insets;

/**
 * Simple GridBagConstraints contenant en plus une m�thode reset() remettant tout � z�ro
 * @author clime
 */
public class ResetableGridBagConstraints extends GridBagConstraints {
	protected int defaultGridx = RELATIVE;
	protected int defaultGridy = RELATIVE;
	protected int defaultGridwidth = 1;
	protected int defaultGridheight = 1;
	protected double defaultWeightx = 0;
	protected double defaultWeighty = 0;
	protected int defaultAnchor = CENTER;
	protected int defaultFill = NONE;
	protected Insets defaultInsets = new Insets(0, 0, 0, 0);
	protected int defaultIpadx = 0;
	protected int defaultIpady = 0;

	/**
	 * 
	 */
	public ResetableGridBagConstraints() {
		super();
	}

	/**
	 * @inheritdoc
	 * @param gridx
	 * @param gridy
	 * @param gridwidth
	 * @param gridheight
	 * @param weightx
	 * @param weighty
	 * @param anchor
	 * @param fill
	 * @param insets
	 * @param ipadx
	 * @param ipady
	 */
	public ResetableGridBagConstraints(int gridx, int gridy,
			int gridwidth, int gridheight,
			double weightx, double weighty,
			int anchor, int fill, Insets insets,
			int ipadx, int ipady) {

		super(gridx, gridy, gridwidth, gridheight, weightx, weighty, anchor, fill, insets, ipadx, ipady);
	}

	/**
	 * Resets all parameters to their default values
	 */
	public void reset() {
		gridx = defaultGridx;
		gridy = defaultGridy;
		gridwidth = defaultGridwidth;
		gridheight = defaultGridheight;

		weightx = defaultWeightx;
		weighty = defaultWeighty;
		anchor = defaultAnchor;
		fill = defaultFill;

		insets = (Insets) defaultInsets.clone();
		ipadx = defaultIpadx;
		ipady = defaultIpady;
	}

	public void resetGridX() {
		gridx = defaultGridx;
	}

	public void resetGridY() {
		gridy = defaultGridy;
	}

	public void resetGridwidth() {
		gridwidth = defaultGridwidth;
	}

	public void resetGridheight() {
		gridheight = defaultGridheight;
	}

	public void resetWeightX() {
		weightx = defaultWeightx;
	}

	public void resetWeightY() {
		weighty = defaultWeighty;
	}

	public void resetAnchor() {
		anchor = defaultAnchor;
	}

	public void resetFill() {
		fill = defaultFill;
	}

	public void resetInsets() {
		insets = (Insets) defaultInsets.clone();
	}

	public void resetIpadX() {
		ipadx = defaultIpadx;
	}

	public void resetIpadY() {
		ipady = defaultIpady;
	}

	/**
	 * @return
	 */
	public int getDefaultAnchor() {
		return defaultAnchor;
	}

	/**
	 * @return
	 */
	public int getDefaultFill() {
		return defaultFill;
	}

	/**
	 * @return
	 */
	public int getDefaultGridheight() {
		return defaultGridheight;
	}

	/**
	 * @return
	 */
	public int getDefaultGridwidth() {
		return defaultGridwidth;
	}

	/**
	 * @return
	 */
	public int getDefaultGridx() {
		return defaultGridx;
	}

	/**
	 * @return
	 */
	public int getDefaultGridy() {
		return defaultGridy;
	}

	/**
	 * @return
	 */
	public Insets getDefaultInsets() {
		return defaultInsets;
	}

	/**
	 * @return
	 */
	public int getDefaultIpadx() {
		return defaultIpadx;
	}

	/**
	 * @return
	 */
	public int getDefaultIpady() {
		return defaultIpady;
	}

	/**
	 * @return
	 */
	public double getDefaultWeightx() {
		return defaultWeightx;
	}

	/**
	 * @return
	 */
	public double getDefaultWeighty() {
		return defaultWeighty;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultAnchor(int in_i) {
		defaultAnchor = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultFill(int in_i) {
		defaultFill = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultGridheight(int in_i) {
		defaultGridheight = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultGridwidth(int in_i) {
		defaultGridwidth = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultGridx(int in_i) {
		defaultGridx = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultGridy(int in_i) {
		defaultGridy = in_i;
	}

	/**
	 * @param in_insets
	 */
	public void setDefaultInsets(Insets in_insets) {
		defaultInsets = in_insets;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultIpadx(int in_i) {
		defaultIpadx = in_i;
	}

	/**
	 * @param in_i
	 */
	public void setDefaultIpady(int in_i) {
		defaultIpady = in_i;
	}

	/**
	 * @param in_d
	 */
	public void setDefaultWeightx(double in_d) {
		defaultWeightx = in_d;
	}

	/**
	 * @param in_d
	 */
	public void setDefaultWeighty(double in_d) {
		defaultWeighty = in_d;
	}

}
