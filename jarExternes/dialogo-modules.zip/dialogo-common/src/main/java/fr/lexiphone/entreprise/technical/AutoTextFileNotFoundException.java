/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lexiphone.entreprise.technical;

import fr.lexiphone.reusable.util.i18n.Messages;

/**
 *
 * @author haerwynn
 */
public class AutoTextFileNotFoundException extends SpecificFileNotFoundException{


	public AutoTextFileNotFoundException() {
		super(Messages.getStringOrKey("entreprisesignalprocessingservice.notxtfile")+" !");
	}

	public AutoTextFileNotFoundException(String path) {
		super(Messages.getStringOrKey("entreprisesignalprocessingservice.notxtfile")+" : "+path);
	}

}
