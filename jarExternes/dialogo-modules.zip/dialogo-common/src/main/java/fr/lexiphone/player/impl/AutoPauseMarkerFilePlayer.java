/**
 *
 */
package fr.lexiphone.player.impl;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.IPlayerConfiguration;
import fr.lexiphone.player.PlayerEvent;
import fr.lexiphone.player.PlayerListener;
import java.beans.PropertyChangeEvent;
import java.io.Closeable;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.Collections;
import java.util.List;
import java.util.ListIterator;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.file.Mp3Wrapper;
import org.dialogo.sound.file.Zone;
import org.dialogo.sound.file.ZonesManager;
import org.dialogo.sound.file.ZonesWithPauseManager;

/**
 * Implementation note: the logic in this class is/was very complex and subtle
 * (when it was based on time). Beware!
 *
 * @author C&eacute;drik LIME
 */
// Implementation note:
// Computing the current zone is based on the underlying player position.
// Problem is: 2 adjacent zones can share the same end/start time, which makes it
// impossible to know which one is the current one...
// Solution: manage current zone # instead of time...
public class AutoPauseMarkerFilePlayer implements BasicController, PlayerListener, Closeable {

	protected static Log _log = LogFactory.getLog(AutoPauseMarkerFilePlayer.class);

	protected BasicController delegate;
	protected IPlayerConfiguration configuration;
	protected Zone currentZone;
	protected List<Zone> allZones;
	protected ZonesManager zonesManager;
	protected ZonesWithPauseManagerPt zonesWithPauseManager;
	private volatile boolean passTrough = true; // if no marker file -> no pauses
	private volatile boolean isPlayBeforePause = true;

	protected final Timer timer = new Timer("Marker AutoPause Player Timer", true);//$NON-NLS-1$
	protected volatile TimerTask currentTimerTask;
	/**
	 * Cummulative time (milliseconds) which we paused the delegate
	 * automatically while officially playing (blank sound). Only used for
	 * computing getPosMilliseconds() while in state PAUSED. Use {code
	 * System#currentTimeMillis() - autoPauseTimestamp} in all other cases.
	 */
	protected volatile long autoPauseTime = 0;
	/**
	 * Timestamp (System.currentTimeMillis()) at which we paused the delegate
	 * automatically, (updated suitably when the user asks to resume while we
	 * are auto-paused). Used to compute {@link #autoPauseTime} in conjonction
	 * with {@link System#currentTimeMillis()}.
	 */
	protected volatile long autoPauseTimestamp = -1;

	/**
	 * last date the user used the recurrence key
	 */
	protected volatile long lastRecurrenceTime = 0;
	/**
	 * time lapse during which recurrence key will jump to previous sentence
	 */
	protected static final long RECURRENCE_ALLOWANCE = TimeUnit.SECONDS.toMillis(1);

	/**
	 * "Virtual" (public) state of this player (i.e. with pause automagically
	 * managed and hidden). This is not the same as the underlying (real,
	 * physical) "internal/ASIO" state.
	 */
	private volatile PlayerState state = PlayerState.STOPPED;

	// Use PropertyChangeSupport rather than an Observer / Observable...
	protected PlayerPropertyChangeSupport propertyChangeSupport = new PlayerPropertyChangeSupport(this);
	//private boolean justOpened;
	//private File intro;
	//private boolean passThroughAfterIntro;
	private Mp3Wrapper sample;
	//private boolean finishedIntro;

	public AutoPauseMarkerFilePlayer(BasicController playerDelegate, IPlayerConfiguration configuration) {
		super();
		this.delegate = playerDelegate;
		this.configuration = configuration;
		//finishedIntro=false;
		delegate.addPlayerListener(this);
		//intro = null;
		//passThroughAfterIntro = false;
		//justOpened = false;
	}

	/**
	 * Cancel old timer tasks
	 */
	private synchronized void cancelTasks() {
		if (currentTimerTask != null) {
			_log.trace("Cancelling TimerTask " + currentTimerTask);
			currentTimerTask.cancel();
			currentTimerTask = null;
		}
		timer.purge();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	@SuppressWarnings("boxing")
	public Integer getPosSentenceNumber() throws BasicPlayerException {
		int zoneNumber = getCurrentZoneNumberInternal();
		return (zoneNumber == -1) ? null : zoneNumber;
	}

	/**
	 * @return current zone number (beginning by {@code 0}), or {@code -1} if
	 * none
	 */
	short getCurrentZoneNumberInternal() {
		if (passTrough || currentZone == null) {
			return -1;
		}
		int zoneNumber = zonesManager.getZones().indexOf(currentZone);
		return (zoneNumber == -1) ? -1 : (short) zoneNumber;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setPosSentenceNumber(int n) throws BasicPlayerException {
		//_log.trace("setPosSentenceNumber "+n);
		if (passTrough) {
			throw new IllegalStateException();
		}
		if (n < 0 || n >= allZones.size()) {
			throw new IllegalArgumentException(Integer.toString(n));
		}
		setCurrentZone(allZones.get(n));
	}

	private void beforeOpenPassTrough() throws BasicPlayerException {
		cancelTasks();
		setState(PlayerState.STOPPED);
		autoPauseTime = 0;
		autoPauseTimestamp = -1;
		lastRecurrenceTime = 0;
	}

	private void afterOpenPassTrough(String name) throws BasicPlayerException {
		passTrough = true;
		zonesManager = null;
		zonesWithPauseManager = null;
		currentZone = null;
		propertyChangeSupport.fireOpened(name);
	}

	public void openPassTrough(Mp3Wrapper sample) throws BasicPlayerException {
		this.sample = sample;
		beforeOpenPassTrough();
		//intro = null;
		delegate.open(sample);
		_log.debug("Opened sample " + sample.getFileName());
		afterOpenPassTrough(sample.getFileName());
	}

	/*public void openPassTrough(Mp3Wrapper sample, File intro) throws BasicPlayerException {
		this.sample = sample;
		beforeOpenPassTrough();
		this.intro = intro;
		delegate.open(sample);
		_log.debug("Opened sample " + sample.getFileName());
		afterOpenPassTrough(sample.getFileName());
	}*/

	public void openPassTrough(File file) throws BasicPlayerException {
		this.sample = new Mp3Wrapper(file);
		beforeOpenPassTrough();
		delegate.open(file);
		_log.debug("Opened file " + file);
		afterOpenPassTrough(file.toString());
	}

	public void openDirectly(File file) throws BasicPlayerException {
		beforeOpenPassTrough();
		delegate.open(file);
		_log.debug("Opened file " + file);
	}
	/**
	 * {@inheritDoc} Don't forget to call {@link #setPlayBeforePause(boolean)}
	 * after this method!
	 */
	@Override
	public void open(File file) throws BasicPlayerException {
		if (!file.exists() || !file.canRead()) {
			_log.warn("Aborting opening file \"" + file + "\" since is does not exist or can not be read.");
		}
		openPassTrough(file);
		afterOpen(sample);
	}

	@Override
	public void open(Mp3Wrapper sample) throws BasicPlayerException {
		if (!sample.hasProperties()) {
			_log.warn("no properties for " + sample.getFileName());
		}
		openPassTrough(sample);
		afterOpen(sample);
	}

	private void afterOpen(Mp3Wrapper sample) throws BasicPlayerException {
		// Grab MaRKer data
		File markerFile = sample.getMaRKerFile();//MP3Utils.getMaRKerFile(file);
		ZonesWithPauseManager zwpm = sample.getZonesWithPauseManager(configuration.getPlayerAutoPauseFactor(),
				configuration.getPlayerAutoPauseConstant());
		if (zwpm == null) {
			throw new BasicPlayerException("ZonesWithPauseManager = null");
		}
		zonesWithPauseManager = new ZonesWithPauseManagerPt(zwpm, configuration);
		if (zonesWithPauseManager == null) {
			passTrough = true;
			_log.debug("Non-existant MaRKer file: " + markerFile);
			zonesManager = null;
			return;
		} else {
			allZones = Collections.unmodifiableList(zonesWithPauseManager.getZones());
			currentZone = allZones.get(0);
			zonesManager = new ZonesManager(allZones);
			zonesManager.setSampleRate(zonesWithPauseManager.getSampleRate());
			_log.trace("sample rate: " + zonesWithPauseManager.getSampleRate());
			/*if (_log.isDebugEnabled()) {
			 _log.debug("All zones: " + zonesManager.toString());
			 }*/
			_log.trace("" + allZones.size() + " zones");
			_log.trace("Duration: " + getDuration() + " ms");
			// Seek to begining of sound, which may not be the begining of the file!
			long startTime = zonesManager.getStartTime(currentZone);
			if (startTime > 0) {
				_log.debug("Sound is not at begining of file! Jumping to " + startTime + " ms");
				delegate.setPosMilliSeconds(startTime);
			}
			passTrough = false;
		}
		//justOpened = true;
	}

	@Override
	public void play(long milliseconds) throws BasicPlayerException {
		_log.debug("play " + (milliseconds / 1000) + "s passTrough=" + passTrough + " delegate=" + delegate);
		if (passTrough) {
			//PlayerState oldState = delegate.getState();
			delegate.play(milliseconds);
			PlayerState newState = delegate.getState();
			/*_log.warn("  oldState="+oldState+", newState="+newState);
			 propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			 */
			setState(newState);
			return;
		}
		throw new UnsupportedOperationException();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void play() throws BasicPlayerException {
		_log.debug("play passTrough=" + passTrough);
		if (passTrough) {
			PlayerState oldState = delegate.getState();
			_log.debug(" old state=" + oldState);
			/*if (justOpened && intro != null) {
				playIntro();
			} else {*/
				delegate.play();
			//}
			PlayerState newState = delegate.getState();
			//propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			setState(newState);
			return;
		}
		switch (state) {
			case PLAYING:
				return;
			case PAUSED:
				throw new IllegalStateException();
			case STOPPED:
				cancelTasks();
				// Play can happen after TH choose to start at a given time, in which case we must start at the begining of the zone (be it play or pause).

				/*if (justOpened && intro != null) {
					_log.debug("will play intro");
					playIntro();
					setState(PlayerState.PLAYING);
				} else {*/
					_log.debug("real player -> play()");
					delegate.play();
					setState(PlayerState.PLAYING);
					recurrenceJump(false);
				//}
			default:
				
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void pause() throws BasicPlayerException {
		_log.debug("pause()");
		if (passTrough) {
			//PlayerState oldState = delegate.getState();
			delegate.pause();
			PlayerState newState = delegate.getState();
			//propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			setState(newState);
			return;
		}
		switch (state) {
			case PAUSED:
				return;
			case STOPPED:
				_log.warn("Can not pause() while in state " + PlayerState.STOPPED);
//			throw new IllegalStateException();
				return;
			case PLAYING:
				cancelTasks();
				_log.trace("real player -> pause()");
				delegate.pause();
				if (autoPauseTimestamp > 0) {
					// pause while "playing" silence
					autoPauseTime = System.currentTimeMillis() - autoPauseTimestamp;
					// autoPauseTimestamp will be updated in resume()
				}
				setState(PlayerState.PAUSED);
		}
	}

	@Override
	public void resume(long milliseconds) throws BasicPlayerException {
		_log.debug("resume(" + milliseconds + ")");
		if (passTrough) {
			//PlayerState oldState = delegate.getState();
			delegate.resume(milliseconds);
			PlayerState newState = delegate.getState();
			//propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			setState(newState);
			return;
		}
		throw new UnsupportedOperationException();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void resume() throws BasicPlayerException {
		if (passTrough) {
			//PlayerState oldState = delegate.getState();
			delegate.resume();
			PlayerState newState = delegate.getState();
			//propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			setState(newState);
			return;
		}
		switch (state) {
			case PLAYING:
				return;
			case STOPPED:
				_log.warn("Can not resume() while in state " + PlayerState.STOPPED);
//			throw new IllegalStateException();
				return;
			case PAUSED:
				cancelTasks();
				// We could have jumped while in pause mode... autoPauseTime is correctly updated in setPos()
				if (autoPauseTimestamp > 0) {
					// resume while "playing" silence
					autoPauseTimestamp = System.currentTimeMillis() - autoPauseTime;
					// re-schedule ResumeTask
					long delay = zonesWithPauseManager.getPauseDuration(currentZone) - autoPauseTime;
					scheduleTask(new ResumeTask(), delay);
				} else {
					// resume while playing sound
					// re-schedule PauseTask
					long delay = zonesManager.getEndTime(currentZone) - delegate.getPosMilliSeconds();
					scheduleTask(new PauseTask(), delay);
					_log.trace("real player -> resume(" + delay + ')');
					delegate.resume(delay);
				}
				setState(PlayerState.PLAYING);
				recurrenceJump(false);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void pauseOrResume() throws BasicPlayerException {
		if (passTrough) {
			delegate.pauseOrResume();
			PlayerState newState = delegate.getState();
			setState(newState);
			return;
		}
		switch (state) {
			case PAUSED:
				resume();
				break;
			case STOPPED:
				play();
				break;
			case PLAYING:
				pause();
				break;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void playOrResume() throws BasicPlayerException {
		_log.debug("playOrResume");
		if (passTrough) {
			delegate.playOrResume();
			PlayerState newState = delegate.getState();
			setState(newState);
			return;
		}
		switch (state) {
			case PAUSED:
				resume();
				break;
			case STOPPED:
				play();
				break;
			case PLAYING:
				break;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void playOrResume(long milliseconds) throws BasicPlayerException {
		_log.debug("playOrResume(" + milliseconds + ")");
		if (passTrough) {
			delegate.playOrResume(milliseconds);
			PlayerState newState = delegate.getState();
			setState(newState);
			return;
		}
		switch (state) {
			case PAUSED:
				resume(milliseconds);
				break;
			case STOPPED:
				play(milliseconds);
				break;
			case PLAYING:
				break;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void stop() throws BasicPlayerException {
		if (passTrough) {
			PlayerState oldState = delegate.getState();
			delegate.stop();
			PlayerState newState = delegate.getState();
			//propertyChangeSupport.fireStateChange(oldState, newState, getCurrentZoneNumberInternal(), getPosMilliSeconds());
			setState(newState);
			return;
		}
		cancelTasks();
		_log.trace("real player -> stop()");
		delegate.stop();
		autoPauseTimestamp = -1;
		autoPauseTime = 0;
		lastRecurrenceTime = 0;
		setState(PlayerState.STOPPED);
		currentZone = null;
		allZones = null;
		isPlayBeforePause = true;
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void recurrenceJump() throws BasicPlayerException {
		recurrenceJump(true);
	}

	public void recurrenceJump(boolean allowPreviousSentence) throws BasicPlayerException {
		if (passTrough) {
			_log.debug("no recurrence() as there are no markers; passing through to delegate");
			delegate.recurrenceJump();
			//propertyChangeSupport.fireRecurrenceJump(delegate.getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
			PlayerState newState = delegate.getState();
			setState(newState);
		} else {
			cancelTasks();
			autoPauseTime = 0;
			autoPauseTimestamp = -1;
			long now = System.currentTimeMillis();
			if (allowPreviousSentence && now < lastRecurrenceTime + RECURRENCE_ALLOWANCE) {
				_log.debug("recurrenceJump(): going to previous sentence");
				Zone newZone = zonesManager.getPreviousZone(currentZone);
				if (newZone != null) {
					currentZone = newZone;
				}
			} else {
				_log.debug("recurrenceJump(): going to begining of current sentence");
			}
			lastRecurrenceTime = now;
			_log.debug("recurrence() to " + zonesWithPauseManager.getStartTime(currentZone) + " ms");
			setCurrentZone(currentZone);
			propertyChangeSupport.fireRecurrenceJump(getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
		}
	}

	/**
	 * @return number of zones in current sample; {@code null} if zones are not
	 * available.
	 */
	@Override
	@SuppressWarnings("boxing")
	public Integer getTotalSentencesNumber() {
		if (zonesManager == null || zonesManager.getZones() == null) {
			_log.debug("getTotalSentencesNumber : zones are not available");
			return null;
		}
		return zonesManager.getZones().size();
	}

	/**
	 * Total duration, including pauses (ms) {@inheritDoc}
	 */
	@Override
	public long getDuration() throws BasicPlayerException {
		if (passTrough) {
			return delegate.getDuration();
		} else {
			return zonesWithPauseManager.getTotalDuration();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public long getPosMilliSeconds() throws BasicPlayerException {
		if (passTrough) {
			return delegate.getPosMilliSeconds();
		}
		if (currentZone == null) {// avoid NPE
			return 0;
		}
		// Get time lapse in current zone...
		long posMilliseconds = 0;
		// add up play time (if any)
		if (isPlayBeforePause || autoPauseTimestamp == -1) { // pause-before-play: check we are in "play" part
			long playPosMillis = delegate.getPosMilliSeconds();
			long startTime = zonesManager.getStartTime(currentZone);
			posMilliseconds += (playPosMillis - startTime);
		}
		// add up paused time (if any)
		if (autoPauseTimestamp > 0) {
			if (state == PlayerState.PAUSED) {
				posMilliseconds += autoPauseTime;
			} else {
				posMilliseconds += (System.currentTimeMillis() - autoPauseTimestamp);
			}
		}
		// ... and add up all previous zones (total) time
		ListIterator<Zone> allZonesIter = allZones.listIterator(allZones.indexOf(currentZone));
		while (allZonesIter.hasPrevious()) {
			Zone zone = allZonesIter.previous();
			posMilliseconds += zonesWithPauseManager.getPlayDuration(zone);
			posMilliseconds += zonesWithPauseManager.getPauseDuration(zone);
		}
		return posMilliseconds;
	}

	/**
	 * {@inheritDoc} Will always set at begining of the requested zone (not in
	 * the middle).
	 */
	// Implementation note: must correctly set autoPauseTimestamp and autoPauseTime
	@Override
	public void setPosMilliSeconds(long virtualMilliSeconds) throws BasicPlayerException {
		_log.debug("setPosMilliSeconds(" + virtualMilliSeconds + ")");
		final long currentVirtualPosMilliSeconds = getPosMilliSeconds();
		if (virtualMilliSeconds < currentVirtualPosMilliSeconds && virtualMilliSeconds > currentVirtualPosMilliSeconds - 10) {//FIXME 10ms: magic number
			// jump backward for a very small amount (10 ms); optimisation: do nothing!
			return;
		}
		virtualMilliSeconds = Math.max(0, virtualMilliSeconds);
		if (passTrough) {
			delegate.setPosMilliSeconds(virtualMilliSeconds);
			propertyChangeSupport.fireSeek(delegate.getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
			return;
		}
		Zone zone;
		if (virtualMilliSeconds < getDuration()) {
			zone = zonesWithPauseManager.getCurrentZone(virtualMilliSeconds);
		} else {
//			stop();
//			return;
			zone = zonesManager.getZones().get(zonesManager.getZones().size() - 1);
		}
		// Go back to begining of requested zone
		virtualMilliSeconds = zonesWithPauseManager.getStartTime(zone);
		setCurrentZone(zone);
		propertyChangeSupport.fireSeek(getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
	}

	/**
	 * Will always set at begining of the requested zone (not in the middle).
	 */
	// Implementation note: must correctly set autoPauseTimestamp and autoPauseTime
	protected void setCurrentZone(Zone zone) throws BasicPlayerException {
		if (passTrough) {
			throw new IllegalStateException();
		}
		cancelTasks();
		autoPauseTime = 0;
		autoPauseTimestamp = -1;
		this.currentZone = zone;

		// seek to begining of sound part
		delegate.setPosMilliSeconds(zonesManager.getStartTime(currentZone));
		if (isPlayBeforePause) {
			if (state == PlayerState.PLAYING) {
				playCurrentZone();
			}
		} else {
			_log.trace("real player -> pause()");
			delegate.pause();
			if (state == PlayerState.PLAYING) {
				long delay = zonesWithPauseManager.getPauseDuration(currentZone);
				scheduleTask(new ResumeTask(), delay);
			}
		}
		// if (state == State.PAUSED): let's assume the user will press "play/resume" manually
	}

	protected void playCurrentZone() throws BasicPlayerException {
		_log.debug("playCurrentZone");
		if (passTrough || currentZone == null) {
			throw new IllegalStateException();
		}
		// seek to begining of sound part
		delegate.setPosMilliSeconds(zonesManager.getStartTime(currentZone));
		long delay = zonesWithPauseManager.getPlayDuration(currentZone);
		_log.trace("real player -> resume(" + delay + ')');
		delegate.resume(delay);
		// schedule next pause task to auto-pause after a while
		scheduleTask(new PauseTask(), delay);// remplacer par appel dans propertyChange
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getPositionAsPercent() throws BasicPlayerException {
		if (passTrough) {
			//_log.warn("getPositionAsPercent="+delegate.getPositionAsPercent());
			return delegate.getPositionAsPercent();
		}
		return (float) getPosMilliSeconds() / getDuration();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setPositionAsPercent(float percent) throws BasicPlayerException {
		_log.debug("setPositionAsPercent(" + percent + ")");
		percent = Math.max(0, percent);
		if (passTrough) {
			delegate.setPositionAsPercent(percent);
			propertyChangeSupport.fireSeek(delegate.getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
			return;
		}
		cancelTasks();
		setPosMilliSeconds((long) (getDuration() * percent));
	}

	/**
	 * {@inheritDoc} This method will simply jump from sentence to sentence,
	 * forward or backward depending on the sign of {@code milliseconds}.
	 */
	@Override
	public long seek(long milliseconds) throws BasicPlayerException {
		_log.debug("seek(" + milliseconds + ")");
		if (passTrough) {
			long seek = delegate.seek(milliseconds);
			propertyChangeSupport.fireSeek(delegate.getState(), getCurrentZoneNumberInternal(), getPosMilliSeconds());
			return seek;
		}
		cancelTasks();
		if (milliseconds > 0) {
			Zone nextZone = zonesManager.getNextZone(currentZone);
			if (nextZone != null && !nextZone.equals(currentZone)) {
				_log.debug("seekForward() to " + zonesWithPauseManager.getStartTime(nextZone) + " ms");
				setCurrentZone(nextZone);
			}
		} else {
			Zone previousZone = zonesManager.getPreviousZone(currentZone);
			if (previousZone == null) {
				previousZone = currentZone;
			}
			_log.debug("seekBackward() to " + zonesWithPauseManager.getStartTime(previousZone) + " ms");
			setCurrentZone(previousZone);
		}
		return getPosMilliSeconds();
	}

	@Override
	public void close() {
		_log.debug("close()");
		try {
			stop();
		} catch (BasicPlayerException ignore) {
		}
		cancelTasks();
		timer.cancel();
		propertyChangeSupport.close();
		//intro = null;
		//justOpened = true;
	}

	/**
	 * ********************************************************************
	 */
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void open(InputStream in) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void open(URL url) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getLeftLevel() {
		return delegate.getLeftLevel();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setLeftLevel(float leftOutput) {
		delegate.setLeftLevel(leftOutput);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getRightLevel() {
		return delegate.getRightLevel();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setRightLevel(float rightOutput) {
		delegate.setRightLevel(rightOutput);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getSoundLevelBoost() {
		return delegate.getSoundLevelBoost();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSoundLevelBoost(float soundLevelBoost) {
		delegate.setSoundLevelBoost(soundLevelBoost);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean getMute() {
		return delegate.getMute();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setMute(boolean mute) {
		delegate.setMute(mute);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setGain(double gain) throws BasicPlayerException {
		delegate.setGain(gain);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setPan(double pan) throws BasicPlayerException {
		setPan(pan);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public float getOutputVUMeterLevel() {
		return delegate.getOutputVUMeterLevel();
	}

	/**
	 * @param isPlayBeforePause the isPlayBeforePause to set
	 */
	public void setPlayBeforePause(boolean isPlayBeforePause) {
		this.isPlayBeforePause = isPlayBeforePause;
	}

	/**
	 * @return the state
	 */
	@Override
	public PlayerState getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 * @throws BasicPlayerException
	 */
	public void setState(PlayerState state) throws BasicPlayerException {
		PlayerState oldState = this.state;
		//_log.warn("  oldState="+oldState+", newState="+state);
		this.state = state;
		propertyChangeSupport.fireStateChange(oldState, state, getCurrentZoneNumberInternal(), getPosMilliSeconds());
	}

	/**
	 * ********************************************************************
	 */
	@Override
	public void addPlayerListener(PlayerListener listener) {
		_log.debug("addPlayerListener "+listener);
		propertyChangeSupport.addPropertyChangeListener(listener);
	}

	@Override
	public void removePlayerListener(PlayerListener listener) {
		propertyChangeSupport.removePropertyChangeListener(listener);
	}

	@Override
	public void opened(String streamName) {
		// noop
	}

	@Override
	public void propertyChange(PropertyChangeEvent evt) {
		PlayerEvent event = (PlayerEvent) evt;
		long posMilliSeconds;
				try {
					posMilliSeconds = getPosMilliSeconds();
				} catch (BasicPlayerException e) {
					_log.warn("can not call getPosMilliSeconds():", e);
					posMilliSeconds = -1;
				}
		_log.debug("propertyChange pos=" + posMilliSeconds + " " + event);
		if(posMilliSeconds==0&&event.getOldValue()==PlayerState.STOPPED&&event.getNewValue()==PlayerState.PLAYING){

		}
		/*if (EntrepriseSignalProcessingServiceImpl.instructionsOk && justOpened && pos > 600
			&& (event.getNewValue() == PlayerState.PAUSED/*||event.getNewValue() == PlayerState.STOPPED*) && (event.getOldValue() != event.getNewValue())) {
			_log.debug("was playing intro...");
			justOpened = false;
			try {
				stop();
				cancelTasks();
				timer.cancel();
				if (sample != null) {
					if (passThroughAfterIntro) {
						openPassTrough(sample);
					} else {
						open(sample);
					}
					passThroughAfterIntro = false;
					setPosSentenceNumber(1);
				}
			} catch (BasicPlayerException ex) {
				ex.printStackTrace();
			}
		} else */if ((event.getNewValue() == PlayerState.PAUSED) && (event.getOldValue() != event.getNewValue())) {
			if (passTrough) {
				short zn = getCurrentZoneNumberInternal();
				_log.debug("zone="+zn);
				if(zonesWithPauseManager!=null)_log.debug(" debut="+zonesWithPauseManager.getStartTime(currentZone)+" fin="+zonesWithPauseManager.getEndTime(currentZone));
				else if(zonesManager!=null)_log.debug(" debut="+zonesManager.getStartTime(currentZone)+" fin="+zonesManager.getEndTime(currentZone));
				propertyChangeSupport.fireStateChange(PlayerState.PLAYING, PlayerState.PAUSED, zn, posMilliSeconds);
				//scheduleTask(new PauseTask(), 0);
			}
		}
	}

	@Override
	public void recurrenceJump(PlayerEvent e) {
		// noop
	}

	@Override
	public void seek(PlayerEvent e) {
		// noop
	}

	/**
	 * ********************************************************************
	 */
	protected synchronized void scheduleTask(TimerTask task, long delay) {
		if (delay < 0) {
			throw new IllegalArgumentException("Negative delay: " + delay + " for task: " + task);
		}
		currentTimerTask = task;
		if (delay < 10) {
			_log.trace("executing task " + task + " immediately");
			task.run();
		} else {
			_log.trace("timer.schedule(" + currentTimerTask + ", " + delay + ')');
			timer.schedule(currentTimerTask, delay);
		}
	}

	/*@Override
	public void open(Mp3Wrapper sample, File intro) throws BasicPlayerException {
		if (!sample.hasProperties()) {
			_log.warn("no properties for " + sample.getFileName());
		}
		openPassTrough(sample, intro);
		afterOpen(sample);
	}*/

	/*private void playIntro() throws BasicPlayerException {
		_log.debug("playIntro");
		IntroPlayer introPlayer = new IntroPlayer(delegate);
		introPlayer.open(intro);
		//scheduleTask(new PauseTask(), delegate.getDuration());
		_log.debug(" intro duration=" + introPlayer.getDuration());
		introPlayer.play(introPlayer.getDuration());
	}*/

	/*void setIntro(File intro) {
		_log.debug("setIntro " + intro);
		this.intro = intro;
	}

	void setPassThroughAfterIntro(boolean b) {
		passThroughAfterIntro = b;
	}*/

	public void reactivateListener() {
		_log.debug("reactivateListener");
		delegate.addPlayerListener(this);
	}

	public void disactivateListener() {
		_log.debug("disactivateListener");
		delegate.removePlayerListener(this);
	}

	@Override
	public void reactivateControls() {
		//l=propertyChangeSupport.getPropertyChangeListeners()
		//finishedIntro = true;
	}

	@Override
	public void disactivateControls() {
	}

	/*@Override
	public boolean hasFinishedIntro() {
		return finishedIntro;
	}*/

	protected class PauseTask extends TimerTask {

		@Override
		public void run() {
			_log.debug("PauseTask.run");
			try {
				_log.debug(" pos=" + getPosMilliSeconds() + "ms");
				// we reached end of play part, and need to pause the player and schedule the next play part
//				_log.trace("real player -> pause()");
//				delegate.pause();// commented since the underlying player will auto-pause itself: #resume(millis)
				autoPauseTimestamp = System.currentTimeMillis();
				autoPauseTime = 0;
				Zone nextZone = zonesManager.getNextZone(currentZone);
				if (isPlayBeforePause) {
					// need to wait until end of this zone (which starts with a sound part)
					long delay = zonesWithPauseManager.getPauseDuration(currentZone);
					scheduleTask(new ResumeTask(), delay);
				} else { // pause before play
					// wait for the pause time of next zone
					// we're changing of current zone!
					if (nextZone != null && !nextZone.equals(currentZone)) {
						setCurrentZone(nextZone);// ResumeTask is done inside
					} else {
						// no next zone, so no need to schedule a resume
						_log.trace("No next zone (end of file)");
						currentTimerTask = null;
						autoPauseTimestamp = -1;
					}
				}
			} catch (BasicPlayerException bpe) {
				_log.error("", bpe);
			}
		}

		@Override
		public String toString() {
			String className = getClass().getName();
			className = className.substring(className.lastIndexOf('.') + 1);
			return className + "@" + Integer.toHexString(hashCode());
		}
	}

	protected class ResumeTask extends TimerTask {

		@Override
		public void run() {
			_log.debug("ResumeTask.run");
			try {
				_log.debug(" pos=" + getPosMilliSeconds() + "ms");
				// we reached end of pause part, and need to resume the player and schedule the next pause part
				autoPauseTime = 0;
				autoPauseTimestamp = -1;
				Zone nextZone = zonesManager.getNextZone(currentZone);
				if (isPlayBeforePause) {
					// need to start the sound part of next zone
					// we're changing of current zone!
					if (nextZone != null && !nextZone.equals(currentZone)) {
						setCurrentZone(nextZone);// delegate.resume() and PauseTask is done inside
					} else {
						// no next zone, so no need to schedule a pause
						// note: do not resume the player since last zone can be != end of file
						_log.trace("No next zone (end of file)");
						currentTimerTask = null;
					}
				} else { // pause before play
					// need to start the sound part of current zone (we are in the middle of it)
					playCurrentZone();
				}
			} catch (BasicPlayerException bpe) {
				_log.error("", bpe);
			}
		}

		@Override
		public String toString() {
			String className = getClass().getName();
			className = className.substring(className.lastIndexOf('.') + 1);
			return className + "@" + Integer.toHexString(hashCode());
		}
	}

}
