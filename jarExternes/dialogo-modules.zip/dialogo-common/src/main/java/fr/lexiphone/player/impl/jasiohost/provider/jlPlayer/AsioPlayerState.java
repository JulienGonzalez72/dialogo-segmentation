package fr.lexiphone.player.impl.jasiohost.provider.jlPlayer;

import com.synthbot.jasiohost.AsioDriverState;

import fr.lexiphone.entreprise.workmodule.PlayerState;

//FIXME should we merge with {@link PlayerState} and use {@link AsioDriverState} where this class is used?
// Beware, order definition is important!
enum AsioPlayerState {
	error,
	unloaded,
	loaded,
	playing,
	paused,
	stopped;
}
