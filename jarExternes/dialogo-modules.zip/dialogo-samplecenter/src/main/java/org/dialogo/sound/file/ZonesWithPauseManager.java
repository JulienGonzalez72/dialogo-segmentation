package org.dialogo.sound.file;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe encapsulant la logique de la gestion du temps.
 * @author C&eacute;drik LIME
 */
public class ZonesWithPauseManager {
	public static final float DEFAULT_FRAMES_PER_SECOND = ZonesManager.DEFAULT_FRAMES_PER_SECOND;

	private static final Log _log = LogFactory.getLog(ZonesWithPauseManager.class);

	/*
	 * Param�tres pour calculer le temps de pause automatique lors de la lecture des fichiers avec MaRKer
	 */
	/*
	 * Facteur multiplicatif
	 */
	protected float autoPauseFactor = 1.1f;
	/*
	 * Contante additive (en millisecondes)
	 */
	protected int autoPauseConstantMillis = 600;

	protected List<Zone> zones;
	protected ZonesManager zonesManager;

	public ZonesWithPauseManager(List<Zone> zones, float autoPauseFactor, int autoPauseConstantMillis) {
		super();
		assert zones != null;
		this.zones	= zones;
		this.zonesManager = new ZonesManager(zones);
	}
	public ZonesWithPauseManager(List<Zone> zones, float autoPauseFactor, int autoPauseConstantMillis, int sampleRate) {
		this(zones, autoPauseFactor, autoPauseConstantMillis);
		setSampleRate(sampleRate);
	}

	public List<Zone> getZones() {
		return new ArrayList<Zone>(zones);
	}

	/**
	 * @return sampleRate in Hz
	 */
	public int getSampleRate() {
		return (int) zonesManager.sampleRate;
	}

	/**
	 * @param sampleRate in Hz
	 */
	public void setSampleRate(int sampleRate) {
		if (sampleRate > 0) {
			zonesManager.setSampleRate(sampleRate);
		} else {
			_log.warn("Invalid sample rate requested: " + sampleRate + "; defaulting to " + (int)DEFAULT_FRAMES_PER_SECOND + "Hz");
		}
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore correspondant au d�but de la phrase, en millisecondes
	 * @see #getTransitionTime(Zone, float, boolean)
	 * @see #getEndTime(Zone, float)
	 */
	public long getStartTime(final Zone zone, float speedModifier) {
		long posTotalMilliseconds = getEndTime(zone, speedModifier);
		posTotalMilliseconds -= getPlayDuration(zone) + getPauseDuration(zone, speedModifier);
		return posTotalMilliseconds;
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore entre le son et la pause, en millisecondes
	 * @see #getStartTime(Zone, float)
	 * @see #getEndTime(Zone, float)
	 */
	public long getTransitionTime(Zone zone, float speedModifier, boolean isPlayBeforePause) {
		long posTotalMilliseconds = getEndTime(zone, speedModifier);
		if (isPlayBeforePause) {
			posTotalMilliseconds -= getPauseDuration(zone, speedModifier);
		} else {
			posTotalMilliseconds -= getPlayDuration(zone);
		}
		return posTotalMilliseconds;
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore + pause correspondant � la fin de la phrase, en millisecondes
	 * @see #getStartTime(Zone, float)
	 * @see #getTransitionTime(Zone, float, boolean)
	 */
	public long getEndTime(Zone zone, float speedModifier) {
		assert zones.contains(zone);
		Iterator<Zone> allZonesIter = zones.iterator();
		long posTotalMilliseconds = 0;
		Zone currentZone;
		do {
			currentZone = allZonesIter.next();
			posTotalMilliseconds += getPlayDuration(currentZone) + getPauseDuration(currentZone, speedModifier);
		} while (allZonesIter.hasNext() && ! currentZone.equals(zone));
		return posTotalMilliseconds;
	}

	/**
	 * @param zone
	 * @return la dur�e du son li� au la phrase n� sentenceNumber, en millisecondes
	 */
	public long getPlayDuration(Zone zone) {
		return zonesManager.getZoneDuration(zone);
	}
	/**
	 * @param zone
	 * @return how long we should pause after/before playing a zone, in milliseconds
	 */
	public long getPauseDuration(Zone zone, float speedModifier) {
		long zoneTimeWithoutPause = getPlayDuration(zone);
		long result = (long) (
				((autoPauseFactor * zoneTimeWithoutPause) + autoPauseConstantMillis)
				* (1 + speedModifier)
			);
		return Math.max(zoneTimeWithoutPause, result);
	}

	public Zone getCurrentZone(final long posVirtualMilliseconds, float speedModifier) {
		Iterator<Zone> allZonesIter = getZones().iterator();
		long posTotalMilliseconds = 0;
		long posDelegatePlayMillisec = 0;
		Zone zone;
		do {
			zone = allZonesIter.next();
			posDelegatePlayMillisec += getPlayDuration(zone);
			posTotalMilliseconds += getPlayDuration(zone) + getPauseDuration(zone, speedModifier);
		} while (allZonesIter.hasNext() && posTotalMilliseconds < posVirtualMilliseconds);
		if (posTotalMilliseconds > posVirtualMilliseconds) {// "if" as we could be at last zone
			// posXXXMillis are now past posMilliseconds; rewind 1 step
			posDelegatePlayMillisec -= getPlayDuration(zone);
			posTotalMilliseconds -= getPlayDuration(zone) + getPauseDuration(zone, speedModifier);
		}
		return zone;
	}

	/**
	 * Total duration, including pauses (ms)
	 */
	public long getTotalDuration(float speedModifier) {
		// Compute duration (with pauses)
		Zone lastZone = zones.get(zones.size() - 1);
		long duration = getEndTime(lastZone, speedModifier);
		return duration;
	}

}
