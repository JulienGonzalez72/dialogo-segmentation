package fr.lexiphone.player.impl.jasiohost.effect;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import alt.dev.szfoundation.SZProperties;

import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.tools.ButterworthFilterOrder2Highpass4000Freq48000;


public class ParametricEffect implements Effect {
	// la 440Hz
	private static final long[] AVAILABLE_FREQUENCIES = new long[] {
		19912, 18792, 17740, 16744, 15804, 14918, 14080, 13290, 12544, 11840, 11176, 10548, 9956, 9396, 8870, 8372, 7902
	};
	private static final String FREQUENCY_MATRIX_PREFIX = "frequencyMatrix_";//$NON-NLS-1$
	
	static public final String ID = "Prosodic v3";

	static {
		Arrays.sort(AVAILABLE_FREQUENCIES);
	}

	//p�riode to swich square frequency value in ms
	private int bigPeriod = 10;
	
	private double highFrequency = 11000.0;
	private double lowFrequency = 4000;
	private int frameRate = 0;
	private double indice = 0.03;
	double[] frequencyMatrix = new double[] { 1.0, 0.3, 0.15, 0.075, 0.03, 0.0 };

	private int sample_count = 0;
	private int sample_max = 0;
	private int sample_max_modified = 0;
	private double previous_moy = 0;
	private double frequency = 0;
	private float excursion = 1;
	private float leftLevel = 0;//0.125f;
	private float rightLevel = 0;//0.125f;
	private ParametricEffectIhm anIhm = null;
	private BaseBus theBus = null;
	private double[] veryPreviousSignalValue = new double[8];
	// square signal
	//private double[] harmonicCoef = new double[] {1, 0, 1.0/3, 0, 1.0/5, 0, 1.0/7, 0}; // same array size as veryPreviousSignalValue
	private double[] harmonicCoef = new double[] {1, 0.5, 1.0/3, 0, 1.0/5, 0, 1.0/7, 0}; // same array size as veryPreviousSignalValue
	// simple sinusoidal signal without harmonics
	//private double[] harmonicCoef = new double[] {1, 0, 0, 0, 0, 0, 0, 0}; // same array size as veryPreviousSignalValue
	private final double harmonicMaxFrequency = 20000;
	
	//valeurs de debug pour les pentes de mont�e et de descente
	private double coeff = 24;
	private double sampleToClean = 47;
	
	private volatile boolean cleanHighFrequency = true;
//	private double countToClean = 48;
	
	private ButterworthFilterOrder2Highpass4000Freq48000 leftFilter = new ButterworthFilterOrder2Highpass4000Freq48000();
	private ButterworthFilterOrder2Highpass4000Freq48000 rightFilter = new ButterworthFilterOrder2Highpass4000Freq48000();


	public ParametricEffect() {
		assert harmonicCoef.length == veryPreviousSignalValue.length;
		anIhm = new ParametricEffectIhm();
		setCleanHightFrequency(true);
	}

	public void setBus(BaseBus aBus) {
		this.theBus = aBus;
		this.frameRate = (int) Math.round(this.theBus.getFrameRate());
		sample_max = getEtf(this.frameRate);
		readFrequencyMatrix();
	}

	protected void readFrequencyMatrix() {
		// read frequencyMatrix
		try {
			SZProperties plist = new SZProperties();
			InputStream in = this.getClass().getResourceAsStream(getFrequencyMatrixFileName());
			plist.load(in);
			in.close();
			List<String> fList = (List<String>) plist.getCollection("f", null);
			double[] newFrequencyMatrix = new double[fList.size()];
			int i = 0;
			for (String f : fList) {
				newFrequencyMatrix[i] = Double.parseDouble(f);
				++i;
			}
			frequencyMatrix = newFrequencyMatrix;
		} catch (IOException e) {
			throw new IllegalStateException(e);
		}
	}

	@Override
	public String getName() {
		return ID;
	}

	@Override
	public float [] soundModification(float inLeft, float inRight) {
		++sample_count;
		//calcul de la moyenne en fonction de 
		previous_moy = getMoy((inLeft + inRight) / 2 * (excursion * 45f)); // 45: excursion volume is too low
		if(sample_count >= sample_max_modified) {
			sample_max = getEtf(this.frameRate);//reset sample_max
			frequency = getFrequencyFactor(previous_moy);
			sample_count = 0;
			//applanation hack
//			this.countToClean = 0;
		}
		float output = generateSinSignalWithHarmonics(frequency, sample_count, frameRate);
		//TODO : clean or restore applanation hack
		/*if(sample_count <= this.sampleToClean) {
//			output *= Math.pow(2, -((this.sampleToClean - this.sample_count) / this.coeff));
			
//			double pow = this.sampleToClean - this.sample_count;
//			double result = Math.pow(2, -( pow));
//			output *= result;*
			
			double pow = this.sampleToClean - this.sample_count;
			double number = Math.exp(Math.log(2)/3);
			double result = Math.pow(number, - pow);
			output *= result;
		}
		if(sample_count >= (this.sample_max - this.sampleToClean)) {
//			output *= Math.pow(2, -( -(this.sample_max - this.sampleToClean - sample_count) / this.coeff));
			
//			double pow = -(this.sample_max - this.sampleToClean - sample_count);
//			double result = Math.pow(2, -( pow));
//			output *= result;
			
			double pow = -(this.sample_max - this.sampleToClean - sample_count);
			double number = Math.exp(Math.log(2)/3);
			double result = Math.pow(number, - pow);
			output *= result;
		}//*/
		// filtre de Butterworth pour r�duction du bruit
		float outputLeft = output * leftLevel, outputRight = output * rightLevel;
		outputLeft = leftFilter.next(output * this.leftLevel);
		outputRight = rightFilter.next(output * this.rightLevel);
		return new float[]{outputLeft, outputRight};
	}
	
	private double getMoy(float aSample) {
		return (this.previous_moy * (sample_max - 1) + Math.abs(aSample) * Math.PI/2) / sample_max;
	}
	
	private int getEtf(int frame_rate) {
		 return frame_rate / 1000 * bigPeriod;
	}
	
	/**
	 * @param enveloppe [0..1]
	 * @return [lowFrequency..highFrequency]
	 */
	private double getFrequencyFactor(double enveloppe) {
		if (enveloppe < 0) {
			enveloppe = 0;
		} else if (enveloppe > 1) {
			enveloppe = 1;
		}
		double frequency = lowFrequency + (highFrequency - lowFrequency) * frequencyMatrix[(int)(enveloppe*(frequencyMatrix.length - 1))];
		// adjust sample_max to cleanly finish generated sin wave
		double period = (frameRate / frequency);
		double periodsInBigPeriod = Math.rint(sample_max / period);
		sample_max_modified = (int)Math.rint(periodsInBigPeriod * period);
		frequency = frameRate / (sample_max_modified / periodsInBigPeriod);
		return frequency;
	}
	
	private float generateSinSignalWithHarmonics(final double frequency, final int sample_count, final int frame_rate) {
		if (this.cleanHighFrequency && frequency >= this.highFrequency) {
			return 0;
		}
		double currentFrequency = frequency;
		int harmonicLevel = 0;
		double result = 0;
		double soundLevelNormalization = 0;
		while (harmonicLevel < harmonicCoef.length && currentFrequency <= harmonicMaxFrequency) {
			result += generateSinSignal(harmonicLevel, currentFrequency, sample_count, frame_rate) * harmonicCoef[harmonicLevel];
			soundLevelNormalization += 1 * harmonicCoef[harmonicLevel];
			++harmonicLevel;
			currentFrequency += frequency;
		}
		return (float) (result / soundLevelNormalization);
	}
	
	private double generateSinSignal(final int harmonicLevel, final double frequency, final int sample_count, final int frame_rate) {
		if (frequency >= harmonicMaxFrequency) {
			return 0;
		}
		if (harmonicLevel >= harmonicCoef.length) {
			return 0;
		}
		double period = frame_rate / frequency;
		double previous_effect = Math.sin((sample_count - 0)/period * Math.PI * 2 );
		//if (Math.abs(previous_effect-veryPreviousSignalValue[harmonicLevel]) > 1 && frequency < 8000)
		//	System.out.println("ParametricEffect#generateSinSignal() : pas bien!");
		//veryPreviousSignalValue[harmonicLevel] = previous_effect;
		return (previous_effect * 0.05); // 0.05: parametric sound is too loud
	}
	
	@Override
	public JPanel getIhm() {
		anIhm.setFHight(highFrequency);
		anIhm.setFLow(lowFrequency);
		anIhm.setIndice(indice);
		anIhm.addActionToApplyButton(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setHighFrequency(anIhm.getFHigh());
				setLowFrequency(anIhm.getFLow());
				setIndice(anIhm.getIndice());
				setSampleToClean(anIhm.getNumberSambleToClean());
				setCoeff(anIhm.getCoeff());
				cleanHighFrequency = anIhm.getCleanFrenquency();
			}
		});
		anIhm.addChangeToInputLevel(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				excursion = anIhm.getExcursionLevel();
			}
		});
		anIhm.addChangeToOutputLevel(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				leftLevel = anIhm.getOutputLeftLevel();
			}
		}, new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				rightLevel = anIhm.getOutputRightLevel();
			}
		});
		return anIhm;
	}
	
	public void setCoeff(double coeff) {
		this.coeff = coeff;
	}

	public double getCoeff() {
		return coeff;
	}

	public void setSampleToClean(double sampleToClean) {
		this.sampleToClean = sampleToClean - 1;
	}

	public double getSampleToClean() {
		return sampleToClean;
	}

	public double getIndice() {
		return indice;
	}

	public void setIndice(double indice) {
		this.indice = indice;
		if (anIhm != null) {
			anIhm.setIndice(indice);
		}
	}
	
	public int getBigPeriod() {
		return bigPeriod;
	}

	public void setBigPeriod(int bigPeriod) {
		this.bigPeriod = bigPeriod;
	}

	public double getHighFrequency() {
		return highFrequency;
	}

	public void setHighFrequency(double highFrequency) {
		if (highFrequency != this.highFrequency) {
			this.highFrequency = highFrequency;
			readFrequencyMatrix();
			if (anIhm != null) {
				anIhm.setFHight(highFrequency);
			}
		}
	}

	public double getLowFrequency() {
		return lowFrequency;
	}

	public void setLowFrequency(double lowFrequency) {
		this.lowFrequency = lowFrequency;
		if (anIhm != null) {
			anIhm.setFLow(lowFrequency);
		}
	}

	public int getFrameRate() {
		return frameRate;
	}

	public void setFrameRate(int frameRate) {
		this.frameRate = frameRate;
	}
	
	public void setInputLevel(float value){
		this.excursion = value;
		if (anIhm != null) {
			anIhm.setExcursionLevel(this.excursion);
		}
	}
	
	public void setOutputLeftLevel(float value) {
		this.leftLevel = value;
		if (anIhm != null) {
			anIhm.setOutputLeftLevel(this.leftLevel);
		}
	}
	
	public void setOutputRightLevel(float value) {
		this.rightLevel = value;
		if (anIhm != null) {
			anIhm.setOutputRightLevel(this.rightLevel);
		}
	}
	
	public void setCleanHightFrequency(boolean active) {
		this.cleanHighFrequency = active;
		if (anIhm != null) {
			anIhm.setCleanFrequency(active);
		}
	}

	private String getFrequencyMatrixFileName() {
		long frq = (long)highFrequency;
		// round highFrequency to known values
		int index = Arrays.binarySearch(AVAILABLE_FREQUENCIES, frq);
		if (index >= 0) {
			frq = AVAILABLE_FREQUENCIES[index];
		} else {
			int newIndex = Math.min(-index - 1, AVAILABLE_FREQUENCIES.length-1);
			frq = AVAILABLE_FREQUENCIES[newIndex];
		}
		return FREQUENCY_MATRIX_PREFIX + frq + ".plist";//$NON-NLS-1$
	}

	public static void main(String[] args) throws IOException {
		final int max_points = 500;
		ParametricEffect effect = new ParametricEffect();
		effect.frameRate = 48000;
		effect.indice = 0.03;
		effect.lowFrequency = 4000;
		for (long highFreq : AVAILABLE_FREQUENCIES) {
			effect.highFrequency = highFreq;
			SZProperties plist = new SZProperties();
			plist.put("indice", effect.indice);
			plist.put("lowFrequency", (long)effect.lowFrequency);
			plist.put("highFrequency", (long)effect.highFrequency);
			plist.put("frameRate", effect.frameRate);
			System.out.println("indice:\t" + effect.indice);
			System.out.println("lowFrequency:\t" + (long)effect.lowFrequency);
			System.out.println("highFrequency:\t" + (long)effect.highFrequency);
			System.out.println("frameRate:\t" + effect.frameRate);
			List<Double> freqs = new ArrayList<Double>(max_points + 1);
			for (int i = 0; i <= max_points; ++i) {
				double enveloppe = i / (double) max_points;
				double frequency = effect.lowFrequency + (effect.highFrequency-effect.lowFrequency) * Math.log(enveloppe) / Math.log(effect.indice);
				frequency = Math.max(frequency, effect.lowFrequency);
				frequency = Math.min(frequency, effect.highFrequency);
				double normalizedFreq = (frequency - effect.lowFrequency) / (effect.highFrequency - effect.lowFrequency);
//				double varia = rand.nextDouble() * 2 / 100 * (rand.nextBoolean() ? 1 : -1);
//				normalizedFreq *= 1 + varia;
				freqs.add(normalizedFreq);
//				System.out.print(normalizedFreq);
//				if (i < max_points) {
//					System.out.print(", ");
//				}
			}
			plist.put("f", freqs);
			System.out.println();
			OutputStream out = new FileOutputStream(effect.getFrequencyMatrixFileName());
			plist.store(out);
			out.close();
		}
	}
}
