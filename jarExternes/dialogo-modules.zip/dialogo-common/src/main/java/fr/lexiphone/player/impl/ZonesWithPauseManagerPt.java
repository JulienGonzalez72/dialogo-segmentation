package fr.lexiphone.player.impl;

import java.util.List;

import javazoom.jlgui.basicplayer.BasicPlayerException;

import org.dialogo.sound.file.Zone;
import org.dialogo.sound.file.ZonesManager;

import fr.lexiphone.player.IPlayerConfiguration;

/**
 * Classe encapsulant la logique de la gestion du temps.
 * @author C&eacute;drik LIME
 */
class ZonesWithPauseManagerPt {
	public static final float DEFAULT_FRAMES_PER_SECOND = org.dialogo.sound.file.ZonesWithPauseManager.DEFAULT_FRAMES_PER_SECOND;

	protected org.dialogo.sound.file.ZonesWithPauseManager delegate;
	protected IPlayerConfiguration configuration;

	public ZonesWithPauseManagerPt(org.dialogo.sound.file.ZonesWithPauseManager delegate, IPlayerConfiguration configuration) {
		super();
		this.delegate = delegate;
		this.configuration = configuration;
	}

	public List<Zone> getZones() {
		return delegate.getZones();
	}

	/**
	 * @return sampleRate in Hz
	 */
	int getSampleRate() {
		return delegate.getSampleRate();
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore correspondant au d�but de la phrase, en millisecondes
	 */
	public long getStartTime(final Zone zone) {
		return delegate.getStartTime(zone, configuration.getPlayerSpeedModifier());
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore entre le son et la pause, en millisecondes
	 */
	public long getTransitionTime(Zone zone, boolean isPlayBeforePause) {
		return delegate.getTransitionTime(zone, configuration.getPlayerSpeedModifier(), isPlayBeforePause);
	}

	/**
	 * @param zone
	 * @return position virtuelle de l'extrait sonore + pause correspondant � la fin de la phrase, en millisecondes
	 */
	public long getEndTime(Zone zone) {
		return delegate.getEndTime(zone, configuration.getPlayerSpeedModifier());
	}

	/**
	 * @param zone
	 * @return how long we should pause after/before playing a zone, in milliseconds
	 * @see ZonesManager#getZoneDuration(Zone)
	 */
	public long getPlayDuration(Zone zone) {
		return delegate.getPlayDuration(zone);
	}

	/**
	 * @param zone
	 * @return how long we should pause after/before playing a zone, in milliseconds
	 */
	public long getPauseDuration(Zone zone) {
		return delegate.getPauseDuration(zone, configuration.getPlayerSpeedModifier());
	}

	public Zone getCurrentZone(long posVirtualMilliseconds) throws BasicPlayerException {
		return delegate.getCurrentZone(posVirtualMilliseconds, configuration.getPlayerSpeedModifier());
	}

	/**
	 * Total duration, including pauses (ms)
	 */
	public long getTotalDuration() {
		return delegate.getTotalDuration(configuration.getPlayerSpeedModifier());
	}
}
