package fr.lexiphone.player.impl.jasiohost.bus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.effect.Effect;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import fr.lexiphone.player.impl.jasiohost.provider.LineControl;

public abstract class BaseBus extends LineControl {

//	protected Log log = LogFactory.getLog(getClass());

	protected List<BaseProvider> devices = null;
	protected Effect effect = null;
	protected double frameRate = 48000;
	protected volatile float mtvPrc = 0.0f;
	protected volatile float mtvPrd = 1.0f;
	private volatile boolean alternate = false;
	private final Timer timer = new Timer("Bus Alternation Timer", true);//$NON-NLS-1$
	private volatile TimerTask currentTimerTask;

	public BaseBus(String name) {
		super(name);
		this.devices = new ArrayList<BaseProvider>();
		initAlternation();
	}
	
	/**
	 * This is the method which calls and inits the asio Driver,
	 * for the beginning it auto select the 2 first output.
	 * You must load the parameters before.
	 */
	public abstract boolean initDriver();
	
	public abstract boolean stopDriver();
	
	public List<BaseProvider> getDevices() {
		return new ArrayList<BaseProvider>(this.devices);
	}
	
	public void addDevice(BaseProvider aDevice) {
		this.devices.add(aDevice);
		aDevice.addBusToRegister(this);
	}
	
	public void addDevices(Collection<BaseProvider> manyDevices) {
		for(BaseProvider provider : manyDevices) {
			this.addDevice(provider);
		}
	}

	public void removeDevice(BaseProvider aDevice) {
		this.devices.remove(aDevice);
		aDevice.removeBusToRegister(this);
	}
	
	public Effect getEffect() {
		return this.effect;
	}
	
	public abstract boolean changeFrameRate(double sampleRate);
	
	public void setEffect(Effect anEffect) {
		if(anEffect != null) {
			anEffect.setBus(this);
		}
		this.effect = anEffect;
	}
	
	public double getFrameRate() {
		return this.frameRate;
	}
	
	public abstract void write(StereoBuffer aStereoBuffer);
	
	public StereoBuffer mixDevices(int bufferSize, float devicesLeftLevel, float devicesRightLevel) {
		if(mute) {
			return new StereoBuffer(new float [bufferSize], new float [bufferSize]);
		}
		float [] outputLeft = new float[bufferSize];
		float [] outputRight = new float[bufferSize];
		StereoBuffer tmpBuff = null;

		//mixing all devices
		for (BaseProvider unGene : devices) {
			tmpBuff = unGene.getBuffer();
			if (tmpBuff != null && tmpBuff.getLeftChannel().length == bufferSize && tmpBuff.getRightChannel().length == bufferSize) {
				for (int i = 0; i < bufferSize; ++i) {
					outputLeft[i]  += tmpBuff.getLeftChannel()[i];
					outputRight[i] += tmpBuff.getRightChannel()[i];
				}
			}
		}

		//apply effect
		float devicesAttenuation = 1f / devices.size();
		if(effect != null) {
			float [] modif = null;
			for (int i = 0; i < outputLeft.length; ++i) {
				modif = effect.soundModification(outputLeft[i] * devicesAttenuation, outputRight[i] * devicesAttenuation);
				outputLeft[i]  = outputLeft[i] * (this.alternate ? 0f : devicesLeftLevel) + modif[0];
				outputRight[i] = outputRight[i] * (this.alternate ? 0f : devicesRightLevel) + modif[1];
			}
		} else {
			for (int i = 0; i < outputLeft.length; ++i) {
				outputLeft[i]  *= (this.alternate ? 0f : devicesLeftLevel);
				outputRight[i] *= (this.alternate ? 0f : devicesRightLevel);
			}
		}

		//final volume
		for (int i = 0; i < outputLeft.length; ++i) {
			outputLeft[i]  *= leftLevel;
			outputRight[i] *= rightLevel;
		}
		return new StereoBuffer(outputLeft, outputRight);
	}

	private synchronized void initAlternation() {
		cancelTasks();
		if (mtvPrc <= 0 || mtvPrd <= 0) {
			// no alternation
//			log.debug("initAlternation(): no alternation");
			this.alternate = false;
			return;
		} else {
//			log.debug("initAlternation(): starting alternation: sound " + getAlternationSoundTempo() + "s -- pause " + getAlternationPauseTempo() + "s");
			scheduleTask(new MuteTask(), 10);
		}
	}

	/**
	 * % du signal � 0 dans une p�riode
	 * @see fr.lexiphone.player.IEntrepriseSignalProcessingService#setMtvPrc(float)
	 */
	public void setMtvPrc(float mtvPrc) {
		cancelTasks();
		this.mtvPrc = mtvPrc;
		initAlternation();
	}

	/**
	 * p�riode du multivibrateur en millisecondes
	 * @see fr.lexiphone.player.IEntrepriseSignalProcessingService#setMtvPrd(float)
	 */
	public void setMtvPrd(float mtvPrd) {
		cancelTasks();
		if (mtvPrd == 0) {
			mtvPrd = 0.01f;
		}
		this.mtvPrd = mtvPrd;
		initAlternation();
	}

	protected float getAlternationSoundTempo() {
		return (100 - mtvPrc) * mtvPrd / 100f;
	}
	protected float getAlternationPauseTempo() {
		return mtvPrc * mtvPrd / 100f;
	}

	/**
	 * Cancel old timer tasks
	 */
	private synchronized void cancelTasks() {
		if (currentTimerTask != null) {
			currentTimerTask.cancel();
			currentTimerTask = null;
		}
		timer.purge();
	}

	protected synchronized void scheduleTask(TimerTask task, long delay) {
		if (delay < 0) {
			throw new IllegalArgumentException("Negative delay: " + delay + " for task: " + task);
		}
		currentTimerTask = task;
		if (delay < 10) {
//			log.trace("executing task "+task+" immediately");
			task.run();
		} else {
//			log.trace("timer.schedule("+currentTimerTask+", "+delay+')');
			timer.schedule(currentTimerTask, delay);
		}
	}

	protected class MuteTask extends TimerTask {
		@Override
		public void run() {
			alternate = true;
			long delay = (long) (getAlternationPauseTempo() * 1000);
//			log.trace("Unmuting in " + delay + "ms");
			scheduleTask(new UnmuteTask(), delay);
		}
		@Override
		public String toString() {
			String className = getClass().getName();
			className = className.substring(className.lastIndexOf('.')+1);
			return className + "@" + Integer.toHexString(hashCode());
		}
	}
	protected class UnmuteTask extends TimerTask {
		@Override
		public void run() {
			alternate = false;
			long delay = (long) (getAlternationSoundTempo() * 1000);
//			log.trace("Muting in " + delay + "ms");
			scheduleTask(new MuteTask(), delay);
		}
		@Override
		public String toString() {
			String className = getClass().getName();
			className = className.substring(className.lastIndexOf('.')+1);
			return className + "@" + Integer.toHexString(hashCode());
		}
	}
}
