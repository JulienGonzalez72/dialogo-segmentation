package fr.lexiphone.player.impl.jasiohost.provider;

import java.util.ArrayList;
import java.util.Map;

import org.apache.commons.lang.ArrayUtils;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;


public abstract class BaseProvider extends LineControl{
	
	protected Map<String, String> params = null;
	
	protected StereoBuffer outputBuffer = null;
	protected ArrayList<BaseBus> registredBus = new ArrayList<BaseBus>();

	public BaseProvider(String name) {
		super(name);
	}
	
	/**
	 * this method add the bus who use it in the registered bus list
	 * @param aBus a BaseBus that represent the bus who use it
	 */
	public void addBusToRegister(BaseBus aBus) {
		registredBus.add(aBus);
	}
	
	/**
	 *  this method remove the bus who not using it anymore in the registered bus list
	 * @param aBus a BaseBus that represent the bus who doesn't use it
	 */
	public void removeBusToRegister(BaseBus aBus) {
		registredBus.remove(aBus);
	}
	
	public abstract boolean changeFrameRateOfRegisteredBus();
	
	/**
	 * this method is automatically called when provider is added to the discovered devices
	 */
	public void setParams(Map<String,String> aMap) {
		params = aMap;
	}
	
	/**
	 * this method is automatically called when we need to save the parameters
	 * @return
	 */
	public Map<String, String> getParams() {
		return params;
	}
	
	/**
	 * return the buffer for the mixer
	 * @return a stereo buffer
	 */
	public StereoBuffer getBuffer() {
		return outputBuffer;
	}
	
	/**
	 * @return [0..1]
	 */
	public float getOutputVUMeterLevel() {
		float[] leftChannel = (outputBuffer == null) ? ArrayUtils.EMPTY_FLOAT_ARRAY
				: ArrayUtils.nullToEmpty(outputBuffer.getLeftChannel());
		float[] rightChannel = (outputBuffer == null) ? ArrayUtils.EMPTY_FLOAT_ARRAY
				: ArrayUtils.nullToEmpty(outputBuffer.getRightChannel());
		double result = 0.0;
		for (float f : rightChannel) {
			result += Math.abs((double)f)/rightChannel.length;
		}
		for (float f : leftChannel) {
			result += Math.abs((double)f)/leftChannel.length;
		}
		return (float) result; // do not / 2 as values are really low...
	}
	
	abstract public void refreshBuffer(int bufferSize);
	
	abstract public void init(BaseBus aBus);
	
	abstract public void sampleRateChanged(double sampleRate, BaseBus aBus);
}
