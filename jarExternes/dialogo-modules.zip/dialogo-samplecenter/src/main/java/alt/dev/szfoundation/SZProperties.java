//
//      ===========================================================================
//
//      Title:          SZProperties.java
//      Description:    More or less equivalent to java.util.Properties. 
//
//                      Uses "plist" serialization format instead of Sun's one.
//                      See alt.dev.szfoundation.SZPropertiesWriter.
//
//      Author:         Rapha�l Szwarc <zoe (underscore) info (at) mac (dot) com>
//      Creation Date:  Thu Dec 09 2004
//      Legal:          Copyright (C) 2004 Rapha�l Szwarc
//
//      This software is provided 'as-is', without any express or implied warranty. 
//      In no event will the author be held liable for any damages arising from 
//      the use of this software.
//
//      Permission is granted to anyone to use this software for any purpose, 
//      including commercial applications, and to alter it and 
//      redistribute it freely, subject to the following restrictions:
//
//      1. The origin of this software must not be misrepresented; 
//      you must not claim that you wrote the original software. 
//      If you use this software in a product, an acknowledgment
//      in the product documentation would be appreciated but is not required.
//
//      2. Altered source versions must be plainly marked as such, 
//      and must not be misrepresented as being the original software.
//
//      3. This notice may not be removed or altered from any source distribution.
//
//      ---------------------------------------------------------------------------
//

package alt.dev.szfoundation;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.util.Collection;
import java.util.Map;
import java.util.HashMap;
import java.util.Set;

public class SZProperties extends Object implements Map
{

//      ===========================================================================
//      Constant(s)
//      ---------------------------------------------------------------------------

//      ===========================================================================
//      Class variable(s)
//      ---------------------------------------------------------------------------

//      ===========================================================================
//      Instance variable(s)
//      ---------------------------------------------------------------------------

        private SZProperties    _defaults = null;
        private final Map       _map = new HashMap();

//      ===========================================================================
//      Constructor method(s)
//      ---------------------------------------------------------------------------

        public SZProperties(final SZProperties someDefaults)
        {
                super();
                
                this.setDefaults( someDefaults );
        }

        public SZProperties()
        {
                this( null );
        }

//      ===========================================================================
//      Class method(s)
//      ---------------------------------------------------------------------------

//      ===========================================================================
//      Instance method(s)
//      ---------------------------------------------------------------------------

        private SZProperties defaults()
        {
                return _defaults;
        }
        
        private void setDefaults(final SZProperties aValue)
        {
                _defaults = aValue;
        }

        private Map map()
        {
                return _map;
        }
        
        public String toString()
        {
                ByteArrayOutputStream   anOutputStream = new ByteArrayOutputStream();
                
                try
                {
                        SZPropertiesWriter.writeObject( this.map(), anOutputStream );
                        
                        return new String( anOutputStream.toByteArray(), SZPropertiesWriter.Encoding );
                }
                catch (Exception anException)
                {
                        throw new RuntimeException( "SZproperties.toString: " + anException.getMessage(), anException );
                }
        }
        
//      ===========================================================================
//      Properties method(s)
//      ---------------------------------------------------------------------------

        public String getProperty(final String aKey)
        {
                Object  aValue = this.get( aKey );
                String  aProperty = null;
                
                if ( aValue != null )
                {
                        aProperty = aValue.toString();
                }
                
                if ( aProperty == null )
                {
                        SZProperties    someDefaults = this.defaults();
                        
                        if ( someDefaults != null )
                        {
                                aProperty = someDefaults.getProperty( aKey );
                        }
                }
                
                return aProperty;
        }

        public String getProperty(final String aKey, final String aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty == null )
                {
                        aProperty = aDefaultValue;
                }
                
                return aProperty;
        }
        
        public void load(final InputStream anInputStream) throws IOException
        {
                if ( anInputStream != null )
                {
                        Object  anObject = SZPropertiesReader.readObject( anInputStream );
                        
                        if ( ( anObject instanceof Map ) == true )
                        {
                                this.map().putAll( (Map) anObject );
                        
                                return;
                        }
                        
                        if ( anObject != null )
                        {
                                throw new IllegalArgumentException( "SZProperties.load: '" + anObject.getClass().getName() + "' not instance of '" + Map.class.getName() + "'." );
                        }
                        
                        throw new IllegalArgumentException( "SZProperties.load: null object" );
                }
                
                throw new IllegalArgumentException( "SZProperties.load: null input stream" );
        }
        
        public void store(final OutputStream anOutputStream) throws IOException
        {
                if ( anOutputStream != null )
                {
                        SZPropertiesWriter.writeObject( this.map(), anOutputStream );
                        
                        return;
                }

                throw new IllegalArgumentException( "SZProperties.load: null output stream" );
        }

//      ===========================================================================
//      Map method(s)
//      ---------------------------------------------------------------------------

        public void clear()
        {
                this.map().clear();
        }
        
        public boolean containsKey(final Object aKey)
        {
                return this.map().containsKey( aKey );
        }
        
        public boolean containsValue(final Object aValue)
        {
                return this.map().containsValue( aValue );
        }
        
        public Set entrySet()
        {
                return this.map().entrySet();
        }
        
        public boolean equals(final Object anObject)
        {
                return this.map().equals( anObject );
        }
        
        public Object get(final Object aKey)
        {
                return this.map().get( aKey );
        }
        
        public int hashCode()
        {
                return this.map().hashCode();
        }

        public boolean isEmpty()
        {
                return this.map().isEmpty();
        }
        
        public Set keySet()
        {
                return this.map().keySet();
        }
        
        public Object put(final Object aKey, final Object aValue)
        {
                return this.map().put( aKey, aValue );
        }
        
        public void putAll(final Map aMap)
        {
                this.map().putAll( aMap );
        }
        
        public Object remove(final Object aKey)
        {
                return this.map().remove( aKey );
        }
        
        public int size()
        {
                return this.map().size();
        }
        
        public Collection values()
        {
                return this.map().values();
        }
        
//      ===========================================================================
//      Convenience method(s)
//      ---------------------------------------------------------------------------

        public Boolean getBoolean(final String aKey, final Boolean aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        return Boolean.valueOf( aProperty );
                }
                
                return aDefaultValue;
        }

        public Class getClass(final String aKey, final Class aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Class.forName( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Double getDouble(final String aKey, final Double aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Double.valueOf( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Float getFloat(final String aKey, final Float aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Float.valueOf( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Integer getInteger(final String aKey, final Integer aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Integer.valueOf( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Long getLong(final String aKey, final Long aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Long.valueOf( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Short getShort(final String aKey, final Short aDefaultValue)
        {
                String  aProperty = this.getProperty( aKey );
                
                if ( aProperty != null )
                {
                        try
                        {
                                return Short.valueOf( aProperty );
                        }
                        catch (Exception anException)
                        {
                                // Ignore
                        }
                }
                
                return aDefaultValue;
        }

        public Collection getCollection(final String aKey, final Collection aDefaultValue)
        {
                Object  aValue = this.get( aKey );
                
                if ( ( aValue instanceof Collection ) == true )
                {
                        return (Collection) aValue;
                }
                
                return aDefaultValue;
        }

        public Map getMap(final String aKey, final Map aDefaultValue)
        {
                Object  aValue = this.get( aKey );
                
                if ( ( aValue instanceof Map ) == true )
                {
                        return (Map) aValue;
                }
                
                return aDefaultValue;
        }

//      ===========================================================================
//      Primitive Convenience method(s)
//      ---------------------------------------------------------------------------

        public boolean getBoolean(final String aKey, final boolean aDefaultValue)
        {
                Boolean aValue = this.getBoolean( aKey, Boolean.valueOf( aDefaultValue ) );
                
                return aValue.booleanValue();
        }

        public double getDouble(final String aKey, final double aDefaultValue)
        {
                Double aValue = this.getDouble( aKey, null );
                
                if ( aValue != null )
                {
                        return aValue.doubleValue();
                }
                
                return aDefaultValue;
        }

        public float getFloat(final String aKey, final float aDefaultValue)
        {
                Float aValue = this.getFloat( aKey, null );
                
                if ( aValue != null )
                {
                        return aValue.floatValue();
                }
                
                return aDefaultValue;
        }

        public int getInt(final String aKey, final int aDefaultValue)
        {
                Integer aValue = this.getInteger( aKey, null );
                
                if ( aValue != null )
                {
                        return aValue.intValue();
                }
                
                return aDefaultValue;
        }

        public long getLong(final String aKey, final long aDefaultValue)
        {
                Long aValue = this.getLong( aKey, null );
                
                if ( aValue != null )
                {
                        return aValue.longValue();
                }
                
                return aDefaultValue;
        }

        public short getShort(final String aKey, final short aDefaultValue)
        {
                Short aValue = this.getShort( aKey, null );
                
                if ( aValue != null )
                {
                        return aValue.shortValue();
                }
                
                return aDefaultValue;
        }

}
