package fr.lexiphone.application.technical;

/**
 * <p>
 *  Exception relative � la couche Application.
 * </p>
 * @author pprimot
 */
public class ApplicationException extends Exception { // extends NestableException

	/**
	 * 
	 */
	public ApplicationException() {
		super();
	}

	/**
	 * Constructeur avec message.
	 * @param message
	 */
	public ApplicationException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ApplicationException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructeur avec message et exception d'origine.
	 * @param message
	 * @param cause
	 */
	public ApplicationException(String message, Throwable cause) {
		super(message, cause);
	}

	/** SURCHARGE : pour afficher aussi l'exception de d�part. */
	public void printStackTrace() {
		super.printStackTrace();
		/*
		System.err.println("ERREUR DANS LA COUCHE APPLICATION : ");
		super.printStackTrace();
		if (getOriginException()!=null) {
			System.err.println("ORIGINE DE L'ERREUR : ");
			getOriginException().printStackTrace();	
		}
		*/
	}

}
