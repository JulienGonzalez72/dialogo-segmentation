/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lexiphone.entreprise.technical;

import java.io.FileNotFoundException;

/**
 *
 * @author haerwynn
 */
public abstract class SpecificFileNotFoundException extends FileNotFoundException{

	public SpecificFileNotFoundException() {
	}

	public SpecificFileNotFoundException(String s) {
		super(s);
	}

}
