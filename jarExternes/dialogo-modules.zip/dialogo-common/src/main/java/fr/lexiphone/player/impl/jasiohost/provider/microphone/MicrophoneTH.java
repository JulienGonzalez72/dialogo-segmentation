package fr.lexiphone.player.impl.jasiohost.provider.microphone;


public class MicrophoneTH extends AbstractMicrophone {

	public final static String ID = "MicrophoneTH";
	public MicrophoneTH() {
		super(ID);
	}
	
}
