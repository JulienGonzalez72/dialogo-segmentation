package fr.lexiphone.player.impl.jasiohost.tools.parameters;

import fr.lexiphone.player.impl.jasiohost.bus.asio.AsioBus;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AsioParameterHelper {
	
	private final static String ASIO = AsioBus.ID + '.';
	private final static String DRIVER = "driver";
	private final static String LEFT_OUTPUT = "output.left";
	private final static String RIGHT_OUTPUT = "output.right";
	private final static String LEFT_TH_OUTPUT = "outputTH.left";
	private final static String RIGHT_TH_OUTPUT = "outputTH.right";
	private final static Log log=LogFactory.getLog(AsioParameterHelper.class);
	
	private static Parameters parametersInstance = Parameters.getInstance();

	static public void setDriverName(String driverName) {
		parametersInstance.setProperty(ASIO + DRIVER, driverName);
	}
	
	static public String getDriverName() {
		return parametersInstance.getProperty(ASIO + DRIVER);
	}
	
	static public boolean hasDriverName() {
		return parametersInstance.containsKey(ASIO + DRIVER);
	}
	
	static public void setRightOutput(int indexLine) {
		log.debug("setRightOutput->"+indexLine);
		parametersInstance.setProperty(ASIO + RIGHT_OUTPUT, Integer.toString(indexLine));
	}
	
	static public int getRightOutput() {
		return Integer.parseInt(parametersInstance.getProperty(ASIO + RIGHT_OUTPUT, "1"),10);
	}
	
	static public boolean hasRightOutput() {
		return parametersInstance.containsKey(ASIO + RIGHT_OUTPUT);
	}
	
	static public void setLeftOutput(int indexLine) {
		log.debug("setLeftOutput->"+indexLine);
		parametersInstance.setProperty(ASIO + LEFT_OUTPUT, Integer.toString(indexLine));
	}
	
	static public int getLeftOutput() {
		return Integer.parseInt(parametersInstance.getProperty(ASIO + LEFT_OUTPUT, "0"),10);
	}
	
	static public boolean hasLeftOutput() {
		return parametersInstance.containsKey(ASIO + LEFT_OUTPUT);
	}
	
	static public void setRightTHOutput(int indexLine) {
		log.debug("setRightTHOutput->"+indexLine);
		parametersInstance.setProperty(ASIO + RIGHT_TH_OUTPUT, Integer.toString(indexLine));
	}
	
	static public int getRightTHOutput() {
		return Integer.parseInt(parametersInstance.getProperty(ASIO + RIGHT_TH_OUTPUT, "-1"),10);
	}
	
	static public boolean hasRightTHOutput() {
		return parametersInstance.containsKey(ASIO + RIGHT_TH_OUTPUT);
	}
	
	static public void setLeftTHOutput(int indexLine) {
		log.debug("setLeftTHOutput->"+indexLine);
		parametersInstance.setProperty(ASIO + LEFT_TH_OUTPUT, Integer.toString(indexLine));
	}
	
	static public int getLeftTHOutput() {
		return Integer.parseInt(parametersInstance.getProperty(ASIO + LEFT_TH_OUTPUT, "-1"),10);
	}
	
	static public boolean hasLeftTHOutput() {
		return parametersInstance.containsKey(ASIO + LEFT_TH_OUTPUT);
	}
}
