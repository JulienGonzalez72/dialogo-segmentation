package fr.lexiphone.configuration;

import java.io.File;

import org.apache.commons.configuration.CompositeConfiguration;
import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.SystemConfiguration;

// uses commons-configuration ${} syntax to avoid managing parent folder
enum Folder {
	/**
	 * {@code Prg} directory, containing Dialogo fonts, images, xslt, &c.
	 */
	SYSTEM_ROOT("system"),
	SYSTEM_CONFIGURATION("system_conf"),
	FONTS("fonts"),
	IMAGES("images"),
	XSLT("xslt"),
	/**
	 * {@code data} directory, containing (user) sounds and associated text files
	 */
	DATA_ROOT("data"),
	SOUND_FILES("sound_files"),
	TEXTS("texts"),
	AUTOMATIC_TEXTS("automatic_texts"),
	/**
	 * {@code work} directory, containing user data: configuration, DB, &c.
	 */
	USER_ROOT("work"),
	USER_COMMON_CONFIGURATION("user_conf_global"),
	USER_SPECIFIC_CONFIGURATION("user_conf_local"),
	DB("db"),
	FORMULAIRES("forms"),
	PATIENTS("patients"),
	VERSIONS("versions");
	
	private static final Configuration paths;
	
	static {
		paths = new CompositeConfiguration();
		try {
			PropertiesConfiguration pathsProperties = new PropertiesConfiguration("paths.properties");
			PropertiesConfiguration localProperties = new PropertiesConfiguration("local-paths.properties");
			((CompositeConfiguration)paths).addConfiguration(localProperties); // primary
			((CompositeConfiguration)paths).addConfiguration(pathsProperties); // primary
			((CompositeConfiguration)paths).addConfiguration(new SystemConfiguration()); // fallback
		} catch (ConfigurationException e) {
			throw new RuntimeException("Can not load paths.properties or local-paths.properties", e);
		}
	}
	
	private String folderNameKey;

	private Folder(String folderName) {
		this.folderNameKey = folderName;
	}

	public String getFolderName() {
		return paths.getString(folderNameKey);
	}
	@Override
	public String toString() {
		return getFolderName();
	}
	
	public File getDirectory() {
		return new File(getFolderName());
	}


	public static void main(String[] args) {
		System.out.println("System:\t\t" + SYSTEM_ROOT.getDirectory());
		System.out.println("System conf:\t" + SYSTEM_CONFIGURATION.getDirectory());
		System.out.println("Data:\t\t" + DATA_ROOT.getDirectory());
		System.out.println("Data mp3:\t" + SOUND_FILES.getDirectory());
		System.out.println("Work:\t\t" + USER_ROOT.getDirectory());
		System.out.println("Work conf common:\t" + USER_COMMON_CONFIGURATION.getDirectory());
		System.out.println("Work conf local:\t" + USER_SPECIFIC_CONFIGURATION.getDirectory());
	}
}
