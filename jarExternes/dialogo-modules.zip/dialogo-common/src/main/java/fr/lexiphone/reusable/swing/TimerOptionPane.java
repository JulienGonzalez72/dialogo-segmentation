/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fr.lexiphone.reusable.swing;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.HeadlessException;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import javax.swing.Icon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.CLOSED_OPTION;
import static javax.swing.JOptionPane.ERROR_MESSAGE;
import static javax.swing.JOptionPane.INFORMATION_MESSAGE;
import static javax.swing.JOptionPane.PLAIN_MESSAGE;
import static javax.swing.JOptionPane.QUESTION_MESSAGE;
import static javax.swing.JOptionPane.VALUE_PROPERTY;
import static javax.swing.JOptionPane.WARNING_MESSAGE;
import static javax.swing.JOptionPane.getRootFrame;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;

/**
 * Le TimerOptionPane est un JOptionPane qui se ferme automatiquement apr�s un
 * d�lai donn�.
 *
 * Ici le d�lai est cod� en dur: 1500ms. Il faudrait rajouter des m�thodes
 * show... pour modifier cette valeur (TODO).
 * Seules les deux m�thodes showMessageDialog sont concern�es par ce d�lai.
 *
 * @author haerwynn
 */
public class TimerOptionPane extends JOptionPane {

	public TimerOptionPane() {
	}

	public TimerOptionPane(Object message) {
		super(message);
	}

	public TimerOptionPane(Object message, int messageType) {
		super(message, messageType);
	}

	public TimerOptionPane(Object message, int messageType, int optionType) {
		super(message, messageType, optionType);
	}

	public TimerOptionPane(Object message, int messageType, int optionType, Icon icon) {
		super(message, messageType, optionType, icon);
	}

	public TimerOptionPane(Object message, int messageType, int optionType, Icon icon, Object[] options) {
		super(message, messageType, optionType, icon, options);
	}

	public TimerOptionPane(Object message, int messageType, int optionType, Icon icon, Object[] options, Object initialValue) {
		super(message, messageType, optionType, icon, options, initialValue);
	}

	/**
	 * Comme JOptionPane.showMessageDialog, mais le dialogue se ferme automatiquement apr�s un court d�lai.
	 * @param parentComponent
	 * @param message
	 * @param title
	 * @param messageType
	 * @throws HeadlessException
	 */
	public static void showMessageDialog(Component parentComponent,
		Object message, String title, int messageType)
		throws HeadlessException {
		showMessageDialog(parentComponent, message, title, messageType, null);
	}

	/**
	 * Comme JOptionPane.showMessageDialog, mais le dialogue se ferme automatiquement apr�s un court d�lai.
	 * @param parentComponent
	 * @param message
	 * @param title
	 * @param messageType
	 * @param icon
	 * @throws HeadlessException
	 */
	public static void showMessageDialog(Component parentComponent,
		Object message, String title, int messageType, Icon icon)
		throws HeadlessException {
		TimerOptionPane pane = new TimerOptionPane(message, messageType,
			DEFAULT_OPTION, icon,
			null, null);

		//pane.setInitialValue(initialValue);
		pane.setComponentOrientation(((parentComponent == null)
			? getRootFrame() : parentComponent).getComponentOrientation());

		int style = styleFromMessageType(messageType);
		final JDialog dialog = pane.createDialog(parentComponent, title, style);
		Timer timer = new Timer(1500, new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				dialog.dispose();
			}
		});
		timer.setRepeats(false);
		timer.start();
		pane.selectInitialValue();
		dialog.show();
		dialog.dispose();
	}

	/**
	 * M�thode copi�e/coll�e car private dans JOptionPane.
	 *
	 * @see JOptionPane.styleFromMessageType(int messageType)
	 * @param messageType
	 * @return
	 */
	private static int styleFromMessageType(int messageType) {
		switch (messageType) {
			case ERROR_MESSAGE:
				return JRootPane.ERROR_DIALOG;
			case QUESTION_MESSAGE:
				return JRootPane.QUESTION_DIALOG;
			case WARNING_MESSAGE:
				return JRootPane.WARNING_DIALOG;
			case INFORMATION_MESSAGE:
				return JRootPane.INFORMATION_DIALOG;
			case PLAIN_MESSAGE:
			default:
				return JRootPane.PLAIN_DIALOG;
		}
	}

	/**
	 * M�thode copi�e/coll�e car private dans JOptionPane.
	 * @see JOptionPane.createDialog(Component parentComponent, String title, int style)
	 * @param messageType
	 * @return
	 */
	private JDialog createDialog(Component parentComponent, String title,
		int style)
		throws HeadlessException {

		final JDialog dialog;

		Window window = SwingUtilities.windowForComponent(parentComponent);
		if (window instanceof Frame) {
			dialog = new JDialog((Frame) window, title, true);
		} else {
			dialog = new JDialog((Dialog) window, title, true);
		}
		/*if (window instanceof SwingUtilities.SharedOwnerFrame) {
		 WindowListener ownerShutdownListener =
		 SwingUtilities.getSharedOwnerFrameShutdownListener();
		 dialog.addWindowListener(ownerShutdownListener);
		 }*/
		initDialog(dialog, style, parentComponent);
		return dialog;
	}

	/**
	 * M�thode copi�e/coll�e car private dans JOptionPane.
	 * @see JOptionPane.initDialog(final JDialog dialog, int style, Component parentComponent)
	 * @param messageType
	 * @return
	 */
	private void initDialog(final JDialog dialog, int style, Component parentComponent) {
		dialog.setComponentOrientation(this.getComponentOrientation());
		Container contentPane = dialog.getContentPane();

		contentPane.setLayout(new BorderLayout());
		contentPane.add(this, BorderLayout.CENTER);
		dialog.setResizable(false);
		if (JDialog.isDefaultLookAndFeelDecorated()) {
			boolean supportsWindowDecorations
				= UIManager.getLookAndFeel().getSupportsWindowDecorations();
			if (supportsWindowDecorations) {
				dialog.setUndecorated(true);
				getRootPane().setWindowDecorationStyle(style);
			}
		}
		dialog.pack();
		dialog.setLocationRelativeTo(parentComponent);

		final PropertyChangeListener listener = new PropertyChangeListener() {
			public void propertyChange(PropertyChangeEvent event) {
                // Let the defaultCloseOperation handle the closing
				// if the user closed the window without selecting a button
				// (newValue = null in that case).  Otherwise, close the dialog.
				if (dialog.isVisible() && event.getSource() == TimerOptionPane.this
					&& (event.getPropertyName().equals(VALUE_PROPERTY))
					&& event.getNewValue() != null
					&& event.getNewValue() != JOptionPane.UNINITIALIZED_VALUE) {
					dialog.setVisible(false);
				}
			}
		};

		WindowAdapter adapter = new WindowAdapter() {
			private boolean gotFocus = false;

			public void windowClosing(WindowEvent we) {
				setValue(null);
			}

			public void windowClosed(WindowEvent e) {
				removePropertyChangeListener(listener);
				dialog.getContentPane().removeAll();
			}

			public void windowGainedFocus(WindowEvent we) {
				// Once window gets focus, set initial focus
				if (!gotFocus) {
					selectInitialValue();
					gotFocus = true;
				}
			}
		};
		dialog.addWindowListener(adapter);
		dialog.addWindowFocusListener(adapter);
		dialog.addComponentListener(new ComponentAdapter() {
			public void componentShown(ComponentEvent ce) {
				// reset value to ensure closing works properly
				setValue(JOptionPane.UNINITIALIZED_VALUE);
			}
		});

		addPropertyChangeListener(listener);
	}

}
