package fr.lexiphone.player.impl.jasiohost.tools.parameters;

import fr.lexiphone.player.impl.jasiohost.bus.javaSound.JavaSoundBus;

public class JavaSoundParameterHelper {

	private final static String JAVASOUND = JavaSoundBus.ID.replace(' ', '_');
	private final static String MIXER = "_mixer";
	private final static String OUTPUT = "_output";
	
	private static Parameters parametersInstance = Parameters.getInstance();

	static public void setMixerName(String driverName) {
		parametersInstance.setProperty(JAVASOUND + MIXER, driverName);
	}
	
	static public String getMixerName() {
		return parametersInstance.getProperty(JAVASOUND + MIXER);
	}
	
	static public boolean hasMixerName() {
		return parametersInstance.containsKey(JAVASOUND + MIXER);
	}
	
	static public void setOutput(int indexLine) {
		parametersInstance.setProperty(JAVASOUND + OUTPUT, Integer.toString(indexLine));
	}
	
	static public int getOutput(){
		return Integer.parseInt(parametersInstance.getProperty(JAVASOUND + OUTPUT, "1"),10);
	}
	
	static public boolean hasOutput(){
		return parametersInstance.containsKey(JAVASOUND + OUTPUT);
	}
}
