/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.file;

//import fr.lexiphone.reusable.util.i18n.Messages;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * G�re les Filters (d�termin�s par la colonne PHASETYPE.SAMPLEFILTER de la bdd)
 * et les fait correspondre aux Segmentations
 * @author haerwynn
 */
public class FiltersLocator {

	private List<String> filtersAvecSpace;
	private List<String> filtersSansSpace;
	private static boolean logPlainly = false;
	//private String i18nPath;
	//private Properties i18nProps;
	//private static final String[] i18nKeys = {"name", "filter"};
	private List<String> filters;
	private static final Log log = LogFactory.getLog(FiltersLocator.class);
	//private Map<String, String> renames;
	private List<String> rawList;
	private String language;

	public FiltersLocator(Object o) {
		throw new UnsupportedOperationException("unsupported parameter : " + o);
	}

	public FiltersLocator(ResourceBundle r) {
		rawList = getRawList(r);
		//List<String>filterProps=getFilterProps(new ArrayList<String>(r.keySet()));
		initFilterProps();
	}

	public FiltersLocator(String i18nPath) {
		Properties i18nProps = new Properties();
		try {
			i18nProps.load(new FileReader(new File(i18nPath)));
		} catch (IOException ex) {
			log.error("",ex);
		}
		//resourceMap=getMap(i18nProps);
		rawList = getRawList(i18nProps);
		initFilterProps();
	}

	public FiltersLocator(List<String> filters) {
		rawList = filters;
		initFilterProps();
	}

	/*public Mp3PropertiesManager(ResourceBundle r) {
	 this(Messages.allKeys());
	 }*/
	private static void setLogPlainly(boolean b) {
		logPlainly = b;
	}

	public List<String> getFilters() {
		return filters;
	}

	public List<String> getFiltersAvecSpace() {
		return filtersAvecSpace;
	}

	public List<String> getFiltersSansSpace() {
		return filtersSansSpace;
	}

	private void error(Object o) {
		if (logPlainly) {
			System.err.println("Mp3PropertiesManager : " + o);
		} else {
			log.error(o);
		}
	}

	private void debug(Object o) {
		if (logPlainly) {
			System.out.println("Mp3PropertiesManager : " + o);
		} else {
			log.debug(o);
		}
	}

	private void initFilterProps() {
		language = "FR";
		//renames = new HashMap<>();
		filters = new ArrayList<>();
		filtersSansSpace = new ArrayList<>();
		filtersAvecSpace = new ArrayList<>();
		for (int i = 0; i < rawList.size(); i++) {
			//String pr = keys.get(i);
			String f = rawList.get(i);
			//if(f==null)f="";
			if (!filters.contains(f) && f != null && !f.trim().isEmpty() /*&&f.startsWith("db.PHASETYPE.")&&f.endsWith(".filter")*/) {
				debug(f);
				filters.add(f);
				if (f.contains(" ")) {
					filtersAvecSpace.add(f);
				} else {
					filtersSansSpace.add(f);
				}
			}
		}
		debug("filters=" + filters);
	}

	private Map<String, String> getMap(ResourceBundle r) {
		Map<String, String> m = new HashMap<>();
		if (r != null) {
			for (String k : r.keySet()) {
				if (k.startsWith("db.PHASETYPE.") && k.endsWith(".filter")) {
					m.put(k, r.getString(k));
				}
			}
		}
		return m;
	}

	private Map<String, String> getMap(Properties p) {
		Map<String, String> m = new HashMap<>();
		if (p != null) {
			for (String k : p.stringPropertyNames()) {
				if (k.startsWith("db.PHASETYPE.") && k.endsWith(".filter")) {
					m.put(k, p.getProperty(k));
				}

			}
		}
		return m;
	}

	private List<String> getRawList(Properties p) {
		List<String> l = new ArrayList<>();
		if (p != null) {
			for (String k : p.stringPropertyNames()) {
				if (k.startsWith("db.PHASETYPE.") && k.endsWith(".filter")) {
					l.add(p.getProperty(k));
				}
			}
		}
		return l;
	}

	private List<String> getRawList(ResourceBundle r) {
		List<String> l = new ArrayList<>();
		if (r != null) {
			for (String k : r.keySet()) {
				if (k.startsWith("db.PHASETYPE.") && k.endsWith(".filter")) {
					l.add(r.getString(k));
				}
			}
		}
		return l;
	}

	/**
	 * Convertit le Filter en Segmentation.
	 * @param f le samplefilter
	 * @return la segmentation attendue
	 */
	public String getSegmentationFromFiltre(String f) {
		if(f==null||f.trim().isEmpty())return "";
		String c=null;
		if (f.contains(" ")) {
			c = f.split(" ", 2)[1];
		} else if ("E".equals(f) || "Te".equals(f)) {
			c = "T";
		} else if ("MO".equals(f)) {
			c = "M";
		} else if (f.startsWith("a")) {
			f=f.trim();
			c=f.substring(1);
			if("po".equalsIgnoreCase(c)){
				c="T";
			}
		}
		if(f.startsWith("VP")||f.startsWith("MP")){
			c = "";
		} else if(c==null){
			c = f;
		}
		log.debug("getSegmentationFromFiltre "+f+" -> "+c);
		return c;
	}

	private String initFiltreExercice(String t, String f) {
		if (t.startsWith(f)) {
			String st = t.substring(f.length());
			int i1 = st.indexOf(" ");
			if (i1 == 0) {
				return f;
			}
			String nivString = getStartNumbers(st);
			if (nivString != null && !nivString.isEmpty()) {
				//st = st.substring(nivString.length());
				return f;
			}
			
		}
		return null;
	}

	public String[]getFiltreNomCorrigeEtNiveau(String t){
		if(t==null)return new String[]{"","","0"};
		String filtreExercice = getFiltreExercice(t);
		String titreCorrige=null;
		Integer niveauTitre=null;
		if (filtreExercice != null && !filtreExercice.isEmpty() && /*!filtreExercice.startsWith("a") && */!filtreExercice.startsWith("Ec") && !filtreExercice.startsWith("Ea")) {
			titreCorrige = t.substring(filtreExercice.length());
			if (titreCorrige.length() > 0 && titreCorrige.charAt(0) != ' ') {
				String nivString = getStartNumbers(titreCorrige);
				if (nivString != null && !nivString.isEmpty()) {
					try {
						niveauTitre = Integer.parseInt(nivString);
					} catch (NumberFormatException e) {
						niveauTitre = 0;
					}
					titreCorrige = titreCorrige.substring(nivString.length()).trim();
				}
			}
		}
		if (titreCorrige == null) {
			titreCorrige = t;
		}
		if (filtreExercice == null) {
			filtreExercice = "";
		}
		/*if(filtreExercice.startsWith("a")){
			filtreExercice=
		}*/
		return new String[]{filtreExercice,titreCorrige,niveauTitre==null?"0":""+niveauTitre};
	}
	public String getFiltreExercice(String t) {
		String premierMotTitre;
		int i = t.indexOf(" ");
		if (i < 0) {
			premierMotTitre = null;
		} else {
			premierMotTitre = t.substring(0, i);
		}
		if(premierMotTitre==null)return "";
		String endNumbers=getEndNumbers(premierMotTitre);
		if(endNumbers!=null&&!endNumbers.isEmpty()){
			premierMotTitre=premierMotTitre.substring(0, premierMotTitre.length()-endNumbers.length());
		}
		for (String f : getFiltersSansSpace()) {
			if (premierMotTitre.equals(f)) {
				//titreCorrige = getMp3Title().substring(f.length()).trim();
				return premierMotTitre;
			}
		}
		for (String f : getFiltersAvecSpace()) {
			String f1 = initFiltreExercice(t, f);
			if (f1 != null) {
				return f1;
			}
		}
		for (String f : getFiltersSansSpace()) {
			String f1 = initFiltreExercice(t, f);
			if (f1 != null) {
				return f1;
			}
		}
		switch(premierMotTitre){
			case "DW":
				return "aDM";
			case "W":
				return "aM";
			case "PO":
				return "aT";
			case "PS":
				return "aVP";
		}
		return "";
	}

	public String hasNumbers(String s) {
		if (s == null) {
			return null;
		}
		Pattern p = Pattern.compile("[0-9]+");
		Matcher m = p.matcher(s);
		if (m.find()) {
			return m.group();
		}
		return null;
	}

	public String getStartNumbers(String s) {
		if (s == null) {
			return null;
		}
		String numbers = "0123456789";
		/*Pattern p = Pattern.compile("[0-9]+");
		 Matcher m = p.matcher(s);
		 if (m.find()) {
		 return m.group();
		 }*/
		String sortie = "";
		for (int i = 0; i < s.length(); i++) {
			if (numbers.contains("" + s.charAt(i))) {
				sortie += s.charAt(i);
			} else {
				return sortie;
			}
		}
		return sortie;
	}
	public String getEndNumbers(String s) {
		if (s == null) {
			return null;
		}
		String numbers = "0123456789";
		String sortie = "";
		for (int i = 0; i < s.length(); i++) {
			if (numbers.contains("" + s.charAt(s.length()-i-1))) {
				sortie = s.charAt(i)+sortie;
			} else {
				return sortie;
			}
		}
		return sortie;
	}

	public String getLanguage() {
		return language;
	}

	public FiltersLocator setLanguage(String language) {
		this.language = language;
		return this;
	}

	public String[] getSegmentations(){
		return new String[]{"","S","M","DM","P","T"};
	}
}
