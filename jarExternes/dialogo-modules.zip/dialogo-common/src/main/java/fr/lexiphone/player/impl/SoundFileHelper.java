/*
 * Created on 4 mars 03
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package fr.lexiphone.player.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import fr.lexiphone.entreprise.technical.EntrepriseException;
import fr.lexiphone.player.IPlayerConfiguration;

/**
 * @author clime
 */
public class SoundFileHelper {
	private static final Log _log = LogFactory.getLog(SoundFileHelper.class);

	private SoundFileHelper() {
		super();
	}

	public static String fetchFile(IPlayerConfiguration configuration, String in_uri) throws EntrepriseException {
		_log.info("Fetching file '" + in_uri + '\'');
		String lc_fileName = configuration.getSamplesRootPath() + in_uri.trim();
		File lc_file = new File(lc_fileName);
//		// Conditionally fetch file from remote server, caching locally
//		String lc_serverRoot = EntrepriseLayerConfiguration.getInstance().getSamplesServerRoot();
//		if (StringUtils.isNotBlank(lc_serverRoot)) {
//			URL lc_url = new URL(lc_serverRoot + in_uri.trim());
//			URLConnection lc_conn = lc_url.openConnection();
//			try {
//				lc_conn.setAllowUserInteraction(false);
//				lc_conn.setConnectTimeout((int)TimeUnit.SECONDS.toMillis(5));
//				lc_conn.setReadTimeout((int)TimeUnit.SECONDS.toMillis(10));
//				lc_conn.setDoInput(true); 
//				lc_conn.setDoOutput(false); 
//				lc_conn.setUseCaches(true);
//				// only fetch remote file if it is newer than the one stored locally
//				lc_conn.setIfModifiedSince(lc_file.exists() ? lc_file.lastModified() : 0);
//				//TODO add Authorization header - Authorization: Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ
//				//lc_conn.addRequestProperty("Authorization", "Basic QWxhZGRpbjpvcGVuIHNlc2FtZQ");
//				lc_conn.connect();
//				int status = ((HttpURLConnection)lc_conn).getResponseCode();
//				if (status == 200) {
//					long lastModified = lc_conn.getLastModified();
//					try (InputStream data = lc_conn.getInputStream(); OutputStream outFile = new FileOutputStream(lc_file)) {
//						IOUtils.copyLarge(data, outFile);
//					} catch (IOException ioe) {
//						lc_file.delete();
//						throw ioe;
//					}
//					if (lastModified > 0) {
//						lc_file.setLastModified(lastModified);
//					}
//				}
//			} catch (IOException e) {
//				_log.warn("Error while fetching file " + in_uri, e);
//			} finally {
//				if (lc_conn instanceof HttpURLConnection) {
//					((HttpURLConnection)lc_conn).disconnect();
//				}
//			}
//		}
		if (!lc_file.exists()) {
			throw new EntrepriseException("Impossible de lire " + lc_fileName);
		}
		return lc_fileName;
	}
}
