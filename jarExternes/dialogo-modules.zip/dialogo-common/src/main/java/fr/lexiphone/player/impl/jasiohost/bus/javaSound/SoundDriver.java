package fr.lexiphone.player.impl.jasiohost.bus.javaSound;

public interface SoundDriver {
	
	void start();
	void stop();
	void restart();
	void getInputLines();
	void getOutputLines();
}
