package fr.lexiphone.entreprise.technical;

/**
 * <p>
 *  Exception relative � la couche Entreprise.
 * </p>
 * @author pprimot, clime
 */
public class EntrepriseException extends Exception {  // extends NestableException

	/**
	 * 
	 */
	public EntrepriseException() {
		super();
	}

	/**
	 * Constructeur avec message.
	 * @param message
	 */
	public EntrepriseException(String message) {
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public EntrepriseException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructeur avec message et exception d'origine.
	 * @param message
	 * @param cause
	 */
	public EntrepriseException(String message, Throwable cause) {
		super(message, cause);
	}

	/** SURCHARGE : pour afficher aussi l'exception de d�part. */
	public void printStackTrace() {
		super.printStackTrace();
		/*
		System.err.println("ERREUR DANS LA COUCHE ENTREPRISE : ");
		super.printStackTrace();
		if (getOriginException()!=null) {
			System.err.println("ORIGINE DE L'ERREUR : ");
			getOriginException().printStackTrace();	
		}
		*/
	}

}
