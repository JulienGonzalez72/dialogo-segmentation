package fr.lexiphone.player.impl.jasiohost.effect;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;


public class ParametricEffectV1 implements Effect {
	
	static public final String ID = "Prosodic v1";
	
	//p�riode to swich square frequency value in ms
	private int bigPeriod = 10;
	
	private double highFrequency = 11000;
	private double lowFrequency = 4000;
	private int frameRate = 0;
	private double indice = 0.03;

	private int sample_count = 0;
	private int sample_max = 0;
	private double previous_moy = 0;
	private double previous_effect = 0;
	private double square_frequency = 0;
	private float inputLevel = 1; // == excursion
	private float leftLevel = 0;//0.125f;
	private float rightLevel = 0;//0.125f;
	private ParametricEffectIhm anIhm = null;
	private BaseBus theBus = null;

	public ParametricEffectV1() {
		anIhm = new ParametricEffectIhm();
	}

	public void setBus(BaseBus aBus) {
		this.theBus = aBus;
		this.frameRate = (int) Math.round(this.theBus.getFrameRate());
		sample_max = getSamplesForBigPeriod(this.frameRate);
	}
	@Override
	public String getName() {
		return ID;
	}

	@Override
	public float [] soundModification(float inLeft, float inRight) {
		++sample_count;
		previous_moy = getMoy((inLeft + inRight) * 0.5f * inputLevel);
		if(sample_count >= sample_max) {
			sample_max = getSamplesForBigPeriod(this.frameRate);//reset sample_max
			square_frequency = getFrequencyFactor(previous_moy);
			sample_count = 0;
		}
		float output = generateSquareSignal(square_frequency, sample_count, frameRate);
		return new float[]{output * leftLevel, output * rightLevel};
	}
	
	private double getMoy(float aSample) {
		return (this.previous_moy * (sample_max - 1) + Math.abs(aSample) * Math.PI/2) / sample_max;
	}
	
	private int getSamplesForBigPeriod(int frame_rate) {
		 return frame_rate / 1000 * bigPeriod;
	}
	
	private double getFrequencyFactor(double enveloppe) {
		double frequency = Math.min(Math.pow(enveloppe/indice, - Math.log(lowFrequency/highFrequency)/ Math.log(indice)) * highFrequency, highFrequency);
		double period = (frameRate / frequency);
		double periodsInBuffer = Math.rint(getSamplesForBigPeriod(frameRate) / period);
		sample_max = (int)Math.rint(periodsInBuffer * period);
		frequency = frameRate / (sample_max / periodsInBuffer);
		return frequency;
	}
	
	private float generateSquareSignal(double square_frequency, int sampleNumber, int frame_rate) {
		double period = frame_rate / square_frequency;
		previous_effect = Math.sin((sampleNumber - 0)/period * Math.PI * 2);
		return (float) (previous_effect);
	}
	
	@Override
	public JPanel getIhm() {
		anIhm.setFHight(highFrequency);
		anIhm.setFLow(lowFrequency);
		anIhm.setIndice(indice);
		anIhm.addActionToApplyButton(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				setHighFrequency(anIhm.getFHigh());
				setLowFrequency(anIhm.getFLow());
				setIndice(anIhm.getIndice());
			}
		});
		anIhm.addChangeToInputLevel(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setInputLevel((float)(((JSlider)e.getSource()).getValue() / 10.0));
			}
		});
		anIhm.addChangeToOutputLevel(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setOutputLeftLevel((float)(((JSlider)e.getSource()).getValue() / 10.0));
			}
		}, new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setOutputRightLevel((float)(((JSlider)e.getSource()).getValue() / 10.0));
			}
		});
		return anIhm;
	}

	/**
	 * @return the indice
	 */
	public double getIndice() {
		return indice;
	}

	/**
	 * @param indice the indice to set
	 */
	public void setIndice(double indice) {
		this.indice = indice;
		if (anIhm != null) {
			anIhm.setIndice(indice);
		}
	}
	
	/**
	 * @return the bigPeriod
	 */
	public int getBigPeriod() {
		return bigPeriod;
	}

	/**
	 * @param bigPeriod the bigPeriod to set
	 */
	public void setBigPeriod(int bigPeriod) {
		this.bigPeriod = bigPeriod;
	}

	/**
	 * @return the highFrequency
	 */
	public double getHighFrequency() {
		return highFrequency;
	}

	/**
	 * @param highFrequency the highFrequency to set
	 */
	public void setHighFrequency(double highFrequency) {
		this.highFrequency = highFrequency;
		if (anIhm != null) {
			anIhm.setFHight(highFrequency);
		}
	}

	/**
	 * @return the lowFrequency
	 */
	public double getLowFrequency() {
		return lowFrequency;
	}

	/**
	 * @param lowFrequency the lowFrequency to set
	 */
	public void setLowFrequency(double lowFrequency) {
		this.lowFrequency = lowFrequency;
		if (anIhm != null) {
			anIhm.setFLow(lowFrequency);
		}
	}

	/**
	 * @return the frameRate
	 */
	public int getFrameRate() {
		return frameRate;
	}

	/**
	 * @param frameRate the frameRate to set
	 */
	public void setFrameRate(int frameRate) {
		this.frameRate = frameRate;
	}
	
	public void setInputLevel(float value){
		this.inputLevel = value;
		if (anIhm != null) {
			anIhm.setExcursionLevel(value);
		}
	}
	
	public void setOutputLeftLevel(float value) {
		this.leftLevel = value;
		if (anIhm != null) {
			anIhm.setOutputLeftLevel(value);
		}
	}
	
	public void setOutputRightLevel(float value) {
		this.rightLevel = value;
		if (anIhm != null) {
			anIhm.setOutputRightLevel(value);
		}
	}
}
