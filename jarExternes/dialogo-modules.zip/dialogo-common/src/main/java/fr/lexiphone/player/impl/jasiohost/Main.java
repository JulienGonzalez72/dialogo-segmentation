package fr.lexiphone.player.impl.jasiohost;

import java.io.File;

import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import org.apache.commons.configuration.ConfigurationException;

import javazoom.jlgui.basicplayer.BasicPlayerException;
import fr.lexiphone.configuration.ConfigurationService;
import fr.lexiphone.configuration.DLGConfiguration.Type;
import fr.lexiphone.player.impl.jasiohost.bus.asio.AsioBus;
import fr.lexiphone.player.impl.jasiohost.provider.jlPlayer.JlayerPlayer;
import fr.lexiphone.player.impl.jasiohost.provider.microphone.Microphone;
import fr.lexiphone.player.impl.jasiohost.provider.microphone.MicrophoneTH;
import fr.lexiphone.player.impl.jasiohost.tools.parameters.Parameters;

public class Main {

	/**
	 * @param args
	 * @throws InterruptedException 
	 */
	public static void main(String[] args) throws InterruptedException {
		try {
			UIManager.setLookAndFeel(
			            UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (InstantiationException e1) {
			e1.printStackTrace();
		} catch (IllegalAccessException e1) {
			e1.printStackTrace();
		} catch (UnsupportedLookAndFeelException e1) {
			e1.printStackTrace();
		}
		
		if(args.length != 0 && args[0] != null) {
			try {
				Parameters.setFile(new ConfigurationService().getConfiguration(Type.USER_SPECIFIC, args[0]));
			} catch (ConfigurationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
//		Start asio Driver
//		Parameters.setFile(new File("param.properties"));
		
		Mixer unMixer = Mixer.getInstance();
		
		JlayerPlayer unPlayer = (JlayerPlayer) unMixer.getDiscoveredDevice(JlayerPlayer.ID);//*/
		unMixer.activateDevice(unPlayer, AsioBus.ID);
//		unMixer.activateDevice(unPlayer, JavaSoundBus.ID);
//		unMixer.activateDevice(unPlayer, DistantHPBus.ID);
//		DistantMicrophone distantMicro = (DistantMicrophone) unMixer.getDiscoveredDevice(DistantMicrophone.ID);
//		unMixer.activateDevice(distantMicro, JavaSoundBus.ID);
//		
		Microphone unMicro = (Microphone) unMixer.getDiscoveredDevice(Microphone.ID);
		unMixer.activateDevice(unMicro, AsioBus.ID);
		
		MicrophoneTH unMicroTH = (MicrophoneTH) unMixer.getDiscoveredDevice(MicrophoneTH.ID);
		if (unMicroTH != null) {
			unMixer.activateDevice(unMicroTH, AsioBus.ID);
		}
		
		unMixer.initDrivers();
		try {
			unPlayer.open("TS44.mp3");
		} catch (BasicPlayerException e1) {
			e1.printStackTrace();
		}
		
		unPlayer.play();
		long start = System.currentTimeMillis();
//		unPlayer.setPosMilliSeconds(819683);
		try {
			unPlayer.setPositionAsPercent((float)0.50);
		} catch (BasicPlayerException e) {
			e.printStackTrace();
		}
		long stop = System.currentTimeMillis();
		System.out.println("d�placement: " + (stop - start) + "ms pour un d�placement de " + unPlayer.getPositionInFrames());
	}

}
