package fr.lexiphone.player.impl.jasiohost.effect;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeListener;

import fr.lexiphone.player.impl.jasiohost.tools.LexiTools;

public class ParametricEffectIhm extends JPanel {

	private static final long serialVersionUID = 1L;
	private JSlider jSliderExcursion = null;
	private JPanel jPanelSlidersOutput = null;
	private JSlider jSliderOutputLeft = null;
	private JSlider jSliderOutputRight = null;
	private JPanel jPanelConfig = null;
	private JTextField jTextFieldHaut = null;
	private JTextField jTextFieldBas = null;
	private JTextField jTextFieldIndice;
	private JButton jButtonApply;
	private JTextField jTextFieldNumber = null;
	private JTextField jTextFieldCoeff;
	private JCheckBox jCheckBoxCleanHigh;

	/**
	 * This method initializes 
	 * 
	 */
	public ParametricEffectIhm() {
		super();
		initialize();
	}

	/**
	 * This method initializes this
	 * 
	 */
	private void initialize() {
        this.setSize(new Dimension(323, 320));
        this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
        
        Border etchedBorder = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
        //Input Panel
        TitledBorder title = BorderFactory.createTitledBorder(etchedBorder, "Input");
		title.setTitleJustification(TitledBorder.CENTER);
		getJSliderExcursion().setBorder(title);
        this.add(getJSliderExcursion());
        
        //output panel
        title = BorderFactory.createTitledBorder(etchedBorder, "Output");
        title.setTitleJustification(TitledBorder.CENTER);
        getJPanelSlidersOutput().setBorder(title);
        this.add(getJPanelSlidersOutput());
        
        //Config panel
        title = BorderFactory.createTitledBorder(etchedBorder, "Config");
        title.setTitleJustification(TitledBorder.CENTER);
        getJPanelConfig().setBorder(title);
        this.add(getJPanelConfig(), null);
	}

	/**
	 * This method initializes jSliderInput	
	 * 	
	 * @return javax.swing.JSlider	
	 */
	private JSlider getJSliderExcursion() {
		if (jSliderExcursion == null) {
			jSliderExcursion = new JSlider(JSlider.VERTICAL,0,10,5);
			jSliderExcursion.setMajorTickSpacing(1);
			jSliderExcursion.setPaintTicks(true);
		}
		return jSliderExcursion;
	}
	
	private JPanel getJPanelSlidersOutput() {
		if (jPanelSlidersOutput == null) {
			jPanelSlidersOutput  = new JPanel();
			jPanelSlidersOutput.setLayout(new BoxLayout(jPanelSlidersOutput, BoxLayout.X_AXIS));
			jPanelSlidersOutput.add(getJSliderOutputLeft());
			jPanelSlidersOutput.add(getJSliderOutputRight());
		}
		return jPanelSlidersOutput;
	}

	/**
	 * This method initializes jSliderOutputLeft	
	 * 	
	 * @return javax.swing.JSlider	
	 */
	private JSlider getJSliderOutputLeft() {
		if (jSliderOutputLeft == null) {
			jSliderOutputLeft = new JSlider(JSlider.VERTICAL,0,10,2);
			jSliderOutputLeft.setMajorTickSpacing(2);
			jSliderOutputLeft.setPaintTicks(true);
		}
		return jSliderOutputLeft;
	}

	/**
	 * This method initializes jSliderOutputRight	
	 * 	
	 * @return javax.swing.JSlider	
	 */
	private JSlider getJSliderOutputRight() {
		if (jSliderOutputRight == null) {
			jSliderOutputRight = new JSlider(JSlider.VERTICAL, 0, 10, 2);
			jSliderOutputRight.setMajorTickSpacing(2);
			jSliderOutputRight.setPaintTicks(true);
		}
		return jSliderOutputRight;
	}

	/**
	 * This method initializes jPanelConfig	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelConfig() {
		if (jPanelConfig == null) {
			jPanelConfig = new JPanel(new BorderLayout());
			
			JPanel jPanelHaut = makeFieldPanel("F High : ", getJTextFieldHaut());
			JPanel jPanelBas = makeFieldPanel("F Low : ", getJTextFieldBas());
			JPanel jPanelIndice = makeFieldPanel("Indice : ", getJTextFieldIndice());
			JPanel jPanelNumber = makeFieldPanel("n : ", getJTextFieldNumber());
			JPanel jPanelCoeff = makeFieldPanel("lin�/Expo : ", getJTextFieldCoeff());
			
			JPanel centralPanel = new JPanel();
			centralPanel.setLayout(new BoxLayout(centralPanel, BoxLayout.Y_AXIS));
			centralPanel.add(jPanelHaut);
			centralPanel.add(jPanelBas);
			centralPanel.add(jPanelIndice);
			centralPanel.add(jPanelCoeff);
			centralPanel.add(jPanelNumber);
			centralPanel.add(getJCheckBoxCleanHigh());
			centralPanel.add(getJButtonApply());
			jPanelConfig.add(centralPanel, BorderLayout.PAGE_START);
		}
		return jPanelConfig;
	}
	
	private JTextField getJTextFieldCoeff() {
		if (this.jTextFieldCoeff == null) {
			this.jTextFieldCoeff = new JTextField(5);
			this.jTextFieldCoeff.setText("24");
		}
		return this.jTextFieldCoeff;
	}
	
	private JTextField getJTextFieldNumber() {
		if (this.jTextFieldNumber == null) {
			this.jTextFieldNumber = new JTextField(5);
			this.jTextFieldNumber.setText("48");
		}
		return this.jTextFieldNumber;
	}
	
	private JTextField getJTextFieldIndice() {
		if (jTextFieldIndice == null){
			jTextFieldIndice = new JTextField(5);
		}
		return jTextFieldIndice;
	}
	
	private JCheckBox getJCheckBoxCleanHigh() {
		if (this.jCheckBoxCleanHigh == null){
			this.jCheckBoxCleanHigh = new JCheckBox("Clean high frequencies");
		}
		return this.jCheckBoxCleanHigh;
	}
	
	private JButton getJButtonApply(){
		if(jButtonApply == null) {
			jButtonApply = new JButton("Apply");
		}
		return jButtonApply;
	}

	private JPanel makeFieldPanel(String name, JTextField aPanel) {
		JLabel jLabel = new JLabel(name);
		JPanel jPanel = new JPanel(new FlowLayout());
		jPanel.add(jLabel);
		jPanel.add(aPanel);
		return jPanel;
	}

	private JTextField getJTextFieldHaut() {
		if (jTextFieldHaut == null) {
			jTextFieldHaut = new JTextField(5);
		}
		return jTextFieldHaut;
	}
	
	private JTextField getJTextFieldBas() {
		if (jTextFieldBas == null) {
			jTextFieldBas  = new JTextField(5);
		}
		return jTextFieldBas;
	}
	
	public void addActionToApplyButton(ActionListener anAction) {
		getJButtonApply().addActionListener(anAction);
	}
	
	public double getFHigh(){
		return LexiTools.stringToDouble(getJTextFieldHaut().getText());
	}
	
	public double getFLow() {
		return LexiTools.stringToDouble(getJTextFieldBas().getText());
	}
	
	public double getIndice(){
		return LexiTools.stringToDouble(getJTextFieldIndice().getText());
	}

	public void setFHight(double value) {
		getJTextFieldHaut().setText(Double.toString(value));
	}
	
	public void setFLow(double value) {
		getJTextFieldBas().setText(Double.toString(value));
	}
	
	public void setIndice(double value) {
		getJTextFieldIndice().setText(Double.toString(value));
	}
	
	public float getOutputLeftLevel() {
		return getJSliderOutputLeft().getValue() / 10.0f;
	}
	
	public float getOutputRightLevel() {
		return getJSliderOutputRight().getValue() / 10.0f;
	}

	public void setOutputLeftLevel(float value) {
		getJSliderOutputLeft().setValue((int) (value * 10));
	}
	
	public void setOutputRightLevel(float value) {
		getJSliderOutputRight().setValue((int) (value * 10));
	}
	
	public void setExcursionLevel(float value) {
		getJSliderExcursion().setValue((int) (value * 10));
	}
	
	public float getExcursionLevel() {
		return getJSliderExcursion().getValue() / 10.0f;
	}
	
	public void addChangeToInputLevel(ChangeListener changeListener) {
		getJSliderExcursion().addChangeListener(changeListener);
	}
	
	public void addChangeToOutputLevel(ChangeListener changeListenerLeft, ChangeListener changeListenerRight) {
		getJSliderOutputLeft().addChangeListener(changeListenerLeft);
		getJSliderOutputRight().addChangeListener(changeListenerRight);
	}

	/**
	 * this getter return the n value who represents the number
	 * of sample to decrease an increase volume at frequency change
	 * @return a {@link Double} that represent the n value
	 */
	public double getNumberSambleToClean() {
		return LexiTools.stringToDouble(getJTextFieldNumber().getText());
	}

	/**
	 * this getter inform if we use the linear method of the exponential one
	 * to decrease and increase the volume at frequency change
	 * @return a {@link Boolean} that is at true is linear is selected 
	 * and false otherwise
	 */
	public double getCoeff() {
		return LexiTools.stringToDouble(getJTextFieldCoeff().getText());
	}

	public boolean getCleanFrenquency() {
		return getJCheckBoxCleanHigh().isSelected();
	}

	public void setCleanFrequency(boolean cleanHighFrequency) {
		getJCheckBoxCleanHigh().setSelected(cleanHighFrequency);
	}
}
