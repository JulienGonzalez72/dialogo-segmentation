package fr.lexiphone.player.impl.jasiohost.bus.asio;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.synthbot.jasiohost.AsioChannel;
import com.synthbot.jasiohost.AsioDriver;
import com.synthbot.jasiohost.AsioDriverListener;
import com.synthbot.jasiohost.AsioDriverState;

import fr.lexiphone.player.impl.jasiohost.tools.parameters.AsioParameterHelper;

public class Asio {

	private static final ConcurrentMap<String, AtomicInteger> busCountPerAsioDriver = new ConcurrentHashMap<>();
	
	private String driverName = null;
	
	private AsioDriver asioDriver = null;
	private List<AsioChannel> inputChannels = null;
	private List<AsioChannel> outputChannels = null;
	private AsioDriverListener leListener = null;
	private AsioChannel leftOutputChannel = null;
	private AsioChannel rightOutputChannel = null;
	private AsioChannel leftTHOutputChannel = null;
	private AsioChannel rightTHOutputChannel = null;
	private List<AsioChannel> extraChannel = null; // should be a Set, but need to enable "swapping" channels via IHM by having temporary duplicates...

	private static Log log = LogFactory.getLog(Asio.class);
	
	
	public Asio() {
		//initialisation des variables
		this.inputChannels = new ArrayList<AsioChannel>();
		this.outputChannels = new ArrayList<AsioChannel>();
		this.extraChannel = new ArrayList<AsioChannel>();
		
		//get AsioDriver to use
		if (AsioParameterHelper.hasDriverName()) {
			this.driverName = AsioParameterHelper.getDriverName();
		} else {
			List<String> drivers = Asio.getDriverNames();
			if (drivers.isEmpty()) {
				throw new IllegalStateException("no drivers found");
			}
			this.driverName = Asio.getDriverNames().get(0);
		}
		log.debug("driverName="+driverName);
		//initialization to get input/output channels list
		initializeDriver();
		
		//save default parameters (if no one is present)
		saveParameters();
		
		//stop driver (wait for init)
		stopDriver();
	}
	
	/**
	 * Method to load parameters
	 */
	public void loadParameters() {
		//load channels 
		setLeftOutputChannel(getOutputChannel(AsioParameterHelper.getLeftOutput()));
		setRightOutputChannel(getOutputChannel(AsioParameterHelper.getRightOutput()));
		setLeftTHOutputChannel(getOutputChannel(AsioParameterHelper.getLeftTHOutput()));
		setRightTHOutputChannel(getOutputChannel(AsioParameterHelper.getRightTHOutput()));
		// do not allow to have TH output same as PT one
		if (leftTHOutputChannel == leftOutputChannel) {
			setLeftTHOutputChannel(null);
		}
		if (rightTHOutputChannel == rightOutputChannel) {
			setRightTHOutputChannel(null);
		}
	}
	
	/**
	 * method to save parameters
	 */
	public void saveParameters() {
		AsioParameterHelper.setDriverName(driverName);
		AsioParameterHelper.setLeftOutput(leftOutputChannel != null ? leftOutputChannel.getChannelIndex() : -1);
		AsioParameterHelper.setRightOutput(rightOutputChannel != null ? rightOutputChannel.getChannelIndex(): -1);
		AsioParameterHelper.setLeftTHOutput(leftTHOutputChannel != null ? leftTHOutputChannel.getChannelIndex() : -1);
		AsioParameterHelper.setRightTHOutput(rightTHOutputChannel != null ? rightTHOutputChannel.getChannelIndex() : -1);
	}
	
	/**
	 * this method get all channels availables and store it
	 */
	private void discoverChannel() {
		this.inputChannels.clear();
		this.outputChannels.clear();
		if (this.asioDriver != null){
			for(int i = 0; i < this.asioDriver.getNumChannelsInput(); ++i)
				this.inputChannels.add(this.asioDriver.getChannelInput(i));
			for(int i = 0; i < this.asioDriver.getNumChannelsOutput(); ++i)
				this.outputChannels.add(this.asioDriver.getChannelOutput(i));
		}
	}
	
	/**
	 * get the output channel of the current driver for the index passed in parameters
	 * @param index index of the wanted channel
	 * @return the output asio channel
	 */
	public AsioChannel getOutputChannel(int index) {
		for(AsioChannel aChannel : this.outputChannels) {
			if(aChannel.getChannelIndex() == index) {
				return aChannel;
			}
		}
		return null;
	}
	
	/**
	 * get the input channel of the current driver for the index passed in parameters
	 * @param index index of the wanted Channel
	 * @return the output asio channel
	 */
	public AsioChannel getInputChannel(int index) {
		for(AsioChannel aChannel : this.inputChannels) {
			if(aChannel.getChannelIndex() == index) {
				return aChannel;
			}
		}
		return null;
	}
	
	/**
	 * this method get the driver index
	 * first driver is at index 0
	 * @return -1 for any error
	 */
	public int getDriverIndex() {
		for(int i = 0; i < getDriverNames().size(); ++i) {
			if(getDriverNames().get(i).equals(getDriverName()))
				return i;
		}
		return -1;
	}

	/**
	 * check if the input channel index is possible
	 * @param channelIndex the channel index
	 * @return true if channel is available, otherwise false
	 */
	public boolean validInputLine(int channelIndex) {
		return channelIndex < inputChannels.size(); 
	}

	/**
	 * check if the output channel index is possible
	 * @param channelIndex the channel index
	 * @return true if channel is available, otherwise false
	 */
	public boolean validOutputLine(int channelIndex) {
		return channelIndex < outputChannels.size(); 
	}
	
	/**
	 * this method stop cleanly the driver
	 */
	public void stopDriver() {
		if (this.asioDriver != null) {
			int count = busCountPerAsioDriver.get(driverName).decrementAndGet();
			if (count == 0) {
				// FIXME we should Lock the following in order to avoid concurrent Asio init.
				// In practive, we assume all calls will be serialized, and thus this is safe.
				try {
					asioDriver.stop();
				} catch (IllegalStateException ignore) {}
				try {
					asioDriver.disposeBuffers();
				} catch (IllegalStateException ignore) {}
				if (this.leListener != null) {
					this.asioDriver.removeAsioDriverListener(leListener);
				}
				try {
					asioDriver.exit();
				} catch (IllegalStateException ignore) {}
				asioDriver.shutdownAndUnloadDriver();
			}
		}
		this.asioDriver = null;
	}
	
	/**
	 * call it to change the driver
	 * @param newDriver the name of the new driver
	 */
	public void changeDriverName(String newDriver) {
		stopDriver();
		driverName = newDriver;
		AsioParameterHelper.setDriverName(driverName);
		initializeDriver();
	}
	
	/**
	 * call the control panel of the Asio's Driver
	 */
	public void controlPanel() {
		this.asioDriver.openControlPanel();
	}
	
	/**
	 * shortcut to "int initializeDriver(double sampleRate)"
	 * @return 0 if all ok
	 */
	public int initializeDriver() {
		return initializeDriver(0);
	}
	
	/**
	 * initialize or reset the driver`
	 * @param sampleRate a double that represent the samplerate we want to set to the asioDriver
	 * 0 for same as the previous frame_rate
	 * @return 0 if all ok
	 */
	public int initializeDriver(double sampleRate) {
		busCountPerAsioDriver.putIfAbsent(driverName, new AtomicInteger(0));
		double previous_frame_rate = sampleRate;
		if (this.asioDriver != null) {
			if (sampleRate == 0) {
				previous_frame_rate = this.asioDriver.getSampleRate();
			}
			stopDriver();
		}
		busCountPerAsioDriver.get(driverName).incrementAndGet();
		this.asioDriver = AsioDriver.getDriver(driverName); // this is safe as long as driverName is same for all instances
		if (this.leListener != null) {
			this.asioDriver.addAsioDriverListener(this.leListener);
		}
		discoverChannel();
		loadParameters();
		Set<AsioChannel> finalSet = new HashSet<AsioChannel>(extraChannel);
		finalSet.addAll(inputChannels);
		finalSet.addAll(outputChannels);
//		if (this.leftOutputChannel != null) {
//			finalSet.add(this.leftOutputChannel);
//		}
//		if (this.rightOutputChannel != null) {
//			finalSet.add(this.rightOutputChannel);
//		}
//		if (this.leftTHOutputChannel != null) {
//			finalSet.add(this.leftTHOutputChannel);
//		}
//		if (this.rightTHOutputChannel != null) {
//			finalSet.add(this.rightTHOutputChannel);
//		}
		if(this.asioDriver.canSampleRate(previous_frame_rate)) {
			this.asioDriver.setSampleRate(previous_frame_rate);
		}
		this.asioDriver.createBuffers(finalSet);
		this.asioDriver.start();
		return 0;
	}
	
	public AsioChannel getLeftOutputChannel() {
		return this.leftOutputChannel;
	}
	
	public AsioChannel getRightOutputChannel() {
		return this.rightOutputChannel;
	}
	
	public void setLeftOutputChannel(AsioChannel aChannel) {
		this.leftOutputChannel = aChannel;
		AsioParameterHelper.setLeftOutput(aChannel != null ? aChannel.getChannelIndex() : -1);
	}
	
	public void setRightOutputChannel(AsioChannel aChannel) {
		this.rightOutputChannel = aChannel;
		AsioParameterHelper.setRightOutput(aChannel != null ? aChannel.getChannelIndex() : -1);
	}
	
	public AsioChannel getLeftTHOutputChannel() {
		return this.leftTHOutputChannel;
	}
	
	public AsioChannel getRightTHOutputChannel() {
		return this.rightTHOutputChannel;
	}
	
	public void setLeftTHOutputChannel(AsioChannel aChannel) {
		this.leftTHOutputChannel = aChannel;
		AsioParameterHelper.setLeftTHOutput(aChannel != null ? aChannel.getChannelIndex() : -1);
	}
	
	public void setRightTHOutputChannel(AsioChannel aChannel) {
		this.rightTHOutputChannel = aChannel;
		AsioParameterHelper.setRightTHOutput(aChannel != null ? aChannel.getChannelIndex() : -1);
	}
	
	public boolean containsExtraChannel(AsioChannel aChannel) {
		return this.extraChannel.contains(aChannel);
	}
	
	public boolean addExtraChannel(AsioChannel aChannel) {
		return this.extraChannel.add(aChannel);
	}
	
	public boolean removeExtraChannel(AsioChannel aChannel) {
		return this.extraChannel.remove(aChannel);
	}
	
	static public List<String> getDriverNames() {
		return AsioDriver.getDriverNames();
	}
	
	public String getDriverName() {
		return driverName;
	}
	
	public double getSampleRate() {
		return this.asioDriver.getSampleRate();
	}

	public int getBufferSize() {
		return this.asioDriver.getBufferPreferredSize();
	}

	public List<AsioChannel> getOutputChannels() {
		return this.outputChannels;
	}
	
	public List<AsioChannel> getInputChannels() {
		return this.inputChannels;
	}
	
	public void addAsioDriverListener(AsioDriverListener unListener) {
		this.leListener = unListener;
	}
	
	public void setSampleRate(double sampleRate) {
		this.asioDriver.setSampleRate(sampleRate);
	}

	public boolean isRunning() {
		AsioDriverState state = this.asioDriver.getCurrentState();
		return state == AsioDriverState.RUNNING;
	}
}
