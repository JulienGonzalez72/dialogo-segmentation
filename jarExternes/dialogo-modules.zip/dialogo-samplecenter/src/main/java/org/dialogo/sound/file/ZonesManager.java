/**
 * 
 */
package org.dialogo.sound.file;

import java.util.ArrayList;
import java.util.List;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe encapsulant la logique de la gestion du temps.
 * @author C&eacute;drik LIME
 */
public class ZonesManager {
	public static final float DEFAULT_FRAMES_PER_SECOND = 48000.0f;

	private static final Log _log = LogFactory.getLog(ZonesManager.class);

	protected List<Zone> zones;
	// nombre total de frames dans cet extrait
	protected long totalFrames = 0;
	protected float sampleRate = DEFAULT_FRAMES_PER_SECOND;

	public ZonesManager(List<Zone> zones) {
		super();
		assert zones != null;
		this.zones	= zones;
		Zone lastZone = zones.get(zones.size()-1);
		totalFrames = lastZone.getEnd();//FIXME may not be the same as end of file!
	}
	public ZonesManager(List<Zone> zones, int sampleRate) {
		this(zones);
		setSampleRate(sampleRate);
	}

	public List<Zone> getZones() {
		return new ArrayList<Zone>(zones);
	}

	/**
	 * @param sampleRate in Hz
	 */
	public void setSampleRate(int sampleRate) {
		if (sampleRate > 0) {
			this.sampleRate = sampleRate;
		} else {
			_log.warn("Invalid sample rate requested: " + sampleRate + "; defaulting to " + (int)DEFAULT_FRAMES_PER_SECOND + "Hz");
		}
	}

	/**
	 * @param zoneNumber
	 * @return position de l'extrait sonore correspondant au d�but de la phrase, en millisecondes
	 */
	public long getStartTime(int zoneNumber) {
		Zone zone = zones.get(zoneNumber);
		return getStartTime(zone);
	}
	/**
	 * @param zone
	 * @return position de l'extrait sonore correspondant au d�but de la phrase, en millisecondes
	 */
	public long getStartTime(Zone zone) {
		return (long) (DateUtils.MILLIS_PER_SECOND * (zone.getBegin() / sampleRate));
	}

	/**
	 * @param zoneNumber
	 * @return position de l'extrait sonore correspondant � la fin de la phrase, en millisecondes
	 */
	public long getEndTime(int zoneNumber) {
		Zone zone = zones.get(zoneNumber);
		return getEndTime(zone);
	}
	/**
	 * @param zone
	 * @return position de l'extrait sonore correspondant � la fin de la phrase, en millisecondes
	 */
	public long getEndTime(Zone zone) {
		return (long) (DateUtils.MILLIS_PER_SECOND * (zone.getEnd() / sampleRate));
	}

	/**
	 * @param zoneNumber
	 * @return position de l'extrait sonore correspondant au d�but de la phrase, en %
	 */
	public float getStartPercent(int zoneNumber) {
		Zone zone = zones.get(zoneNumber);
		return ((float) zone.getBegin()) / totalFrames;
	}

	/**
	 * @param zoneNumber
	 * @return la dur�e du son li� au la phrase n� sentenceNumber, en millisecondes
	 */
	public long getZoneDuration(int zoneNumber) {
		Zone zone = zones.get(zoneNumber);
		return getZoneDuration(zone);
	}
	/**
	 * @param zone
	 * @return la dur�e du son li� au la phrase n� sentenceNumber, en millisecondes
	 */
	public long getZoneDuration(Zone zone) {
		long nbEchantillons = zone.getEnd() - zone.getBegin();
		return (long) (DateUtils.MILLIS_PER_SECOND * nbEchantillons / sampleRate);
	}

	/**
	 * @param posMilliseconds
	 * @return current zone number, or {@code -1} if position is outside range
	 */
	public int getCurrentZoneNumber(long posMilliseconds) {
		int zoneIndex = 0;
		try {
			while (getEndTime(zoneIndex) < posMilliseconds) {
				++zoneIndex;
			}
			return zoneIndex;
		} catch (IndexOutOfBoundsException e) {
			return -1;
		}
	}

	/**
	 * @param posMilliseconds
	 * @return current zone, or {@code null} if position is outside range
	 */
	public Zone getCurrentZone(long posMilliseconds) {
		int zoneIndex = getCurrentZoneNumber(posMilliseconds);
		if (zoneIndex == -1) {
			return null;
		} // else
		return zones.get(zoneIndex);
	}

	/**
	 * @param zone
	 * @return previous zone, or {@code null} if none
	 */
	public Zone getPreviousZone(Zone zone) {
		assert zones.contains(zone);
		int zoneIndex = zones.indexOf(zone);
		try {
			return zones.get(zoneIndex - 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}

	/**
	 * @param zone
	 * @return next zone, or {@code null} if none
	 */
	public Zone getNextZone(Zone zone) {
		assert zones.contains(zone);
		int zoneIndex = zones.indexOf(zone);
		try {
			return zones.get(zoneIndex + 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}

	/** {@inheritDoc} */
	@Override
	public String toString() {
		StringBuilder result = new StringBuilder(512);
		result.append(getClass().getName()).append("[frameRate=").append(sampleRate).append(SystemUtils.LINE_SEPARATOR);
		for (Zone zone : zones) {
			result.append(zone.toString(sampleRate)).append(SystemUtils.LINE_SEPARATOR);
		}
		result.append(']');
		return result.toString();
	}

}
