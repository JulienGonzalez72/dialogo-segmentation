/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author obicho
 */
public class SampleLocator implements ISampleLocator {

	protected final String samplesRootPath;
	//private final String autoTextsRootPath;
	private List<Mp3Wrapper> mp3FilesList;
	private static final Log log = LogFactory.getLog(SampleLocator.class);
	private List<String> langsInProps;

	public SampleLocator(String samplesRootPath) {
		this.samplesRootPath = samplesRootPath;
		//this.autoTextsRootPath=autoTextsRootPath;
	}

	@Override
	public List<Mp3Wrapper> getSamplesByPhaseTypeFilter(String name) {
		log.debug("getSamplesByPhaseTypeFilter " + name);
		String s = segmentationForFilter(name);
		log.debug(" segmentation=" + s);
		String type=null;
		if("MP".equals(name))type=Mp3Wrapper.MUSIC_TYPE;
		if(name==null&&name.startsWith("VP"))type="";
		List<Mp3Wrapper> l = getSamplesBySegmentationAndType(s, type);
		if (l == null) {
			log.debug("erreur l=null");
		} else {
			log.debug(l.size() + " samples");
		}
		return l;
	}
	@Override
	public List<Mp3Wrapper> getSamplesBySegmentation(String name) {
		return getSamplesBySegmentationAndType(name, null);
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationAndType(String segm, String type) {
		if (segm == null) {
			return null;
		}
		//if("".equals(type))type=null;
		List<Mp3Wrapper> list = getMp3FilesList();
		List<Mp3Wrapper> l = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			Mp3Wrapper m = list.get(i);
			if (segm.equals(m.getSegmentation()) && (type==null||type.equals(m.getTypeProperty()))) {
				l.add(m);
			}
		}
		return l;
	}

	/**
	 * conversion from old 'SAMPLEFILTER' column in 'PHASETYPE' table; temporary
	 * useful, if segmentation is not defined
	 *
	 * @param filter
	 * @return segmentation
	 */
	@Override
	public String segmentationForFilter(String filter) {
		log.debug("segmentationForFilter " + filter);
		return SampleCenter.filters().getSegmentationFromFiltre(filter);
	}

	@Override
	public List<Mp3Wrapper> getMp3FilesList() {
		return getMp3FilesList(true);
	}

	@Override
	public List<Mp3Wrapper> getMp3FilesList(boolean onlyWithProps) {
		if (mp3FilesList == null) {
			log.debug("getMp3FilesList");
			List<Mp3Wrapper> l = new ArrayList<>();
			File samplesDir = new File(samplesRootPath);
			File[] files = samplesDir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					boolean b = true;
					String name = pathname.getName();
					if (!name.endsWith(".mp3")) {
						b = false;
					}
					return b && pathname.isFile() && !pathname.isHidden();
				}
			});
			if (files != null) {
				//Arrays.parallelSort(files, NameFileComparator.NAME_INSENSITIVE_COMPARATOR);
				for (int i = 0; i < files.length; ++i) {
					File file = files[i];
					Mp3Wrapper s = new Mp3Wrapper(file);
					if (!onlyWithProps || s.hasProperties()) {
						l.add(s);
					}
				}
				Collections.sort(l, new Comparator<Mp3Wrapper>() {
					@Override
					public int compare(Mp3Wrapper o1, Mp3Wrapper o2) {
						if(o1==null&&o2==null)return 0;
						if(o1==null||o1.getName()==null)return -1;
						if(o2==null||o2.getName()==null)return 1;
						return o1.getName().compareToIgnoreCase(o2.getName());
					}
				});
			}else{
				log.warn("files==null for samplesRootPath="+samplesRootPath);
			}
			log.debug(l.size() + " lines");
			//sort
			mp3FilesList = l;
		}
		return mp3FilesList;
	}

	@Override
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String filter, int textLevel) {
		log.debug("getSamplesBySegmentationAndTextLevel filter=" + filter + " level=" + textLevel);
		String type="";
		if("MP".equals(filter))type=Mp3Wrapper.MUSIC_TYPE;
		return getSamplesBySegmentationTypeAndTextLevel(segmentationForFilter(filter), type, textLevel);
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationTypeAndTextLevel(String segmentation, String type, int textLevel) {
		log.debug("getSamplesBySegmentationAndTextLevel segmentation=" + segmentation + " level=" + textLevel);
		if (segmentation == null) {
			return null;
		}
		if (textLevel < 0 || textLevel > 8) {
			return null;
		}
		List<Mp3Wrapper> list = getMp3FilesList();
		List<Mp3Wrapper> l = new ArrayList<>();
		for (int i = 0; i < list.size(); i++) {
			Mp3Wrapper m = list.get(i);
			log.debug(m.getName() + " -> " + m.getLevel());
			if (segmentation.equals(m.getSegmentation()) && textLevel == m.getLevel() && (type==null||type.equals(m.getTypeProperty()))) {
				l.add(m);
			}
		}
		log.debug("  " + l.size() + " elements");
		return l;
	}

	@Override
	public Mp3Wrapper findByName(String name) {
		if (name == null) {
			log.debug("findByName : name=null");
			return null;
		}
		/*List<Mp3Wrapper> l = getMp3FilesList();
		for (int i = 0; i < l.size(); i++) {
		Mp3Wrapper s = l.get(i);
		if(name.equals(s.getName()))return s;
		}
		return null;*/
		List<Mp3Wrapper> l = getSamplesByName(name);
		if (l == null) {
			return null;
		}
		log.debug("findByName " + name + " found " + l.size());
		if (l.isEmpty()) {
			return null;
		}
		return l.get(0);
	}

	@Override
	public Mp3Wrapper findByFileName(String name) {
		if (name == null) {
			return null;
		}
		List<Mp3Wrapper> l = getMp3FilesList();
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper s = l.get(i);
			if (name.equals(s.getFileName())) {
				log.debug("findByFileName " + name + " found");
				return s;
			}
		}
		log.debug("findByFileName " + name + " not found");
		return null;
	}

	@Override
	public Mp3Wrapper findByUid(String uidsample) {
		if (uidsample == null) {
			return null;
		}
		List<Mp3Wrapper> l = getMp3FilesList();
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper s = l.get(i);
			if (uidsample.equals(s.getUid())) {
				return s;
			}
		}
		return null;
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationAndTextLevel(String name, String textLevel) {
		return getSamplesBySegmentationTypeAndTextLevel(name, "", stringTextLevelToInt(textLevel));
	}

	@Override
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String name, String textLevel) {
		return getSamplesByFilterAndTextLevel(name, stringTextLevelToInt(textLevel));
	}

	private int stringTextLevelToInt(String s) {
		log.debug("stringTextLevelToInt " + s);
		if (s == null) {
			log.debug(" -> 0");
			return 0;
		}
		if (s.startsWith("NIV")) {
			s = s.substring(3);
		}
		try {
			int n = Integer.parseInt(s);
			log.debug(" -> " + n);
			return n;
		} catch (NumberFormatException e) {
			log.debug(" -> 0");
			return 0;
		}
	}

	@Override
	public List<Mp3Wrapper> getSamplesByName(String name) {
		if (name == null) {
			log.debug("getSamplesByName : name=null");
			return null;
		}
		List<Mp3Wrapper> l = getMp3FilesList();
		List<Mp3Wrapper> l1 = new ArrayList<>();
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper s = l.get(i);
			String n = s.getName();
			if (n == null) {
				n = "";
			}
			n = n.trim();

			if (name.trim().equalsIgnoreCase(n)) {
				l1.add(s);
			}
		}
		return l1;
	}

	@Override
	public List<String> getLanguagesInProperties() {
		if(langsInProps==null){
			List<Mp3Wrapper> l = getMp3FilesList(true);
			langsInProps=new ArrayList<>();
			for (int i = 0; i < l.size(); i++) {
				Mp3Wrapper w = l.get(i);
				if(!langsInProps.contains(w.getLanguage())){
					langsInProps.add(w.getLanguage());
				}
			}
		}
		return langsInProps;
	}

}
