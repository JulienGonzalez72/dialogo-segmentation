package fr.lexiphone.player.impl.jasiohost.bus;

public abstract class LeaderBus extends BaseBus{
	
	protected BusListener theListener = null;
	
	public LeaderBus(String name) {
		super(name);
	}

	/**
	 * get the buffer size of the bus
	 * @return the buffer size
	 */
	public abstract int getBufferSize();
	
	/**
	 * listen when the bus need to refresh his own buffer
	 * @param aListener
	 */
	public void setBusListener(BusListener aListener) {
		theListener = aListener;
	}
}
