package fr.lexiphone.reusable.util.i18n;

/**
 * @author clime
 */
public class ThreadUtils {

	/**
	 * 
	 */
	private ThreadUtils() {
		super();
	}

	/**
	 * Use when you can't use Thread.sleep(millis);
	 * @param millis
	 */
	public static void activeWait(final long millis) {
		//Thread.sleep(millis);
		// new Thread in case we are called from AWT thread (bugger, should be done at client layer...)
		// Bug: can't put  Thread.wait() here (IllegalMonitorStateException: current thread not owner), bugger.
		Thread thread = new Thread("ActiveWaiting thread") {
			public void run() {
				Thread.yield();
				final long startTime = System.currentTimeMillis();
				while (System.currentTimeMillis() - startTime < millis) {
					for (int i=0; i<200000; ++i); // yuck!
				}
			}
		};
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();
		try {
			thread.join();
		} catch (InterruptedException ie) {
		}
	}
}
