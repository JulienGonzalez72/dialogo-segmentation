/**
 * 
 */
package fr.lexiphone.entreprise.workmodule;

/**
 * @author C&eacute;drik LIME
 */
public enum PlayerState {
	PLAYING, PAUSED, STOPPED, INTRO_PLAYING, INTRO_FINISHED, INTRO_PAUSED
}
