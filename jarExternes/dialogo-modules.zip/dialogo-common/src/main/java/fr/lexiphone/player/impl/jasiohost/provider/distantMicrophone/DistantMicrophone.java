package fr.lexiphone.player.impl.jasiohost.provider.distantMicrophone;

import java.io.IOException;
import java.io.ObjectInput;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;

import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;

public class DistantMicrophone extends BaseProvider implements AutoCloseable {
	
	public static String ID = "Distant Mic";
	
	private ObjectInput ois = null;
	
	private InetSocketAddress remote;
	private ServerSocket socket;
	private Socket clientSocket;
	
	public DistantMicrophone(){
		super(ID);
	}

	public void connect(InetSocketAddress remote) {
		this.remote = remote;
		init(null);
	}

	@Override
	public void close() throws IOException {
		if (clientSocket != null) {
			clientSocket.close();
		}
	}

	@Override
	public void refreshBuffer(int bufferSize) {
		if (ois == null) {
			return;
		}
		try {
			this.outputBuffer.setLeftChannel((float[])ois.readObject());
			this.outputBuffer.setRightChannel((float[])ois.readObject());
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void init(BaseBus aBus) {
		// Create the server socket channel
		ServerSocketChannel server;
		try {
			server = ServerSocketChannel.open();
			// nonblocking I/O
			server.configureBlocking(false);
			// host-port 8000
			server.socket().bind(new InetSocketAddress(6969));//FIXME magic number; find free port instead.
			// Create the selector
			Selector selector = Selector.open();
			// Recording server to selector (type OP_ACCEPT)
			server.register(selector,SelectionKey.OP_ACCEPT);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


/*
		Selector selector = Selector.open();
		channel.configureBlocking(false);
		SelectionKey key = channel.register(selector, SelectionKey.OP_READ);

		while(true) {
		  int readyChannels = selector.select();
		  if(readyChannels == 0) continue;

		  Set<SelectionKey> selectedKeys = selector.selectedKeys();
		  Iterator<SelectionKey> keyIterator = selectedKeys.iterator();
		  while(keyIterator.hasNext()) {
		    SelectionKey key = keyIterator.next();
		    if(key.isAcceptable()) {
		        // a connection was accepted by a ServerSocketChannel.

		    } else if (key.isConnectable()) {
		        // a connection was established with a remote server.

		    } else if (key.isReadable()) {
		        // a channel is ready for reading

		    } else if (key.isWritable()) {
		        // a channel is ready for writing
		    }

		    keyIterator.remove();
		  }
		}
*/
	}

	@Override
	public void sampleRateChanged(double sampleRate, BaseBus aBus) {}

	@Override
	public boolean changeFrameRateOfRegisteredBus() {return true;}
}
