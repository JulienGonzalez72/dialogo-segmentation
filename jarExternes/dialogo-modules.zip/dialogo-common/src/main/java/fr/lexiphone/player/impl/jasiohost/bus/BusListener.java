package fr.lexiphone.player.impl.jasiohost.bus;

public interface BusListener {

	void bufferSwitch();
	void bufferSizeChanged(int newBufferSize);

}
