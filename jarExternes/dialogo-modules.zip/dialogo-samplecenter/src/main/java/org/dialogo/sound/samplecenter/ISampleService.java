/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.util.Map;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author obicho
 */
public interface ISampleService {

	public void deleteSample(Mp3Wrapper sample);
	//public List<Long> getSentencesStartTimes(String filename);

	public void renameSample(Mp3Wrapper sample, String newName);

	/**
	 *
	 * @return map : mp3 name => uid
	 */
	public Map<String,String> checkAllMp3Properties();

	//public Map<String, String> getMp3PropertiesAsStrings(List<String> mp);

}
