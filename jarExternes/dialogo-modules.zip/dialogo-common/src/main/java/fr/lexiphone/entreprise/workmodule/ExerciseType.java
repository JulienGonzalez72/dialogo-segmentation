/**
 * 
 */
package fr.lexiphone.entreprise.workmodule;

/**
 * @author C&eacute;drik LIME
 */
public enum ExerciseType {
	AUDIO, REPETITIONECRITE, LECTUREANTICIPEE, LECTUREGUIDEE, DICTEE, LL, REGLAGES;
}
