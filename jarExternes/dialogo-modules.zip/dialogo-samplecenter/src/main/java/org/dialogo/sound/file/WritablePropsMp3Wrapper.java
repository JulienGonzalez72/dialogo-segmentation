/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.file;

import java.io.File;
import java.util.Properties;

/**
 * 
 * @author haerwynn
 */
public class WritablePropsMp3Wrapper extends Mp3Wrapper{

	public WritablePropsMp3Wrapper(File file) {
		super(file);
	}

	public WritablePropsMp3Wrapper(Mp3Wrapper mp3) {
		super(mp3.getFile());
	}

	public void setProperties(Properties properties) {
		if(props==null)props=new Properties();
		props.putAll(properties);
	}

	public void saveProperty(String key, String value) {
		if(props==null)props=new Properties();
		props.setProperty(key, value);
		saveProperties();
	}
	public void saveAllProperties(){
		saveProperties();
	}
}
