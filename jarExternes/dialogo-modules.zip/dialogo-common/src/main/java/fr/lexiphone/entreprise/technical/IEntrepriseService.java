
package fr.lexiphone.entreprise.technical;

/**
 * <P>
 *  Interface de marquage des services Entreprise.
 * </P>
 * @author pprimot
 */

public interface IEntrepriseService {

}
