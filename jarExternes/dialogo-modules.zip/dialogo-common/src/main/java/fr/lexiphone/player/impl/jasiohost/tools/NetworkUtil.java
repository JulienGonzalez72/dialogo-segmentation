package fr.lexiphone.player.impl.jasiohost.tools;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Collections;
import java.util.regex.Pattern;

public class NetworkUtil {
	
	public static void printAllInterfaces() {
		try {
			for (NetworkInterface netint : Collections.list(NetworkInterface.getNetworkInterfaces())) {
				displayInterfaceInformation(netint);
			}
		} catch (SocketException e) {
			e.printStackTrace();
		}
	}
	
	public static InetAddress autoSelectInterface() {
		try {
			for (NetworkInterface netint : Collections.list(NetworkInterface.getNetworkInterfaces())) {
				for (InetAddress inetAddress : Collections.list(netint.getInetAddresses())) {
					if(!Pattern.compile("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b").matcher(inetAddress.getHostAddress()).matches()) {
		            	continue;
		            } else {
		            	if(!BadIP.isBad(inetAddress.getHostAddress()))
		            		return inetAddress;
		            }
		            
		        }
			}
		} catch (SocketException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static void displayInterfaceInformation(NetworkInterface netint) throws SocketException {
        System.out.printf("Display name: %s\n", netint.getDisplayName());
        System.out.printf("Name: %s\n", netint.getName());
        for (InetAddress inetAddress : Collections.list(netint.getInetAddresses())) {
            System.out.printf("InetAddress: %s\n", inetAddress.getHostAddress());
        }
        System.out.printf("\n");
     }

}
