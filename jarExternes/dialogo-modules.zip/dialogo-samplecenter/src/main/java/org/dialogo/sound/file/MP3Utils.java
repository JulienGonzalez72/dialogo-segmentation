/**
 * 
 */
package org.dialogo.sound.file;

import helliker.id3.ID3Exception;
import helliker.id3.MP3File;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author C&eacute;drik LIME
 */
public class MP3Utils {
	protected static Log _log = LogFactory.getLog(MP3Utils.class);

	/**
	 * 
	 */
	private MP3Utils() {
		throw new AssertionError();
	}

	private static void assertFileExist(File file) throws FileNotFoundException {
		if (!file.exists()) {
			throw new FileNotFoundException(file.toString());
		}
	}

	/**
	 * Returns the title of this mp3 if set and the empty string if not.
	 *
	 * @param soundFile
	 * @return the title of this mp3
	 * @throws FileNotFoundException
	 */
	public static String getTitle(File soundFile) throws FileNotFoundException, IOException {
		assertFileExist(soundFile);
		String result = "";
		try {
			MP3File lc_mp3 = new MP3File(soundFile);
			String lc_titre = lc_mp3.getTitle();
			//String lc_niveauPK = lc_mp3.getGenre();
			//String lc_commentaire = lc_mp3.getComment();
			//String lc_artiste = lc_mp3.getArtist();
			//int lc_duration = (int) lc_mp3.getPlayingTime();
			//String lc_durationStr = "" + (lc_duration/60) + ':' + (lc_duration % 60);
			result = lc_titre;
		} catch (ID3Exception id3e) {
			throw new FileNotFoundException(id3e.getLocalizedMessage());
		}
		return result;
	}

	/**
	 * Returns the sample rate of this mp3 in Hz.
	 *
	 * @param soundFile
	 * @return the sample reate of this mp3 in Hz
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	public static int getSampleRate(File soundFile) throws FileNotFoundException, IOException {
		assertFileExist(soundFile);
		try {
			MP3File lc_mp3 = new MP3File(soundFile);
			return lc_mp3.getSampleRate();
		} catch (ID3Exception id3e) {
			throw new FileNotFoundException(id3e.getLocalizedMessage());
		}
	}

	public static File getMaRKerFile(File soundFile) {
		if (! soundFile.exists()) {
			throw new IllegalArgumentException("Can not read sound file: " + soundFile);
		}
		// Grab MaRKer data
		File markerFile = new File(soundFile.getPath().subSequence(0, soundFile.getPath().lastIndexOf('.')) + ".MRK");
		if (! markerFile.exists() || ! markerFile.canRead()) {
			return null;
		} else {
			return markerFile;
		}
	}

	public static ZonesWithPauseManager getZonesWithPauseManager(Mp3Wrapper soundFile, float autoPauseFactor, int autoPauseConstantMillis) throws FileNotFoundException, IOException {
		/*if (! soundFile.exists() || ! soundFile.canRead()) {
			throw new IllegalArgumentException("Can not read sound file: " + soundFile);
		}*/
		// Grab MaRKer data
		File markerFile = soundFile.getMaRKerFile();
		if (markerFile == null || ! markerFile.canRead()) {
			_log.debug("Non-existant MaRKer file: " + markerFile +" for mp3 "+soundFile.getName());
			return null;
		}
		List<Zone> zones = MaRKerFileReader.loadZonesFromMarkerFile(markerFile);
		if (zones == null || zones.isEmpty()) {
			throw new IllegalArgumentException("Bad MaRKer file: " + markerFile);
		}
		ZonesManager zonesManager = new ZonesManager(zones);
		ZonesWithPauseManager zonesWithPauseManager = new ZonesWithPauseManager(zones, autoPauseFactor, autoPauseConstantMillis);
		{
			int sampleRate = soundFile.getMp3SampleRate();
			zonesManager.setSampleRate(sampleRate);
			zonesWithPauseManager.setSampleRate(sampleRate);
			_log.trace("sample rate: " + sampleRate);
		}
		/*if (_log.isDebugEnabled()) {
			_log.debug("All zones: " + zonesManager.toString());
		}*/
		_log.trace("" + zones.size() + " zones");
		_log.trace("Duration: " + zonesWithPauseManager.getTotalDuration(0) + " ms");
		return zonesWithPauseManager;
	}
	public static boolean hasMarkerFile(String absoluteFileName){
		File markerFile = getMaRKerFile(new File(absoluteFileName));
		if (markerFile == null || ! markerFile.canRead()) {
			_log.debug("Non-existant MaRKer file: " + markerFile);
			return false;
		}
		return true;
	}
}
