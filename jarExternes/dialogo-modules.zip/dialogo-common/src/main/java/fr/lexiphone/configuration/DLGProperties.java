/**
 * 
 */
package fr.lexiphone.configuration;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.io.IOUtils;

/**
 * @author C&eacute;drik LIME
 * @deprecated use Configuration instead
 */
//TODO (C�drik) get the right code in there!
@Deprecated
public class DLGProperties extends Properties {

	public DLGProperties() {
		super();
	}

	public DLGProperties(Properties defaults) {
		super(defaults);
	}

	public DLGProperties(String file) {
		init(file);
	}
	
	public DLGProperties(String file, Properties defaults) {
		super(defaults);
		init(file);
	}

	protected void init(String file) {
		InputStream in = this.getClass().getResourceAsStream(file);
		if (in != null) {
			// load from classpath
			try {
				load(in);
			} catch (IOException e) {
				throw new IllegalStateException(
						"Can not load file from classpath: " + file, e);
			} finally {
				IOUtils.closeQuietly(in);
			}
		} else {
			try {
				in = new FileInputStream(new File(file));
			} catch (FileNotFoundException ignore) {
			}
			if (in != null) {
				// load from filesystem
				try {
					load(in);
				} catch (IOException e) {
					throw new IllegalStateException(
							"Can not load file from filesystem: " + file, e);
				} finally {
					IOUtils.closeQuietly(in);
				}
			} else {
				// error
				throw new IllegalStateException(
						"Can not find file neither in classpath nor in filesystem: "
								+ file);
			}
		}
	}

	/**
	 * {@inheritDoc}
	 * <p>
	 * Looks up in System properties before looking up in this property list.
	 */
	@Override
	public String getProperty(String key) {
		String value = System.getProperty(key);
		if (value == null) {
			value = super.getProperty(key);
		}
		return value;
	}

	/************************************************************************/

}
