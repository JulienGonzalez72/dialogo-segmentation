package fr.lexiphone.player.impl.jasiohost.provider.microphone;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.util.Enumeration;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.event.ChangeListener;

import com.synthbot.jasiohost.AsioChannel;

import fr.lexiphone.player.impl.jasiohost.ihm.ConfigIhm;

@SuppressWarnings("serial")
public class MicrophoneIhm extends ConfigIhm {

	private JPanel jPanelButton = null;
	private JButton jButtonOk = null;
	private JButton jButtonCancel = null;
	private JPanel jPanelNoise = null; 
//	private JLabel jLabelNoise = null;
	private JCheckBox jSliderNoise = null;
	private ButtonGroup buttonGroupLeft = null;
	private ButtonGroup buttonGroupRight = null;
	private JPanel jPanelLine = null;
	private JPanel jPanelLineLeft = null;
	private JPanel jPanelLineRight = null;

	/**
	 * This method initializes 
	 * 
	 */
	public MicrophoneIhm() {
		super();
	}

	/**
	 * This method initializes this
	 * 
	 */
	@Override
	public void initAndShowIhm() {
        this.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 20));
        this.setSize(new Dimension(450, 350));
        this.add(getJPanelNoise());
        this.add(getJPanelSoundLevelBoost());
        this.add(getJPanelLine());
        this.add(getJPanelButton());
		setVisible(true);	
	}

	/**
	 * This method initializes jPanelButton	
	 * 	
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelButton() {
		if (jPanelButton == null) {
			jPanelButton = new JPanel();
			jPanelButton.setLayout(new BorderLayout());
			jPanelButton.add(getJButtonOk(), BorderLayout.WEST);
			jPanelButton.add(getJButtonCancel(), BorderLayout.EAST);
		}
		return jPanelButton;
	}

	/**
	 * This method initializes jButtonOk	
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonOk() {
		if (jButtonOk == null) {
			jButtonOk = new JButton();
			jButtonOk.setText("OK");	
		}
		return jButtonOk;
	}
	
	public void addActionToOkButton(ActionListener anActionListener) {
		getJButtonOk().addActionListener(anActionListener);
	}

	/**
	 * This method initializes jButtonCancel
	 * 	
	 * @return javax.swing.JButton	
	 */
	private JButton getJButtonCancel() {
		if (jButtonCancel == null) {
			jButtonCancel = new JButton();
			jButtonCancel.setText("Cancel");
			jButtonCancel.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
		}
		return jButtonCancel;
	}

	/**
	 * This method initializes jPanelNoise	
	 * 	
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelNoise() {
		if (jPanelNoise == null) {
			jPanelNoise = new JPanel();
			jPanelNoise.setLayout(new BorderLayout());
			JLabel jLabel = new JLabel();
			jLabel.setText("Noise Reduction : ");
			jPanelNoise.add(jLabel, BorderLayout.WEST);
//			jPanelNoise.add(getJLabelNoise(), BorderLayout.CENTER);
//			jPanelNoise.add(getJSliderNoise(), BorderLayout.EAST);
			jPanelNoise.add(getJSliderNoise(), BorderLayout.CENTER);
		}
		return jPanelNoise;
	}
	
	private JCheckBox getJSliderNoise() {
		if(jSliderNoise  == null) {
//			jSliderNoise = new JSlider(SwingConstants.HORIZONTAL);
//			jSliderNoise.setMinimum(0);
//			jSliderNoise.setMaximum(10);
//			jSliderNoise.setValue(0);
//			jSliderNoise.setMajorTickSpacing(2);
//			jSliderNoise.setPaintTicks(true);
//			jSliderNoise.addChangeListener(new ChangeListener() {
//				@Override
//				public void stateChanged(ChangeEvent e) {
//					SwingUtilities.invokeLater(new Runnable() {
//						@Override
//						public void run() {
//							getJLabelNoise().setText(Double.toString(jSliderNoise.getValue()/100.0));
//						}
//					});
//				}
//			});
			jSliderNoise = new JCheckBox("Noise Reduction", true);
		}
		return jSliderNoise;
	}
	
//	private JLabel getJLabelNoise() {
//		if (jLabelNoise == null) {
//			jLabelNoise = new JLabel("0");
//		}
//		return jLabelNoise;
//	}

	/**
	 * This method initializes jPanelLine	
	 * 	
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelLine() {
		if (jPanelLine == null) {
			jPanelLine = new JPanel();
			jPanelLine.setLayout(new BorderLayout());
			jPanelLine.add(getJPanelLineLeft(), BorderLayout.WEST);
			jPanelLine.add(getJPanelLineRight(), BorderLayout.EAST);
			
		}
		return jPanelLine;
	}
	
	public void addInputLine(ActionListener anActionLeft, ActionListener anActionRight, List<AsioChannel> inputChannels) {
		buttonGroupLeft = new ButtonGroup();
		buttonGroupRight = new ButtonGroup();
		DecimalFormat aFormat = new DecimalFormat("00");
		
		for (AsioChannel aChannel : inputChannels) {
			JRadioButtonMenuItem lineLeftCheckBox = new JRadioButtonMenuItem(
					aChannel.getChannelName().concat(
							" - " + aFormat.format(aChannel.getChannelIndex())));
			buttonGroupLeft.add(lineLeftCheckBox);
			getJPanelLineLeft().add(lineLeftCheckBox);
			lineLeftCheckBox.addActionListener(anActionLeft);
			
			JRadioButtonMenuItem lineRightCheckBox = new JRadioButtonMenuItem(
					aChannel.getChannelName().concat(
							" - " + aFormat.format(aChannel.getChannelIndex())));
			buttonGroupRight.add(lineRightCheckBox);
			getJPanelLineRight().add(lineRightCheckBox);
			
			lineRightCheckBox.addActionListener(anActionRight);
		}
	}

	/**
	 * This method initializes jPanelLineLeft	
	 * 	
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelLineLeft() {
		if (jPanelLineLeft == null) {
			jPanelLineLeft = new JPanel();
			jPanelLineLeft.setLayout(new GridLayout(0,1));
		}
		return jPanelLineLeft;
	}

	/**
	 * This method initializes jPanelLineRight	
	 * 	
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelLineRight() {
		if (jPanelLineRight == null) {
			jPanelLineRight = new JPanel();
			jPanelLineRight.setLayout(new GridLayout(0,1));
		}
		return jPanelLineRight;
	}
	
	public boolean getNoiseReduction() {
//		return Double.parseDouble(getJLabelNoise().getText());
		return getJSliderNoise().isSelected();
	}

	public void selectLeftLine(AsioChannel aChannel) {
		selectButtonInGroup(aChannel, buttonGroupLeft);
	}
	
	public void selectRightLine(AsioChannel aChannel) {
		selectButtonInGroup(aChannel, buttonGroupRight);
	}
	
	private void selectButtonInGroup(AsioChannel anAsioChannel,
			ButtonGroup aGroup) {
		Enumeration<AbstractButton> elements = aGroup.getElements();
		AbstractButton anElement = null;
		String aText = null;
		while (elements.hasMoreElements()) {
			anElement = elements.nextElement();
			aText = anElement.getText();
			if (anAsioChannel.getChannelIndex() == Integer.parseInt(aText.substring(aText.length() - 2),10)) {
				anElement.setSelected(true);
				break;
			}
		}
	}

	public void addNoiseChangeListener(ChangeListener changeListener) {
		getJSliderNoise().addChangeListener(changeListener);
	}
	
	public void setNoiseReduction(boolean aValue) {
//		getJSliderNoise().setValue((int)(aValue * 100));
		getJSliderNoise().setSelected(aValue);
	}
}
