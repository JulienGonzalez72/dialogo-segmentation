package fr.lexiphone.player.impl.jasiohost.provider.microphone;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;

import javax.swing.JOptionPane;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.synthbot.jasiohost.AsioChannel;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.bus.asio.Asio;
import fr.lexiphone.player.impl.jasiohost.bus.asio.AsioBus;
import fr.lexiphone.player.impl.jasiohost.ihm.ConfigIhm;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import fr.lexiphone.player.impl.jasiohost.tools.ButterworthFilterOrder2Highpass150Freq48000;
import fr.lexiphone.player.impl.jasiohost.tools.ButterworthFilterOrder2Lowpass4000Freq48000;
import fr.lexiphone.player.impl.jasiohost.tools.parameters.Parameters;

abstract class AbstractMicrophone extends BaseProvider {

	private final static String INPUT_LEFT = "input.left";
	private final static String INPUT_RIGHT = "input.right";
	protected final static String SOUND_BOOST = "soundLevelBoost";
	
	private Asio asioDriver = null;
	private String driverName = null;
	private AsioChannel leftChannel = null;
	private AsioChannel rightChannel = null;
	
	private float [] outputLeft = null;
	private float [] outputRight = null;

	/* 2 filters high- and low-pass, as there are sound distorsions when using a single band-pass */
	private ButterworthFilterOrder2Highpass150Freq48000 leftFilter1 = new ButterworthFilterOrder2Highpass150Freq48000();
	private ButterworthFilterOrder2Lowpass4000Freq48000 leftFilter2 = new ButterworthFilterOrder2Lowpass4000Freq48000();
	private ButterworthFilterOrder2Highpass150Freq48000 rightFilter1 = new ButterworthFilterOrder2Highpass150Freq48000();
	private ButterworthFilterOrder2Lowpass4000Freq48000 rightFilter2 = new ButterworthFilterOrder2Lowpass4000Freq48000();
	
	private Map<String, String> properties = null;
	
	protected AbstractMicrophone(String name) {
		super(name);
	}
	
	@Override
	public void init(BaseBus aBus) {
		if (!(aBus instanceof AsioBus))
			throw new IllegalArgumentException(getName() + " can only work on an AsioBus");
		this.asioDriver = ((AsioBus)aBus).getDriver();
		initConfig();
	}
	
	/**
	 * this method get the configuration and set it
	 */
	private void initConfig() {
		this.driverName = this.asioDriver.getDriverName();
		loadParameters();
		if (leftChannel != null)
			this.asioDriver.addExtraChannel(leftChannel);
		if (rightChannel != null)
			this.asioDriver.addExtraChannel(rightChannel);
		this.asioDriver.initializeDriver();
		initIhm();
	}
	
	/**
	 * this methods load the saved parameters
	 */
	private void loadParameters() {
		properties = Parameters.getInstance().getProviderParameters(this);
		String soundLevelBoost = properties.get(SOUND_BOOST);
		String sLeft = properties.get(INPUT_LEFT);
		int left = (sLeft == null ? 0 : Integer.parseInt(sLeft, 10));
		String sRight = properties.get(INPUT_RIGHT);
		int right = (sRight == null ? 1 : Integer.parseInt(sRight, 10));
		
		setSoundLevelBoost(soundLevelBoost == null ? 1.0f : Float.parseFloat(soundLevelBoost));
		setLeftLine(asioDriver.getInputChannel(asioDriver.validInputLine(left) ? left : 0));
		setRightLine(asioDriver.getInputChannel(asioDriver.validInputLine(right) ? right : 1));
	}
		
	@Override
	public void refreshBuffer(int bufferSize) {
		outputLeft = new float[bufferSize];
		outputRight = new float[bufferSize];
		boolean useNoiseFilter = ((MicrophoneIhm)configIhm).getNoiseReduction();
		if (!mute) {
			this.leftChannel.read(outputLeft);
			this.rightChannel.read(outputRight);
			for(int i = 0; i < bufferSize; ++i) {
				// filtre de Butterworth pour r�duction du bruit
				if (useNoiseFilter) {
					outputLeft[i] = leftFilter2.next(leftFilter1.next(outputLeft[i] * this.leftLevel));
					outputRight[i] = rightFilter2.next(rightFilter1.next(outputRight[i] * this.rightLevel));
				} else {
					outputLeft[i] = outputLeft[i] * this.leftLevel;
					outputRight[i] = outputRight[i] * this.rightLevel;
				}
			}
		}
		outputBuffer = new StereoBuffer(outputLeft, outputRight);
	}


	@Override
	public StereoBuffer getBuffer() {
		return outputBuffer;
	}
	
	/**
	 * set the left line of the Microphone
	 * @param aChannel the asio leftLine
	 */
	private void setLeftLine(AsioChannel aChannel) {
		if(aChannel != null) {
			this.leftChannel = aChannel;
			properties.put(INPUT_LEFT, Integer.toString(aChannel.getChannelIndex(), 10));
		}
	}
	
	/**
	 * set the right line of the Microphone
	 * @param aChannel the asio right line
	 */
	private void setRightLine(AsioChannel aChannel) {
		if(aChannel != null) {
			this.rightChannel = aChannel;
			properties.put(INPUT_RIGHT, Integer.toString(aChannel.getChannelIndex(), 10));
		}
	}
	
	@Override
	public void setSoundLevelBoost(float soundLevelBoost) {
		super.setSoundLevelBoost(soundLevelBoost);
		properties.put(SOUND_BOOST, Float.toString(soundLevelBoost));
	}
	
	/**
	 * start the ihm to configure the microphone
	 */
	private void initIhm() {
		final MicrophoneIhm ihm = new MicrophoneIhm();
		ihm.addInputLine(
			new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String name = ((JRadioButtonMenuItem)e.getSource()).getText();
					AsioChannel aChannel = asioDriver.getInputChannel(Integer.parseInt(name.substring(name.length() - 2),10));
					if (aChannel == null || aChannel.equals(leftChannel)) {
						return;
					}
					if ( ! asioDriver.containsExtraChannel(aChannel)) {
						doSelectLeftChannel(aChannel);
					} else {
						int result = JOptionPane.showConfirmDialog(null, "Warning: inconsistency detected; are you sure you want to do that?", "Inconsistency warning", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							doSelectLeftChannel(aChannel);
						} else {
							ihm.selectLeftLine(leftChannel);
						}
					}
				}
				private void doSelectLeftChannel(AsioChannel aChannel) {
					asioDriver.addExtraChannel(aChannel);
					asioDriver.removeExtraChannel(leftChannel);
					ihm.selectLeftLine(aChannel);
					setLeftLine(aChannel);
					asioDriver.initializeDriver();
				}
			},
			new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String name = ((JRadioButtonMenuItem)e.getSource()).getText();
					AsioChannel aChannel = asioDriver.getInputChannel(Integer.parseInt(name.substring(name.length() - 2),10));
					if (aChannel == null || aChannel.equals(rightChannel)) {
						return;
					}
					if( ! asioDriver.containsExtraChannel(aChannel)) {
						doSelectRightChannel(aChannel);
					} else {
						int result = JOptionPane.showConfirmDialog(null, "Warning: inconsistency detected; are you sure you want to do that?", "Inconsistency warning", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
						if (result == JOptionPane.YES_OPTION) {
							doSelectRightChannel(aChannel);
						} else {
							ihm.selectRightLine(rightChannel);
						}
					}
				}
				private void doSelectRightChannel(AsioChannel aChannel) {
					asioDriver.addExtraChannel(aChannel);
					asioDriver.removeExtraChannel(rightChannel);
					ihm.selectRightLine(aChannel);
					setRightLine(aChannel);
					asioDriver.initializeDriver();
				}
			},
			asioDriver.getInputChannels());
		if (leftChannel != null)
			ihm.selectLeftLine(leftChannel);
		if (leftChannel != null)
			ihm.selectRightLine(rightChannel);
		
		ihm.addNoiseChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
//				System.out.println("Change noise reduction => " + ihm.getNoiseReduction());//DEBUG
			}
		});

		ihm.setSoundLevelBoost(soundLevelBoost);
		ihm.addSoundLevelBoostChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setSoundLevelBoost(ihm.getSoundLevelBoost());
			}
		});
		
		ihm.addActionToOkButton(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Parameters.getInstance().setProviderParameters(AbstractMicrophone.this, properties);
				ihm.dispose();
			}
		});
		configIhm = ihm;
	}
	
	/**
	 * reload the parameters and the ihms
	 */
	private void reload() {
		if(this.asioDriver.getDriverName().equals(driverName)) {
			return;
		}
		this.asioDriver.removeExtraChannel(leftChannel);
		this.asioDriver.removeExtraChannel(rightChannel);
		initConfig();
	}
	
	@Override
	public ConfigIhm getIhm() {
		reload();
		return configIhm;
	}

	@Override
	public void sampleRateChanged(double sampleRate, BaseBus aBus) {}

	@Override
	public boolean changeFrameRateOfRegisteredBus() {return true;}
}
