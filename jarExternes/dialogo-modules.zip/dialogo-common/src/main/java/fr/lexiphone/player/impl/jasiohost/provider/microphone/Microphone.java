package fr.lexiphone.player.impl.jasiohost.provider.microphone;


public class Microphone extends AbstractMicrophone {

	public final static String ID = "Microphone";
	public Microphone() {
		super(ID);
	}
	
}
