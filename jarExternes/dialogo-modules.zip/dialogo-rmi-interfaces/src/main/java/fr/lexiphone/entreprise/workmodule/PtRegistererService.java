/*
 * Created on 27 f�vr. 03
 *
 * To change this generated comment go to 
 * Window>Preferences>Java>Code Generation>Code Template
 */
package fr.lexiphone.entreprise.workmodule;

import java.rmi.Remote;
import java.rmi.RemoteException;

import fr.lexiphone.entreprise.technical.EntrepriseException;
import fr.lexiphone.entreprise.technical.IEntrepriseService;

/**
 * @author clime
 */
public interface PtRegistererService extends IEntrepriseService, Remote {

	public void register(String in_ptUrn) throws RemoteException, EntrepriseException;

}
