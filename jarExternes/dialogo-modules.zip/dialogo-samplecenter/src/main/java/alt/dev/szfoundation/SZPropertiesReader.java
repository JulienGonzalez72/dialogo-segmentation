//
//      ===========================================================================
//
//      Title:          SZPropertiesReader.java
//      Description:    See SZPropertiesWriter.java
//      Author:         Rapha�l Szwarc <zoe (underscore) info (at) mac (dot) com>
//      Creation Date:  Thu Dec 09 2004
//      Legal:          Copyright (C) 2004 Rapha�l Szwarc
//
//      This software is provided 'as-is', without any express or implied warranty. 
//      In no event will the author be held liable for any damages arising from 
//      the use of this software.
//
//      Permission is granted to anyone to use this software for any purpose, 
//      including commercial applications, and to alter it and 
//      redistribute it freely, subject to the following restrictions:
//
//      1. The origin of this software must not be misrepresented; 
//      you must not claim that you wrote the original software. 
//      If you use this software in a product, an acknowledgment
//      in the product documentation would be appreciated but is not required.
//
//      2. Altered source versions must be plainly marked as such, 
//      and must not be misrepresented as being the original software.
//
//      3. This notice may not be removed or altered from any source distribution.
//
//      ---------------------------------------------------------------------------
//

package alt.dev.szfoundation;

import java.io.InputStream;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.LineNumberReader;
import java.io.PushbackReader;
import java.io.IOException;

import java.util.Arrays;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public abstract class SZPropertiesReader extends Object
{

//      ===========================================================================
//      Constant(s)
//      ---------------------------------------------------------------------------

        private static final Class[]    Classes = 
                                        { 
                                                MapReader.class,
                                                CollectionReader.class,
                                                StringReader.class
                                        };

//      ===========================================================================
//      Class variable(s)
//      ---------------------------------------------------------------------------

        private static final Map        _readers = new HashMap( SZPropertiesReader.Classes.length );
        private static final int[]      _markers = new int[ SZPropertiesReader.Classes.length ];

//      ===========================================================================
//      Instance variable(s)
//      ---------------------------------------------------------------------------

//      ===========================================================================
//      Constructor method(s)
//      ---------------------------------------------------------------------------

        protected SZPropertiesReader()
        {
                super();
        }

//      ===========================================================================
//      Class method(s)
//      ---------------------------------------------------------------------------

        static 
        {
                Class[] someClasses = SZPropertiesReader.Classes;
                int     count = someClasses.length;
                
                for ( int index = 0; index < count; index++ )
                {
                        Class   aClass = someClasses[ index ];
                        
                        try
                        {
                                SZPropertiesReader      aReader = (SZPropertiesReader) aClass.newInstance();
                                int                     aMarker = aReader.marker();
                                Integer                 aValue = new Integer( aMarker );

                                _readers.put( aValue, aReader );
                                _markers[ index ] = aMarker;
                        }
                        catch (Exception anException)
                        {
                                throw new RuntimeException( anException.getMessage(), anException );
                        }
                }
                
                Arrays.sort( _markers );
        }
        
        private static Map readers()
        {
                return _readers;
        }

        private static int[] markers()
        {
                return _markers;
        }

        public static Object readObject(final InputStream anInputStream) throws IOException
        {
                if ( anInputStream != null )
                {
                        Reader                  anInputStreamReader = new InputStreamReader( anInputStream, SZPropertiesWriter.Encoding );
                        Reader                  aBufferedReader = new BufferedReader( anInputStreamReader );
                        LineNumberReader        aLineReader = new LineNumberReader( aBufferedReader );
                        PushbackReader          aReader = new PushbackReader( aLineReader  );
                        
                        try
                        {
                                Object  anObject = SZPropertiesReader.readObject( aReader );
                                        
                                aReader.close();
                        
                                return anObject;
                        }
                        catch (IOException anException)
                        {
                                throw anException;
                        }
                        catch (IllegalStateException anException)
                        {
                                throw new RuntimeException( "SZPropertiesReader.readObject: invalid data at line " + aLineReader.getLineNumber(), anException );
                        }
                }

                throw new IllegalArgumentException( "SZPropertiesReader.readObject: null input stream" );
        }
        
        protected static Object readObject(final PushbackReader aReader) throws IOException
        {
                if ( aReader != null )
                {
                        int     aValue = MarkerReader.reader().read( aReader, -1 );
                        
                        if ( aValue != -1 )
                        {
                                Integer                 anIntValue = new Integer( aValue );
                                Map                     someReaders = SZPropertiesReader.readers();
                                SZPropertiesReader      aPropertiesReader = (SZPropertiesReader) someReaders.get( anIntValue );
                                
                                if ( aPropertiesReader != null )
                                {
                                        Object  anObject = aPropertiesReader.read( aReader );

                                        return anObject;
                                }

                                throw new IllegalStateException( "SZPropertiesReader.readObject: null object" );
                        }
                        
                        throw new IllegalStateException( "SZPropertiesReader.readObject: unexpected end of stream" );
                }

                throw new IllegalArgumentException( "SZPropertiesReader.readObject: null reader" );
        }

//      ===========================================================================
//      Instance method(s)
//      ---------------------------------------------------------------------------

        protected abstract int marker();

        protected abstract Object read(final PushbackReader aReader) throws IOException;

//      ===========================================================================
//      MapReader method(s)
//      ---------------------------------------------------------------------------

        private static final class MapReader extends SZPropertiesReader
        {
        
                private static final int        Marker = (int) '{';
                private static final int        EndMarker = (int) '}';
        
                protected MapReader()
                {
                        super();
                }
                
                protected int marker()
                {
                        return MapReader.Marker;
                }
                
                protected Object read(final PushbackReader aReader) throws IOException
                {
                        Map     aMap = new HashMap();
                        int     aValue = -1;
                        
                        while ( ( ( aValue = MarkerReader.reader().read( aReader, MapReader.EndMarker ) ) != -1 ) &&
                                ( aValue != MapReader.EndMarker ) )
                        {
                                        aReader.unread( aValue );
                                Object  aKey = SZPropertiesReader.readObject( aReader );
                                Object  anObject = SZPropertiesReader.readObject( aReader );
                                        
                                aMap.put( aKey, anObject );
                        }
                        
                        if ( aValue != MapReader.EndMarker )
                        {
                                throw new IllegalStateException( "SZPropertiesReader.MapReader.read: missing end marker '" + MapReader.EndMarker + "'" );
                        }
                        
                        return aMap;
                }
                
        }

//      ===========================================================================
//      CollectionReader method(s)
//      ---------------------------------------------------------------------------

        private static final class CollectionReader extends SZPropertiesReader
        {
        
                private static final int        Marker = (int) '(';
                private static final int        EndMarker = (int) ')';
        
                protected CollectionReader()
                {
                        super();
                }

                protected int marker()
                {
                        return CollectionReader.Marker;
                }
                
                protected Object read(final PushbackReader aReader) throws IOException
                {
                        Collection      aCollection = new ArrayList();
                        int             aValue = -1;
                        
                        while ( ( ( aValue = MarkerReader.reader().read( aReader, CollectionReader.EndMarker ) ) != -1 ) &&
                                ( aValue != CollectionReader.EndMarker ) )
                        {
                                        aReader.unread( aValue );
                                Object  anObject = SZPropertiesReader.readObject( aReader );
                                
                                aCollection.add( anObject );
                        }
                        
                        if ( aValue != CollectionReader.EndMarker )
                        {
                                throw new IllegalStateException( "SZPropertiesReader.CollectionReader.read: missing end marker '" + CollectionReader.EndMarker + "'" );
                        }

                        return aCollection;
                }
                
        }

//      ===========================================================================
//      StringReader method(s)
//      ---------------------------------------------------------------------------

        private static final class StringReader extends SZPropertiesReader
        {
        
                private static final int        Marker = (int) '"';
                private static final int        EndMarker = (int) '"';
                
                private static final int        EscapeMarker = (int) '\\';
                private static final int[]      EscapeChars = { (int) 'n', (int) 'r', (int) 't', (int) 'f', (int) 'b', (int) 'a', (int) 'v' };
                private static final int[]      EscapeValues = { (int) '\n', (int) '\r', (int) '\t', (int) '\f', (int) '\b', (int) '\007', (int) '\013' };
                private static final Map        EscapeMap = new HashMap( EscapeChars.length );

                protected StringReader()
                {
                        super();
                }
                
                static
                {
                        int     count = EscapeChars.length;
                        
                        for ( int index = 0; index < count; index++ )
                        {
                                Integer aValue = new Integer( StringReader.EscapeChars[ index ] );
                                Integer anEscapeValue = new Integer( StringReader.EscapeValues[ index ] );
                                
                                StringReader.EscapeMap.put( aValue, anEscapeValue );
                        }
                
                        Arrays.sort( StringReader.EscapeChars );
                }

                protected int marker()
                {
                        return StringReader.Marker;
                }
                
                private int escapeValue(int aValue, final PushbackReader aReader) throws IOException
                {
                        if ( aValue == StringReader.EscapeMarker )
                        {
                                aValue = aReader.read();
                                
                                if ( aValue != -1 )
                                {
                                        int     anIndex = Arrays.binarySearch( StringReader.EscapeChars, aValue );
                                        
                                        if ( anIndex >= 0 )
                                        {
                                                Integer anIntValue = new Integer( aValue );
                                                Integer anEscapeValue = (Integer) StringReader.EscapeMap.get( anIntValue );
                                                
                                                aValue = anEscapeValue.intValue();
                                        }
                                }
                                else
                                {
                                        throw new IllegalStateException( "SZPropertiesReader.StringReader.valueForChar: unexpected end of stream" );
                                }
                        }

                        return aValue;
                }

                protected Object read(final PushbackReader aReader) throws IOException
                {
                        StringBuffer    aBuffer = new StringBuffer();
                        int             aValue = -1;
                        
                        while ( ( ( aValue = aReader.read() ) != -1 ) && ( aValue != StringReader.EndMarker ) )
                        {
                                char    aChar = (char) this.escapeValue( aValue, aReader );
                                
                                aBuffer.append( aChar );
                        }
                        
                        return aBuffer.toString();
                }
                
        }

//      ===========================================================================
//      MarkerReader method(s)
//      ---------------------------------------------------------------------------

        private static final class MarkerReader extends Object
        {
        
                private static final MarkerReader       _reader = new MarkerReader();
        
                protected MarkerReader()
                {
                        super();
                }
                
                protected static MarkerReader reader()
                {
                        return _reader;
                }
                
                protected int read(final Reader aReader, int anEndMarker ) throws IOException
                {
                        int     aValue = -1;
                        
                        while ( ( aValue = aReader.read() ) != -1 )
                        {
                                if ( ( aValue == anEndMarker ) ||
                                        ( Arrays.binarySearch( SZPropertiesReader.markers(), aValue ) >= 0 ) )
                                {
                                        break;
                                }
                        }
                        
                        return aValue;
                }
                
        }

}
