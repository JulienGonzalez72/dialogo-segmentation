package fr.lexiphone.player.impl.jasiohost.provider.jlPlayer;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.PlayerEvent;
import fr.lexiphone.player.PlayerListener;
import fr.lexiphone.player.impl.BasicController;
import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.BitstreamException;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.DecoderException;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dialogo.sound.file.Mp3Wrapper;

public class JlayerPlayer extends BaseProvider implements BasicController {
	private final Log log = LogFactory.getLog(JlayerPlayer.class);
	
	static final public String ID = "Player";
	
	static final public int TOLERANCE_FRAMES = 800;
	
	//the position in mpegBuffer in Frame
	private volatile int mpegBufferFramePosition = 0;
	
	private volatile AsioPlayerState state = AsioPlayerState.unloaded;

	private volatile long checkStopMarker;// in frames

	//all fields for mpeg decoding
	private Bitstream bitStream = null;
	private Decoder decoder = null;
	private volatile int positionInMpegFrame = 0;
	private StereoBuffer mpegBuffer = null;
	
	//Information about the file
	private float frameRate = 48000;
	private int durationInMilliseconds = 0;
	private String fileName = null;

	//Listener
	private List<PlayerListener> listeners = null;
	private boolean introIsSet;
	
	public JlayerPlayer() {
		super(ID);
		introIsSet=false;
		listeners = new ArrayList<>();
		initIhm();
	}
	
	public JlayerPlayer(String fileName) throws BasicPlayerException{
		this();
		open(fileName);
	}
	
	private void initIhm(){
		configIhm = new JLayerPlayerIhm(this);
	}
	
	/**
	 * init the player with an inputStream
	 * @param in the input Stream
	 */
	private void init(InputStream in) {
		//init mpeg decoding
		bitStream = new Bitstream(in);
		decoder = new Decoder();
		
		//set all Position to 0;
		mpegBufferFramePosition = 0;
		positionInMpegFrame = 0;
		
		Header h;
		try {
			//fill mpeg Buffer
			h = bitStream.readFrame();
			SampleBuffer aSampleBuffer = (SampleBuffer)decoder.decodeFrame(h, bitStream);
			mpegBuffer = shortArrayToStereoBuffer(aSampleBuffer.getBuffer(), aSampleBuffer.getBufferLength());
			bitStream.closeFrame();
			++positionInMpegFrame;
			
			//get mp3 information
			frameRate = h.frequency();
			durationInMilliseconds = (int)(8000 * (new File(fileName).length() - bitStream.header_pos()) / h.bitrate());
		} catch (BitstreamException e) {
//			log.error("", e);
			setState(AsioPlayerState.error);
			return;
		} catch (DecoderException e) {
//			log.error("", e);
			setState(AsioPlayerState.error);
			return;
		}
		
		if (!changeFrameRateOfRegisteredBus()) {
			throw new IllegalStateException("can't read this file");
		}
		
		//if all good set to loaded
		setState(AsioPlayerState.loaded);
	}
	
	@Override
	public boolean changeFrameRateOfRegisteredBus() {
		for(BaseBus aBus : registredBus) {
			if (!aBus.changeFrameRate(this.frameRate))
				return false;
		}
		return true;
	}
	
	/**
	 * reset the stream without some initialization
	 * warning : it doesn't read the first mpeg frame and it doen't change state of the player
	 */
	private void resetStream(){
		//init mpeg decoding
		try {
			if (bitStream != null) {
				try {
					bitStream.close();
				} catch (BitstreamException ignore) {
				}
			}
			if (fileName != null) {
				bitStream = new Bitstream(new FileInputStream(fileName));
			}
		} catch (FileNotFoundException e) {
			System.out.println(e.getLocalizedMessage());
		}
		decoder = new Decoder();
		
		//set all Position to 0;
		mpegBufferFramePosition = 0;
		positionInMpegFrame = 0;
	}

	/**
	 * set the position to read in millisecond
	 * @param mSeconds the position in milliseconds
	 */
	@Override
	public void setPosMilliSeconds(long mSeconds) throws BasicPlayerException {
		mSeconds = Math.max(0, mSeconds);
		setPosFrames((long) (mSeconds / 1000.0 * this.frameRate));
	}
	
	/**
	 * set the position in frames format and give the new position
	 * @param positionInFrames the position who want 
	 * @return the new position, -1 if fails
	 */
	public long setPosFrames(long positionInFrames) throws BasicPlayerException {
		positionInFrames = Math.max(0, positionInFrames);
//		if (log.isDebugEnabled()) {
//			log.debug("setPosFrames: position = " + getPositionInFrames() + " frames = " + getPosTimeFormated() + " ; wanted = " + positionInFrames + " frames");
//		}
		//check the player state and backup it
		boolean isPlayingBefore = false;
		if (this.state == AsioPlayerState.unloaded) {
			return -1;
		} else if (this.state == AsioPlayerState.playing) {
			pause();
			isPlayingBefore = true;
		}
		
		//if we doesn't move, do nothing
		if (positionInFrames == getPositionInFrames())
			return getPositionInFrames();
		//reset the stream if the position needed is only smaller than the current position
		else if (positionInFrames < (getPositionInFrames() - TOLERANCE_FRAMES))
			resetStream();
		
		//skip the mpegFrames, for more speed we don't decode frame but the last mpeg frame must be decoded
		boolean skipok = true;
		while(positionInMpegFrame < (positionInFrames / mpegBuffer.getBufferSize()) && skipok) {
			skipok = skipSingleMpegFrame();
		}
		//decoded the last mpeg frame
		if(positionInMpegFrame == (positionInFrames / mpegBuffer.getBufferSize()))
			readSingleMpegFrame();
		
		//move the position for the mpeg buffer
		mpegBufferFramePosition = (int) (positionInFrames % mpegBuffer.getBufferSize()); 
		
		//store new position
		long newPosition = 0;
		if(skipok)
			newPosition = getPositionInFrames();
		
//		if (log.isDebugEnabled()) {
//			log.debug("setPosFrames: new position = " + getPositionInFrames() + " frames = " + getPosTimeFormated() + " ; wanted = " + positionInFrames + " frames");
//		}
		
		//resume if player playing before movement
		if(isPlayingBefore) {
			resume();
		}
		
		if(newPosition == 0)
			return -1;
		else
			return newPosition;
	}
	
	/**
	 * get the position in frames
	 * @return the position in frames
	 */
	public long getPositionInFrames() {
		return (positionInMpegFrame - 1) * 1152 + mpegBufferFramePosition;
	}
	
	/**
	 * get current position in milliseconds
	 * @return the position in milliseconds 
	 */
	@Override
	public long getPosMilliSeconds(){
		return framesToMilliSeconds(getPositionInFrames());
	}
	
	/**
	 * get the pos in a formated time like "hh:mm:ss.SS"
	 * @return the formatted time in a String
	 */
	public String getPosTimeFormated() {
		StringBuffer buff = new StringBuffer(13);
		long time = getPosMilliSeconds();
		long millis = time % 1000;
		long rest = time / 1000; // seconds
		long hour = rest / 3600;
		rest = rest % 3600;
		long minute = rest / 60;
		rest = rest % 60;
		long second = rest;
		if (hour < 10) {
			buff.append('0');
		}
		buff.append(hour);
		buff.append(':');
		if (minute < 10) {
			buff.append('0');
		}
		buff.append(minute);
		buff.append(':');
		if (second < 10) {
			buff.append('0');
		}
		buff.append(second);
		buff.append('.').append(millis);
		return buff.toString();
	}

	/**
	 * set the position whith normal constructor of the time
	 * @param hours the hours > 0
	 * @param minutes the minutes between 0 and 60
	 * @param seconds the seconds between 0 and 60
	 * @param milliseconds the milliseconds between 0 and 1000
	 * @return the new position in milliseconds
	 */
	public long setPosAt(int hours, int minutes, int seconds, int milliseconds) throws BasicPlayerException {
		if (minutes > 60 || minutes < 0 || seconds < 0 || seconds > 60)
			throw new IllegalArgumentException("minutes or seconds must be between 0 and 60");
		if (milliseconds < 0 || milliseconds > 1000)
			throw new IllegalArgumentException("milliseconds must be between 0 and 1000");
		if (hours < 0)
			throw new IllegalArgumentException("hours must be > 0");
		return framesToMilliSeconds(setPosFrames(milliSecondsToFrame(milliseconds + seconds * 1000 + minutes * 60 * 1000 + hours * 60 * 60 * 1000)));
		
	}
	
	/**	
	 * getter for duration in ms
	 * @return the duration of the track in ms
	 */
	@Override
	public long getDuration() {
		return durationInMilliseconds;
	}
	
	/**
	 * get the actual value of the state of the player
	 * @return the current state
	 */
	public AsioPlayerState getAsioPlayerState() {
		return this.state;
	}
	
	/**
	 * get the actual state of the player	
	 * @return the current state
	 */
	@Override
	public PlayerState getState() {
		return stateFromAsio(state);
	}
	static PlayerState stateFromAsio(AsioPlayerState asioState) {
		switch (asioState) {
		case unloaded:
		case loaded:
		case stopped:
		case error:
			return PlayerState.STOPPED;
		case playing:
			return PlayerState.PLAYING;
		case paused:
			return PlayerState.PAUSED;
		default:
			throw new IllegalStateException(asioState.name());
		}
	}
	
	/**
	 * set the new state and do the associated job
	 * @param aNewState 
	 */
	private void setState(AsioPlayerState aNewState) {
		state = aNewState;
		((JLayerPlayerIhm)configIhm).setLabelState(this.state.toString());
	}
	
	/**
	 * skip a single mpeg frame 
	 * @return false, if there are no more frames to decode
	 */
	private boolean skipSingleMpegFrame() {
		Header h = null;
		try {
			h = bitStream.readFrame();
		} catch (BitstreamException e) {
			System.out.println(e.getLocalizedMessage());
		}
		if (h == null)
			return false;
		bitStream.closeFrame();
		
		++positionInMpegFrame;
		return true;
	}
	
	/**
	 * this method decode a single Mpeg Frame and store it in a 
	 * @return true if the reading and decoding success, unless false
	 */
	private boolean readSingleMpegFrame() {
		Header h;
		try {
			h = bitStream.readFrame();
			SampleBuffer aSampleBuffer = (SampleBuffer)decoder.decodeFrame(h, bitStream);
			mpegBuffer = shortArrayToStereoBuffer(aSampleBuffer.getBuffer(), aSampleBuffer.getBufferLength());
			bitStream.closeFrame();
			++positionInMpegFrame;
			return true;
		} catch (BitstreamException e) {
			e.printStackTrace();
		} catch (DecoderException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	/**
	 * This method transform a short array in an asio St�reoBuffer (float)
	 * @param samples an array of short samples
	 * @param len the len of samples inside the short array (short Array can be larger than necessary)
	 * @return a StereoBuffer in asio format
	 */
	private StereoBuffer shortArrayToStereoBuffer(short [] samples, int len) {
		float[] leftBuffer = new float[len];
		if (decoder.getOutputChannels() == 1) {
			for (int i = 0; i < leftBuffer.length; ++i) {
				leftBuffer[i] = samples[i] / 32768.0F;
			}
			return new StereoBuffer(leftBuffer, leftBuffer);
		} else if (decoder.getOutputChannels() == 2) {
			float[] rightBuffer = new float[len];
			for (int i = 0, offset = 0; offset < samples.length; ++i, offset+=2) {
				leftBuffer[i] = samples[offset];
				rightBuffer[i] = samples[offset + 1];
			}
			return new StereoBuffer(leftBuffer, rightBuffer);
		} else {
//			if (log.isTraceEnabled()) {// should be a warning, but that would flood the log output
//				log.trace("shortArrayToStereoBuffer(): unknown # channels: " + decoder.getOutputChannels());
//			}
			return new StereoBuffer(leftBuffer, leftBuffer);// empty buffer, instead of null
		}
	}
	
	/**
	 * give the position in milliseconds for the position of frames given in parameters
	 * @param frames the position in frames
	 * @return the position in milliseconds, 0 if the framerate is null
	 */
	private long framesToMilliSeconds(long frames) {
		return this.frameRate == 0 ? 0 : (long) (frames / this.frameRate * 1000.0);
	}
	
	/**
	 * give the position in frame for the position in milliseconds given in parameters
	 * @param milliseconds the position in milliseconds
	 * @return the position in frame, 0 if the framerate is null
	 */
	private long milliSecondsToFrame(long milliseconds) {
		return (long) (milliseconds / 1000.0 * this.frameRate);
	}
	
	
	/**
	 * Implementation of the provider interface
	 * 
	 */

	@Override
	public void refreshBuffer(int bufferSize) {
		//if player is not loaded do nothing
		if (state.ordinal() < AsioPlayerState.loaded.ordinal())
			return;
		
		float[] outputLeft = new float[bufferSize];
		float[] outputRight = new float[bufferSize];
		if (state == AsioPlayerState.playing) {
			if (mute)
				muteReading(bufferSize);
			else {
				if (mpegBufferFramePosition >= (mpegBuffer.getBufferSize() - bufferSize)) {
					for(int i = 0; i < bufferSize; ++i, ++mpegBufferFramePosition) {
						if (mpegBufferFramePosition == mpegBuffer.getBufferSize()) {
							readSingleMpegFrame();
							mpegBufferFramePosition = 0;
						}
						outputLeft[i] = mpegBuffer.getLeftChannel()[mpegBufferFramePosition] * leftLevel;
						outputRight[i] = mpegBuffer.getRightChannel()[mpegBufferFramePosition] * rightLevel;
						if (checkStopMarker()) {
							break;
						}
					}
				} else {
					for(int i = 0; i < bufferSize; ++i) {
						outputLeft[i] = mpegBuffer.getLeftChannel()[mpegBufferFramePosition + i] * leftLevel;
						outputRight[i] = mpegBuffer.getRightChannel()[mpegBufferFramePosition + i] * rightLevel;
						if (checkStopMarker()) {
							mpegBufferFramePosition += i;
							break;
						}
					}
					mpegBufferFramePosition += bufferSize;
				}
			}
		}

		outputBuffer = new StereoBuffer(outputLeft, outputRight);
	}

	private boolean checkStopMarker() {
		if (checkStopMarker == 0)
			return false;
		if (getPositionInFrames() >= checkStopMarker) {
			pause();
			log.debug("getPositionInFrames() >= checkStopMarker ("+checkStopMarker+")");
			return true;
		}
		return false;
	}
	
	/**
	 * read the buffer without saving value 
	 * @param bufferSize
	 */
	private void muteReading(int bufferSize){
		if (mpegBufferFramePosition >= (mpegBuffer.getBufferSize() - bufferSize)) {
			readSingleMpegFrame();
			mpegBufferFramePosition = bufferSize - (mpegBuffer.getBufferSize() - mpegBufferFramePosition);
		} else
			mpegBufferFramePosition += bufferSize;
	}
	
	
	/**
	 * All the following methods concern the controls
	 * (implementations of BasicController)
	 */
	
	@Override
	public void open(InputStream in) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}

	@Override
	public void open(File file) throws BasicPlayerException {
		fileName = file.getPath();
		try {
			init(new FileInputStream(file));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
	
	public void open(String fileName) throws BasicPlayerException {
		open(new File(fileName));
	}

	@Override
	public void pause() {
		if(this.state == AsioPlayerState.playing) {
//			if (log.isDebugEnabled()) {
//				log.debug("pause: position = " + getPositionInFrames() + " frames = " + getPosTimeFormated());
//			}
			notifyChangeToPauseListener(state, getPosMilliSeconds());
			this.setState(AsioPlayerState.paused);
			checkStopMarker = 0;
		}
	}

	@Override
	public void play() {
		play(0);
	}
	
	@Override
	public void play(long milliseconds) {
		log.debug("play("+milliseconds+") state="+this.state);
		if(this.state == AsioPlayerState.loaded || this.state == AsioPlayerState.stopped) {
			notifyChangeToPlayListener(state, getPosMilliSeconds());
			this.setState(AsioPlayerState.playing);
			checkStopMarker = initStopMarker(milliseconds);//
		}
	}
	
	private long initStopMarker(long milliseconds) {
		long littleTimeBeforeEnd=milliSecondsToFrame(durationInMilliseconds-100);
		return milliseconds > 0 ? Math.min(getPositionInFrames() + milliSecondsToFrame(milliseconds), littleTimeBeforeEnd) : littleTimeBeforeEnd;
	}

	/**
	 * start playing between the required position
	 * @param startMilliseconds the milliseconds to start reading
	 * @param stopMilliseconds the milliseconds to stop reading
	 */
	public void play(long startMilliseconds, long stopMilliseconds) throws BasicPlayerException {
//		System.out.println("start " + startMilliseconds + " stop " +(stopMilliseconds - startMilliseconds));
		setPosMilliSeconds(startMilliseconds);
		pause();
		resume(stopMilliseconds - startMilliseconds);
	}

	/**
	 * {@inheritDoc}
	 * Beware that this method will reset the auto-stop mark ({@code checkStopMarker})!
	 */
	@Override
	public void resume() throws BasicPlayerException {
		resume(0);
		recurrenceJump();
	}
	
	@Override
	public void resume(long milliseconds) {
		if(this.state == AsioPlayerState.paused) {
			notifyChangeToResumeListener(state, getPosMilliSeconds());
			this.setState(AsioPlayerState.playing);
			checkStopMarker = initStopMarker(milliseconds);//milliseconds > 0 ? getPositionInFrames() + milliSecondsToFrame(milliseconds) : 0;
		} else if (this.state == AsioPlayerState.playing) {
			// allow to set auto-stop mark while already playing
			checkStopMarker = initStopMarker(milliseconds);//milliseconds > 0 ? getPositionInFrames() + milliSecondsToFrame(milliseconds) : 0;
		}
	}
	
	@Override
	public void pauseOrResume() throws BasicPlayerException {
		switch (this.state) {
		case playing:
			pause();
			break;
		case paused:
			resume();
			break;
		case loaded:
		case stopped:
			play();
			break;
		default:
			break;
		}
	}

	@Override
	public void playOrResume() throws BasicPlayerException {
		switch (this.state) {
		case playing:
			resume(); // set auto-stop mark while already playing
			break;
		case paused:
			resume();
			break;
		case loaded:
		case stopped:
			play();
			break;
		default:
			break;
		}
	}
	@Override
	public void playOrResume(long milliseconds) throws BasicPlayerException {
		switch (this.state) {
		case playing:
			resume(milliseconds); // set auto-stop mark while already playing
			break;
		case paused:
			resume(milliseconds);
			break;
		case loaded:
		case stopped:
			play(milliseconds);
			break;
		default:
			break;
		}
	}
	
	@Override
	public void stop() {
		try {
			if (bitStream != null) {
				bitStream.close();
			}
		} catch (BitstreamException ex) {
			System.out.println(ex.getLocalizedMessage());
		}
		notifyChangeToStopListener(state, getPosMilliSeconds());
		this.setState(AsioPlayerState.stopped);
		resetStream();
		if (bitStream != null) {
			skipSingleMpegFrame();
		}
		checkStopMarker = 0;
		this.setState(AsioPlayerState.loaded);
	}

	@Override
	public long seek(long milliseconds) throws BasicPlayerException {
		setPosMilliSeconds(getPosMilliSeconds() + milliseconds);
		checkStopMarker = 0;
		return milliseconds;
	}

	@Override
	public float getPositionAsPercent() throws BasicPlayerException {
		return this.frameRate == 0 || durationInMilliseconds == 0 ? 0 : getPositionInFrames() * 1000 / (durationInMilliseconds * this.frameRate);	
	}
	
	@Override
	public void setPositionAsPercent(float percent) throws BasicPlayerException {
		if (percent > 1 || percent < 0 || setPosFrames((long) (durationInMilliseconds * percent * this.frameRate * .001)) == -1)
			throw new BasicPlayerException("setPositionAsPercent() % out of range: " + percent);
	}
	
	@Override
	public Integer getPosSentenceNumber() throws BasicPlayerException {
		return null;
	}

	@Override
	public void setPosSentenceNumber(int n) throws BasicPlayerException {
		// noop
	}
	
	@Override
	public Integer getTotalSentencesNumber() throws BasicPlayerException {
		return null;
	}
	
	@Override
	public void recurrenceJump() throws BasicPlayerException {
		// noop
		notifyRecurrenceJumpListener(state, getPosMilliSeconds());
	}

	@Override
	public void open(URL url) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}
	@Override
	public void setGain(double gain) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}
	@Override
	public void setPan(double pan) throws BasicPlayerException {
		throw new UnsupportedOperationException();
	}

	@Override
	public void init(BaseBus aBus) {}
	
	@Override
	public void sampleRateChanged(double sampleRate, BaseBus aBus) {}
	
	/**
	 * M�thods for listeners
	 */
	
	@Override
	public void addPlayerListener(PlayerListener listener) {
		if (listener != null) {
			listeners.add(listener);
		}
	}
	
	@Override
	public void removePlayerListener(PlayerListener listener) {
		if (listener != null) {
			listeners.remove(listener);
		}
	}
	
	public void notifyChangeToPauseListener(AsioPlayerState previousState, long positionInMillis) {
		PlayerEvent anEvent = new PlayerEvent(this, stateFromAsio(previousState), PlayerState.PAUSED, (short)-1, positionInMillis);
		for (int i = 0; i < listeners.size(); i++) {
			PlayerListener listener = listeners.get(i);
			//for(PlayerListener listener : listeners) {
//        	listener.changeToPause(anEvent);
        	listener.propertyChange(anEvent);
        }
	}
	public void notifyChangeToPlayListener(AsioPlayerState previousState, long positionInMillis) {
		PlayerEvent anEvent = new PlayerEvent(this, stateFromAsio(previousState), PlayerState.PLAYING, (short)-1, positionInMillis);
		for (int i = 0; i < listeners.size(); i++) {
			PlayerListener listener = listeners.get(i);
//			listener.changeToPlay(anEvent);
        	listener.propertyChange(anEvent);
		}
	}
	public void notifyChangeToResumeListener(AsioPlayerState previousState, long positionInMillis) {
		PlayerEvent anEvent = new PlayerEvent(this, stateFromAsio(previousState), PlayerState.PLAYING, (short)-1, positionInMillis);
		for (int i = 0; i < listeners.size(); i++) {
			PlayerListener listener = listeners.get(i);
//			listener.changeToResume(anEvent);
        	listener.propertyChange(anEvent);
		}
	}
	public void notifyChangeToStopListener(AsioPlayerState previousState, long positionInMillis) {
		PlayerEvent anEvent = new PlayerEvent(this, stateFromAsio(previousState), PlayerState.STOPPED, (short)-1, positionInMillis);
		for (int i = 0; i < listeners.size(); i++) {
			PlayerListener listener = listeners.get(i);
//			listener.changeToStop(anEvent);
        	listener.propertyChange(anEvent);
		}
	}
	public void notifyRecurrenceJumpListener(AsioPlayerState previousState, long positionInMillis) {
		PlayerEvent anEvent = new PlayerEvent(this, stateFromAsio(previousState), stateFromAsio(previousState), (short)-1, positionInMillis);
		for (int i = 0; i < listeners.size(); i++) {
			PlayerListener listener = listeners.get(i);
        	listener.recurrenceJump(anEvent);
		}
	}

	@Override
	public void open(Mp3Wrapper sample) throws BasicPlayerException {
		fileName = sample.getFile().getPath();
		try {
			init(new FileInputStream(sample.getFile()));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	/*@Override
	public void open(Mp3Wrapper sample, File intro) throws BasicPlayerException {
		fileName = sample.getFile().getPath();
		try {
			//init(new FileInputStream(sample.getFile()));
			init(new FileInputStream(intro));
			introIsSet=true;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}*/

	@Override
	public void reactivateControls() {
	}

	@Override
	public void disactivateControls() {
	}

}
