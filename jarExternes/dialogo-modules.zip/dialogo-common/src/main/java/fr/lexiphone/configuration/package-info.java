/**
 * Centrally manage all configuration files.
 * <pre>
data/			contains sounds and associated text files
Prg/
    conf/		system (non-user-editable) configuration
work/		contains user data
    conf/	user-editable common configuration
    conf1/	user-editable PT-specific configuration
    conf2/
 * </pre>
 * 
 * @author C&eacute;drik LIME
 */
package fr.lexiphone.configuration;
