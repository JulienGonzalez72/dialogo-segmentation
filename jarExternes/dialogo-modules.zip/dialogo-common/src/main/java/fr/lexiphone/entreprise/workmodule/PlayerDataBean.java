package fr.lexiphone.entreprise.workmodule;

import java.io.Serializable;

/**
 * This bean is created by EntrepriseSignalProcessingServiceImpl (PT project); its goal is sending 
 * from the player all the data needed by the GUI classes LexiphoneFrame and SessionTrackingPanel (TH project).
 * @author Herv� Monot
 *
 */
public class PlayerDataBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1576522544581689124L;
	/**
	 * Constant used for logarithmic conversion.
	 */
	private static final double EPSILON = 0.001;
	/**
	 * the microphone output VU-meter level, as defined PT-side.
	 */
	private float microphoneOutputVUMeterLevel = 0;
	/**
	 * the player output VU-meter level, as defined PT-side
	 */
	private float playerOutputVUMeterLevel = 0;
	/**
	 * Position in the sample (between 0 and 1)
	 */
	private float posRel = 0;
	/**
	 * current sentence number, {@code null} if sample doesn't have a zone marker file.
	 */
	private Integer sentenceNumber=null;
	/**
	 * current player's state
	 */
	private PlayerState state=PlayerState.STOPPED;
	/**
	 * true if patient window is opened
	 */
	private boolean windowOpened=false;
	/**
	 * sample duration in ms
	 */
	private long sampleDurationMs;
	/**
	 * sample position in ms
	 */
	private long samplePositionMs;
	private boolean hasFinishedIntro=false;
	
	/**
	 * 
	 * @return the microphone output VU-meter level, to be used TH-side
	 */
	public int getMicrophoneOutputVUMeterLevel() {
		return convertValueForVuMeter(4, microphoneOutputVUMeterLevel);
		//return (int) (microphoneOutputVUMeterLevel*32768*4);//FIXME magic number
	}
	/**
	 * 
	 * @param microphoneOutputVUMeterLevel the microphone output VU-meter level, as defined PT-side
	 */
	public void setMicrophoneOutputVUMeterLevel(float microphoneOutputVUMeterLevel) {
		this.microphoneOutputVUMeterLevel = microphoneOutputVUMeterLevel;
	}
	/**
	 * 
	 * @return the player output VU-meter level, to be used TH-side
	 */
	public int getPlayerOutputVUMeterLevel() {
		return convertValueForVuMeter(16, playerOutputVUMeterLevel);
		//return (int) (playerOutputVUMeterLevel*32768*16);//FIXME magic number
	}
	/**
	 * 
	 * @param playerOutputVUMeterLevel the player output VU-meter level, as defined PT-side
	 */
	public void setPlayerOutputVUMeterLevel(float playerOutputVUMeterLevel) {
		this.playerOutputVUMeterLevel = playerOutputVUMeterLevel;
	}
	/**
	 * 
	 * @return position in sample (between {@code 0} and {@code 1})
	 */
	public float getPosRel() {
		return posRel;
	}
	/**
	 * 
	 * @param posRel position in sample (between {@code 0} and {@code 1})
	 */
	public void setPosRel(float posRel) {
		this.posRel = posRel;
	}
	/**
	 * @return the current sentence number (beginning by {@code 0}), {@code null} if sample doesn't have a zone marker file
	 */
	public Integer getSentenceNumber() {
		return sentenceNumber;
	}
	/**
	 * @param sentenceNumber the current sentence number (beginning by {@code 0})
	 */
	public void setSentenceNumber(Integer sentenceNumber) {
		this.sentenceNumber = sentenceNumber;
	}
	/**
	 * 
	 * @param state the current player state
	 */
	public void setState(PlayerState state) {
		if(PlayerState.INTRO_FINISHED.equals(this.state)&&!PlayerState.INTRO_FINISHED.equals(state)){
			hasFinishedIntro=true;
		}
		this.state=state;
	}
	/**
	 * 
	 * @return the current player state
	 */
	public PlayerState getState() {
		return state;
	}
	
	/**
	 * "Inspired" from LexiCoreHelper.getOutputVUMeterLevel... I didn't move the LexiCoreHelper class because it depends
	 * on TH's enterprise configuration.
	 * @param multFactor
	 * @param xMin
	 * @param value
	 * @return
	 */
	private static int convertValueForVuMeter(int multFactor, float value){
		double a=fLin2Log(value*32768*multFactor, 2000, 32767, 0, 7);
		return (int) Math.round(a);
	}
	/**
	 * Copy of the method with same name in MathUtils (TH project), necessary to avoid TH project dependencies... Sorry! 
	 * @param x
	 * @param xMin
	 * @param xMax
	 * @param yMin
	 * @param yMax
	 * @return
	 */
	private static double fLin2Log(double x, double xMin, double xMax, double yMin, double yMax) {
		if (x <= xMin) {
			//x = xMin;
			return yMin;
		}
		if (x >= xMax) {
			//x = xMax;
			return yMax;
		}
		if (xMin == xMax) {
			if (yMin == yMax) {
				return yMin;
			} else {
				throw new IllegalArgumentException();
			}
		}
		double newXMin = 10;
		double newXMax = 110;
		double newX = newXMin + ((x - xMin) / (xMax - xMin)) * (newXMax - newXMin);
		if (xMin <= EPSILON) {
			xMax += 1 - xMin;
			x += 1 - xMin;
			xMin = 1;
		}
		return (yMax - yMin) * Math.log(newX / newXMin) / Math.log(newXMax / newXMin) + yMin;
	}
	public void setWindowOpened(boolean opened) {
		windowOpened=opened;
	}
	public boolean windowIsOpened() {
		return windowOpened;
	}

	public long getSampleDurationMs() {
		return sampleDurationMs;
	}

	public void setSampleDurationMs(long sampleDurationMs) {
		this.sampleDurationMs = sampleDurationMs;
	}

	public long getSamplePositionMs() {
		return samplePositionMs;
	}

	public void setSamplePositionMs(long samplePositionMs) {
		this.samplePositionMs = samplePositionMs;
	}
	
	@Override
	public String toString() {
		return "PlayerDataBean: state="+getState()+" posRel="+getPosRel()+" sentenceNumber="+getSentenceNumber();
	}

	/**
	 * Flag indicating is intro has been played and is finished
	 * @return
	 */
	public boolean hasFinishedIntro() {
		return hasFinishedIntro;
	}

}
