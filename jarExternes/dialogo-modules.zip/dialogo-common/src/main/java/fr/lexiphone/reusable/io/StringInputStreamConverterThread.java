package fr.lexiphone.reusable.io;

import java.io.IOException;
import java.io.InputStream;

/**
 * Thread dont la seule fonction est de manger un InputStream jusqu'� plus soif...
 * ... et � en renvoyer le contenu sous forme de String
 * @author clime
 */
public class StringInputStreamConverterThread extends Thread implements Runnable {
	private InputStream is;
	private StringBuffer buffer = new StringBuffer(256);

	/**
	 * 
	 */
	public StringInputStreamConverterThread(InputStream in_is) {
		super("StringInputStreamConverterThread");
		is = in_is;
		// Priorit� plus basse que l'appelant
		if (this.getPriority() > Thread.MIN_PRIORITY) {
			this.setPriority(this.getPriority() - 1);
		}
	}


	/* (non-Javadoc)
	 * @see java.lang.Runnable#run()
	 */
	public void run() {
		int currentChar;
		try {
			while ((currentChar = is.read()) != -1) {
				buffer.append((char) currentChar);
				yield();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}


	/**
	 * Renvoie la chaine de caract�res mang�e par ce thread
	 * @return String
	 */
	public String getString() {
		return buffer.toString();
	}

}
