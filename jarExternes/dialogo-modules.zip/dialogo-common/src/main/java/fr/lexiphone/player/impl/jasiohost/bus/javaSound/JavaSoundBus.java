package fr.lexiphone.player.impl.jasiohost.bus.javaSound;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.LeaderBus;

public class JavaSoundBus extends LeaderBus{
	
	public static String ID="Java Sound";
	private JavaSound javaSoundDriver = null;

	public JavaSoundBus() {
		super(ID);
		javaSoundDriver = new JavaSound(this);
//		initIhm();
	}
	
	@Override
	public boolean initDriver() {
		javaSoundDriver.init();
		return false;
	}
	
	@Override
	public void write(StereoBuffer aStereoBuffer) {
		byte [] buffer = JavaSound.sampleToDataLineFormat(aStereoBuffer.getLeftChannel(), aStereoBuffer.getRightChannel());
		javaSoundDriver.getOutputLine().write(buffer, 0, buffer.length);
	}


	@Override
	public boolean stopDriver() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changeFrameRate(double sampleRate) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public int getBufferSize() {
		return javaSoundDriver.getBufferSize();
	}

	public void bufferSwitch() {
		theListener.bufferSwitch();
	}
}
