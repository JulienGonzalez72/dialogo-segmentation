/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.util.ResourceBundle;

/**
 *
 * @author obicho
 */
public class SampleCenterConfig {
	private ISampleLocator sampleLocator;
	private String autoTextRootPath;
	private String samplesRootPath;
	private String language;
	private String i18nPath;
	private ResourceBundle i18nBundle;

	public SampleCenterConfig(ISampleLocator sampleLocator, String samplesRootPath, String autoTextRootPath) {
		if(sampleLocator!=null)this.sampleLocator = sampleLocator;
		else this.sampleLocator=new SampleLocator(samplesRootPath);
		this.autoTextRootPath = autoTextRootPath;
		this.samplesRootPath = samplesRootPath;
		language="FR";
	}

	ISampleLocator getSampleLocator() {
		return sampleLocator;
	}

	public String getAutoTextRootPath() {
		return autoTextRootPath;
	}

	public String getSamplesRootPath() {
		return samplesRootPath;
	}

	public String getLanguage() {
		return language;
	}

	public String getI18nPath() {
		return i18nPath;
	}

	public ResourceBundle getI18nBundle() {
		return i18nBundle;
	}

	public SampleCenterConfig setI18nPath(String path) {
		i18nPath=path;
		return this;
	}

	public SampleCenterConfig setI18nBundle(ResourceBundle bundle) {
		i18nBundle=bundle;
		return this;
	}
	
}
