
package fr.lexiphone.application.technical;
/**
 * <P>
 *  Interface de marquage des entit�s Application.
 * </P>
 * @author pprimot
 */

public interface IApplicationData {

}
