package fr.lexiphone.application.font;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FontHelper {
	private static final Log log = LogFactory.getLog(FontHelper.class);
	public static void installFonts(String basePath) {
		log.debug("installFonts "+basePath);
		File basePathFile=new File(basePath);
		if(basePathFile.exists()&&basePathFile.isDirectory()) {
			installFontsFromDirectory(basePathFile);
		}
	}
	private static void installFontsFromDirectory(File dir) {
		log.debug("installFontsFromDirectory "+dir);
		File[]list=dir.listFiles(new FileFilter() {
			
			@Override
			public boolean accept(File pathname) {
				if(pathname.isDirectory())return true;
				String name=pathname.getName();
				return name.toLowerCase().endsWith(".ttf");
			}
		});
		for(int i=0;i<list.length;i++) {
			if(list[i].isDirectory())installFontsFromDirectory(list[i]);
			else{
				int style;
				String nameLc=list[i].getName().toLowerCase();
				if(nameLc.contains("bold")&& nameLc.contains("italic")){
					style=Font.BOLD+Font.ITALIC;
				}else if(nameLc.contains("bold")){
					style=Font.BOLD;
				}else if(nameLc.contains("italic")){
					style=Font.ITALIC;
				}else style=Font.PLAIN;
				int type=Font.TRUETYPE_FONT;
				try {
					Font f=Font.createFont(type, list[i]).deriveFont(style);
					log.debug("registering font : "+f);
					GraphicsEnvironment.getLocalGraphicsEnvironment().registerFont(f.deriveFont(12f));
				} catch (FontFormatException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
	}

	public static List<String> getAuthorizedFamilies() {
		return Arrays.asList("OpenDyslexic3","Andika Basic","Serif","Verdana","Arial","Comic Sans MS");
	}
}
