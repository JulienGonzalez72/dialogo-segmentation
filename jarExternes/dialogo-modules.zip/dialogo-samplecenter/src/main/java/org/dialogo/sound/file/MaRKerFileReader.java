/*
 */
package org.dialogo.sound.file;

import alt.dev.szfoundation.SZProperties;
import alt.dev.szfoundation.SZPropertiesWriter;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Classe utilitaire pour la lecture des fichiers de marker WaveLab.
 */
public class MaRKerFileReader {
	private static final String FILE_CHARSET = "ISO-8859-1";
	private static final Pattern RE_MARKER = Pattern.compile("(Marker\\S*)");
	private static final String RE_MARKER_REPLACE = "\"$1\"=";
	private static final Pattern RE_BRACE = Pattern.compile("(})");
	private static final String RE_BRACE_REPLACE = "$1;";
	private static final Pattern RE_GENERAL = Pattern.compile("(Name|Pos|Type|Flags|Extra)=(.*)");
	private static final String RE_GENERAL_REPLACE = "\"$1\"=\"$2\";";

	private static final String MARKER_POS = "Pos";
	private static final String MARKER_TYPE = "Type";
	private static final int MARKER_TYPE_BEGIN = 11;
	private static final int MARKER_TYPE_END = 12;
	private static final Log log = LogFactory.getLog(MaRKerFileReader.class);

	/**
	 * 
	 */
	public MaRKerFileReader() {
		super();
	}

	/**
	 * Lit et transforme un fichier de markers WaveLab en un Property List (NeXT) correctement format�
	 * @param file
	 * @return
	 * @throws FileNotFoundException
	 * @throws IOException
	 */
	private static SZProperties readAndFixMRK(File file) throws FileNotFoundException, IOException {
		InputStream is = null;
		StringBuffer result;
		try {
			//log.debug("readAndFixMRK "+file);
			is = new FileInputStream(file);
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, Charset.forName(FILE_CHARSET)));//FileReader is not good enough
			result = new StringBuffer(Math.max(128, (int) (is.available() * 1.05)));
			result.append('{');
			while (reader.ready()) {
				String line = reader.readLine();
				Matcher matcher = RE_MARKER.matcher(line);
				line = matcher.replaceAll(RE_MARKER_REPLACE);
				matcher = RE_BRACE.matcher(line);
				line = matcher.replaceAll(RE_BRACE_REPLACE);
				matcher = RE_GENERAL.matcher(line);
				line = matcher.replaceAll(RE_GENERAL_REPLACE);
				result.append(line);
			}
			result.append('}');
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException ioe) {
				}
			}
		}

		is = new ByteArrayInputStream(result.toString().getBytes(SZPropertiesWriter.Encoding));
		SZProperties plist = new SZProperties();
		plist.load(is);
		//Object result = SZPropertiesReader.readObject(is);
		return plist;
	}

	protected static List<Zone> szPropertiesToZones(final Map<Object, Map<String, String>> props) {
		List<Zone> result = new ArrayList<>(props.size() / 2 + 1);
		// Etape 1 : ordonner
		SortedMap<Object, Map<String, String>> tempProps = new TreeMap<>(new Comparator<Object>() {
			/** {@inheritdoc} */
			@Override
			public int compare(Object o1, Object o2) {
				Map<String, String> m1 = props.get(o1);
				Map<String, String> m2 = props.get(o2);
				int time1 = getIntFromMap(m1, MARKER_POS);
				int time2 = getIntFromMap(m2, MARKER_POS);
				int type1 = getIntFromMap(m1, MARKER_TYPE);
				int type2 = getIntFromMap(m2, MARKER_TYPE);
				if (time1 != time2) {
					return time1 - time2;
				} else {
					return type2 - type1;
				}
			}
		});
		Iterator<Map.Entry<Object,Map<String, String>>> iter = props.entrySet().iterator();
		while (iter.hasNext()) {
			Map.Entry<Object,Map<String, String>> entry = iter.next();
			tempProps.put(entry.getKey(), entry.getValue());
		}
		// Etape 2 : convertir les markers en Zone
		iter = tempProps.entrySet().iterator();
		while (iter.hasNext()) {
			// marker 1
			Map.Entry<Object,Map<String, String>> entry = iter.next();
			Map<String, String> value1 = entry.getValue();
			int type1 = getIntFromMap(value1, MARKER_TYPE);
			int time1 = getIntFromMap(value1, MARKER_POS);
			if (type1 != MARKER_TYPE_BEGIN) {
				System.out.println("Unexpected MaRKer type: " + type1 + " at "+time1+"; was expecting: " + MARKER_TYPE_BEGIN);
				return Collections.emptyList();
			}

			// marker 2
			if (! iter.hasNext()) {
				System.out.println("Missing end MaRKer!");
				return result;
			}
			Map<String, String> value2 = iter.next().getValue();
			int type2 = getIntFromMap(value2, MARKER_TYPE);
			int time2 = getIntFromMap(value2, MARKER_POS);
			if (type2 != MARKER_TYPE_END) {
				System.out.println("Unexpected MaRKer type: " + type2 + " at "+time2+"; was expecting: " + MARKER_TYPE_END);
				return Collections.emptyList();
			}

			Zone zone = new Zone(time1, time2);
			result.add(zone);
		}
		return result;
	}
	private static int getIntFromMap(Map<String, String> map, String key) {
		return Integer.parseInt(map.get(key));
	}

	/**
	 * Charge un fichier Marker (.MRK) issu de WaveLab et le convertie en liste de Zone.
	 * Chaque zone repr�sente une zone de parole. Le "son" entre chaque zone est suppos�
	 * �tre du silence.
	 * @param file
	 * @return List&lt;Zone&gt;
	 */
	public static List<Zone> loadZonesFromMarkerFile(File file) {
		List<Zone> result = Collections.emptyList();
		try {
			SZProperties plist = readAndFixMRK(file);
			result = szPropertiesToZones(plist.getMap("Markers", Collections.emptyMap()));
			checkZones(file, result);
		} catch (IOException ioe) {
		}
		return result;
	}
	/**
	 * Validates that zones are contigous.
	 * @param zones
	 */
	private static void checkZones(File file, List<Zone> zones) throws IllegalArgumentException {
		if (zones == null || zones.size() <= 1) {
			return;
		}
		Zone previous = null;
		for (Zone zone : zones) {
			if (previous == null) {
				previous = zone;
				continue;
			}
			if (zone.getBegin() < previous.getEnd()) {
				throw new IllegalArgumentException("" + file + ": overlapping zones: " + previous + " / " + zone);
			}
			previous = zone;
		}
	}

	public static void main(String[] args) throws Exception {
		List<Zone> zones = loadZonesFromMarkerFile(new File("Prg/work/mp3/RE0File.MRK"));//"src/alt/dev/szfoundation/Example.utf8.plist"
		System.out.println(zones);
	}
}
