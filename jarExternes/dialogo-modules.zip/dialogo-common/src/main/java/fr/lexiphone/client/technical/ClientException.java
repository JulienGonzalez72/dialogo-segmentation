package fr.lexiphone.client.technical;

public class ClientException extends Exception { // extends NestableException

	/**
	 * 
	 */
	public ClientException() {
		super();
	}

	/**
	 * Constructeur avec message.
	 * @param message
	 */
	public ClientException(String message) {
		super(message);
	}
	
	/**
	 * @param cause
	 */
	public ClientException(Throwable cause) {
		super(cause);
	}

	/**
	 * Constructeur avec message et exception d'origine.
	 * @param message
	 * @param cause
	 */
	public ClientException(String message, Throwable cause) {
		super(message, cause);
	}

	/** SURCHARGE : pour afficher aussi l'exception de d�part. */
	public void printStackTrace() {
		super.printStackTrace();
		/*
		System.err.println("ERREUR DANS LA COUCHE CLIENT : ");
		super.printStackTrace();
		if (getOriginException()!=null) {
			System.err.println("ORIGINE DE L'ERREUR : ");
			getOriginException().printStackTrace();	
		}
		*/
	}

}
