/*
 */
package org.dialogo.sound.file;

import org.apache.commons.lang.builder.HashCodeBuilder;

/**
 * Zone temporelle repr�sentant les phrases/mots dans le fichier sonore.
 * 1 zone == 2 Markeurs WaveLab (exprim�s en nombre de frames).
 */
public class Zone {
	protected long begin;
	protected long end;

	/**
	 * 
	 */
	public Zone(int begin, int end) {
		super();
		this.begin = begin;
		this.end = end;
		if (begin > end) {
			throw new IllegalArgumentException("Begin ("+begin+") should be before end ("+end+')');
		}
	}

	/** {@inheritdoc} */
	@Override
	public String toString() {
		return getClass().getName() + '[' + begin + ',' + end + ']';
	}

	/** {@inheritdoc} */
	@Override
	public boolean equals(Object obj) {
		if (!( obj instanceof Zone)) {
			return false;
		}
		Zone that = (Zone) obj;
		return this.begin == that.begin && this.end == that.end;
	}

	@Override
	public int hashCode() {
		return new HashCodeBuilder().append(begin).append(end).toHashCode();
	}

	/**
	 * @return begin frame #
	 */
	public long getBegin() {
		return begin;
	}

	/**
	 * @return end frame #
	 */
	public long getEnd() {
		return end;
	}

	public String toString(float sampleRate) {
		StringBuilder result = new StringBuilder(32);
		long beginMillis = framesToMilliSeconds(begin, sampleRate);
		long endMillis = framesToMilliSeconds(end, sampleRate);
		result.append("Zone(");
		result.append(endMillis - beginMillis);
		result.append("ms");
		result.append(": ");
		result.append(begin).append('=').append(getPosTimeFormated(beginMillis));
		result.append(" -> ");
		result.append(end).append('=').append(getPosTimeFormated(endMillis));
		result.append(')');
		return result.toString();
	}
	private static long framesToMilliSeconds(long frames, float sampleRate) {
		return sampleRate == 0 ? 0 : (long) (frames / sampleRate * 1000.0);
	}
	/**
	 * get the pos in a formated time like "hh:mm:ss.SS"
	 * @return the formatted time in a String
	 */
	private static String getPosTimeFormated(long time) {
		StringBuffer buff = new StringBuffer(13);
		long millis = time % 1000;
		long rest = time / 1000; // seconds
		long hour = rest / 3600;
		rest = rest % 3600;
		long minute = rest / 60;
		rest = rest % 60;
		long second = rest;
		if (hour < 10) {
			buff.append('0');
		}
		buff.append(hour);
		buff.append(':');
		if (minute < 10) {
			buff.append('0');
		}
		buff.append(minute);
		buff.append(':');
		if (second < 10) {
			buff.append('0');
		}
		buff.append(second);
		buff.append('.').append(millis);
		return buff.toString();
	}
}
