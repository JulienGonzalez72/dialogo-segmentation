package fr.lexiphone.player.impl.jasiohost.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import fr.lexiphone.player.impl.jasiohost.provider.LineControl;

public class LinePanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JSlider jSliderGainLeft = null;
	private JSlider jSliderGainRight = null;
	private JPanel jPanelSlider = null;
	private JButton jButtonMute = null;
	private JButton jButtonConfig = null;
	private String name = null;
	private LineControl aLine = null;
	private JPanel jPanelBus = null;

	/**
	 * This is the default constructor
	 */
	public LinePanel(LineControl aControl) {
		super();
		this.name = aControl.getName();
		this.aLine = aControl;
		aControl.setLineIhm(this);
		initialize();
	}

	@Override
	public String getName() {
		return this.name;
	}

	/**
	 * This method initializes this
	 */
	private void initialize() {
		JPanel aPanel = new JPanel(new BorderLayout());
		aPanel.setSize(70, 254);

		// nom du provider
		JLabel name = new JLabel(getName());
		name.setAlignmentX(Component.CENTER_ALIGNMENT);
		aPanel.add(name, BorderLayout.PAGE_START);
		// add sliders
		getJPanelSlider().setAlignmentX(Component.CENTER_ALIGNMENT);
		aPanel.add(getJPanelSlider(), BorderLayout.CENTER);
		// panel des boutons
		JPanel jPanelButton = new JPanel(new BorderLayout());
		jPanelButton.add(getJButtonMute(), BorderLayout.PAGE_END);
		if (this.aLine.haveIhm())
			jPanelButton.add(getJButtonConfig(), BorderLayout.CENTER);
		jPanelButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		aPanel.add(jPanelButton, BorderLayout.PAGE_END);

		this.setLayout(new BorderLayout());
		this.add(aPanel, BorderLayout.CENTER);
		this.add(getBusPanel(), BorderLayout.PAGE_END);
		this.setBorder(BorderFactory.createEmptyBorder());
	}

	private JPanel getBusPanel() {
		if (jPanelBus == null) {
			jPanelBus = new JPanel();
			jPanelBus.setLayout(new BoxLayout(jPanelBus, BoxLayout.Y_AXIS));
			jPanelBus.add(busCheckBox(true));
			jPanelBus.add(busCheckBox(false));
		}
		return jPanelBus;
	}

	private JCheckBox busCheckBox(boolean selected) {
		JCheckBox aCheck = new JCheckBox();
		aCheck.setAlignmentX(Component.CENTER_ALIGNMENT);
		aCheck.setAlignmentY(Component.CENTER_ALIGNMENT);
		aCheck.setSelected(selected);
		return aCheck;
	}

	private JButton getJButtonConfig() {
		if (jButtonConfig == null) {
			jButtonConfig = new JButton();
			jButtonConfig.setText("Config");
			jButtonConfig.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					aLine.getIhm().initAndShowIhm();
				}
			});
		}
		return jButtonConfig;
	}

	private JSlider getJSliderGainLeft() {
		if (jSliderGainLeft == null) {
			jSliderGainLeft = new JSlider(SwingConstants.VERTICAL);
			jSliderGainLeft.setMaximum(10);
			jSliderGainLeft.setMinimum(0);
			jSliderGainLeft.setMajorTickSpacing(2);
			jSliderGainLeft.setPaintTicks(true);
			jSliderGainLeft.setToolTipText("Master Left");
			jSliderGainLeft.setValue(2);
			jSliderGainLeft.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					aLine.setLeftLevel(getLeftGain());
				}
			});
		}
		return jSliderGainLeft;
	}

	/**
	 * get the value of the gain for the device
	 * 
	 * @return level between 0 and 1
	 */
	public float getLeftGain() {
		return (float) (getJSliderGainLeft().getValue() / 10.0);
	}

	public void setLeftGain(float value) {
		getJSliderGainLeft().setValue(Math.round(value * 10));
		getJSliderGainLeft().getParent().validate();
	}

	/**
	 * This method initializes jSliderPan
	 * 
	 * @return javax.swing.JSlider
	 */
	private JSlider getJSliderGainRight() {
		if (jSliderGainRight == null) {
			jSliderGainRight = new JSlider(SwingConstants.VERTICAL);
			jSliderGainRight.setMaximum(10);
			jSliderGainRight.setMinimum(0);
			jSliderGainRight.setMajorTickSpacing(2);
			jSliderGainRight.setPaintTicks(true);
			jSliderGainRight.setToolTipText("Master Right");
			jSliderGainRight.setValue(2);
			jSliderGainRight.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					aLine.setRightLevel(getRightGain());
				}
			});
		}
		return jSliderGainRight;
	}

	/**
	 * get the value of the pan for the device
	 * 
	 * @return level between -1 and 1
	 */
	public float getRightGain() {
		return (float) (getJSliderGainRight().getValue() / 10.0);
	}

	public void setRightGain(float value) {
		getJSliderGainRight().setValue(Math.round(value * 10));
		getJSliderGainRight().getParent().validate();
	}

	/**
	 * This method initializes jPanelSlider
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJPanelSlider() {
		if (jPanelSlider == null) {
			FlowLayout flowLayout = new FlowLayout();
			flowLayout.setVgap(5);
			jPanelSlider = new JPanel();
			jPanelSlider.setLayout(flowLayout);
			jPanelSlider.add(getJSliderGainLeft(), null);
			jPanelSlider.add(getJSliderGainRight(), null);
		}
		return jPanelSlider;
	}

	/**
	 * This method initializes jButtonMute
	 * 
	 * @return javax.swing.JButton
	 */
	private JButton getJButtonMute() {
		if (jButtonMute == null) {
			jButtonMute = new JButton();
			jButtonMute.setText("Mute");
			jButtonMute.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					aLine.setMute(!aLine.getMute());
					if (aLine.getMute())
						jButtonMute.setForeground(Color.red);
					else
						jButtonMute.setForeground(null);
				}
			});
		}
		return jButtonMute;
	}
}
