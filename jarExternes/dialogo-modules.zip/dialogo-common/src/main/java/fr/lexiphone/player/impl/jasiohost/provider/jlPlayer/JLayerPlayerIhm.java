package fr.lexiphone.player.impl.jasiohost.provider.jlPlayer;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;

import javax.swing.AbstractAction;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.Timer;

import javazoom.jlgui.basicplayer.BasicPlayerException;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.impl.jasiohost.ihm.ConfigIhm;

public class JLayerPlayerIhm extends ConfigIhm implements ActionListener, MouseListener {

	private static final long serialVersionUID = -8071042746189506023L;
	
	private JlayerPlayer playerInstance = null;
	
	private int precision = 1000;
	private Timer aTimer = null;
	
	private JPanel jPanelControlButton = null;
	private JButton jButtonPrevious;
	private JButton jButtonNext;
	private JPanel jPanelPlayPauseStop = null;
	private JButton jButtonPP = null;
	private JButton jButtonStop;
	private JButton jButtonRecurrence = null;
	private JProgressBar jProgressBar;
	private JPanel jPanelState;
	private JLabel jLabelState = null;
	private JPanel jPanelInformation;
	private JPanel jPanelPosMilli;
	private JLabel jLabelPosMilli;
	private JPanel jPanelGoToTime;
	private JButton jButtonGoTime;
	private JPanel jPanelTimeToGo;
	private JPanel jPanelHourToGo;
	private JTextField jTextFieldHourToGo;
	private JPanel jPanelMinuteToGo;
	private JTextField jTextFielMinuteToGo;
	private JPanel jPanelSecondToGo;
	private JTextField jTextFieldSecondToGo;
	private JPanel jPanelMilliSecondToGo;
	private JTextField jTextFieldMilliSecondToGo;
	private JPanel jPanelFrameToGo;
	private JPanel jPanelFrames;
	private JTextField jTextFieldFrames;
	private JButton jButtonFrameGo;
	private JPanel jPanelFile;
	private JTextField jTextFieldFile;

	private JButton jButtonFile;

	private JPanel jPanelStartStopFrame;

	private Container masterPanel;

	public JLayerPlayerIhm(JlayerPlayer player) {
		super();
		playerInstance = player;
	}
	
	private JPanel getJPanelControlButton() {
		if (jPanelControlButton == null) {
			jPanelControlButton = new JPanel(new BorderLayout());
			jPanelControlButton.add(getJButtonPrevious(), BorderLayout.LINE_START);
			jPanelControlButton.add(getJPanelPlayPauseStop(), BorderLayout.CENTER);
			jPanelControlButton.add(getJButtonNext(), BorderLayout.LINE_END);
			jPanelControlButton.add(getJProgressBar(), BorderLayout.PAGE_END);
		}
		return jPanelControlButton;
	}
	
	private JProgressBar getJProgressBar() {
		if (jProgressBar == null) {
			jProgressBar = new JProgressBar(0, precision);
			jProgressBar.addMouseListener(this);
		}
		return jProgressBar;
	}
	
	private JButton getJButtonPrevious() {
		if (jButtonPrevious == null) {
			jButtonPrevious = new JButton("back");
			jButtonPrevious.setActionCommand("back");
			jButtonPrevious.addActionListener(this);
		}
		return jButtonPrevious;
	}
	
	private JButton getJButtonNext(){
		if (jButtonNext == null) {
			jButtonNext = new JButton("next");
			jButtonNext.setActionCommand("next");
			jButtonNext.addActionListener(this);
		}
		return jButtonNext;
	}
	
	private JPanel getJPanelPlayPauseStop() {
		if (jPanelPlayPauseStop == null) {
			jPanelPlayPauseStop = new JPanel();
			jPanelPlayPauseStop.add(getJButtonPP());
			jPanelPlayPauseStop.add(getJButtonStop());
			jPanelPlayPauseStop.add(getJButtonRecurrence());
		}
		return jPanelPlayPauseStop;
	}
	
	private JButton getJButtonPP() {
		if (jButtonPP == null) {
			jButtonPP = new JButton("Play/Pause");
			jButtonPP.setActionCommand("PP");
			jButtonPP.addActionListener(this);
		}
		return jButtonPP;
	}
	
	private JButton getJButtonStop() {
		if (jButtonStop == null) {
			jButtonStop = new JButton("stop");
			jButtonStop.setActionCommand("stop");
			jButtonStop.addActionListener(this);
		}
		return jButtonStop;
	}
	
	private JButton getJButtonRecurrence() {
		if (jButtonRecurrence == null) {
			jButtonRecurrence = new JButton("Recurrence");
			jButtonRecurrence.setActionCommand("recurrence");
			jButtonRecurrence.addActionListener(this);
		}
		return jButtonRecurrence;
	}
	
	private JPanel getJPanelInformation() {
		if (jPanelInformation == null) {
			jPanelInformation = new JPanel();
			jPanelInformation.add(getJPanelState());
			jPanelInformation.add(getJPanelPosMilli());
		}
		return jPanelInformation;
	}
	
	private JPanel getJPanelState() {
		if (jPanelState == null) {
			jPanelState = new JPanel(new BorderLayout());
			jPanelState.add(new JLabel("�tat : "), BorderLayout.LINE_START);
			jPanelState.add(getJLabelState());
		}
		return jPanelState;
	}
	
	private JLabel getJLabelState() {
		if (jLabelState == null) {
			jLabelState = new JLabel();
		}
		return jLabelState;
	}
	
	private JPanel getJPanelPosMilli() {
		if (jPanelPosMilli == null) {
			jPanelPosMilli = new JPanel(new BorderLayout());
			jPanelPosMilli.add(new JLabel("Position : "), BorderLayout.LINE_START);
			jPanelPosMilli.add(getJLabelPosMilli());
		}
		return jPanelPosMilli;
	}
	
	private JLabel getJLabelPosMilli() {
		if (jLabelPosMilli == null) {
			jLabelPosMilli = new JLabel();
		}
		return jLabelPosMilli;
	}
	
	private JPanel getJPanelGoToTime(){
		if (jPanelGoToTime == null) {
			jPanelGoToTime = new JPanel(new BorderLayout());
			jPanelGoToTime.add(getJPanelTimeToGo(), BorderLayout.CENTER);
			jPanelGoToTime.add(getJButtonGoTime(), BorderLayout.LINE_END);
		}
		return jPanelGoToTime;
	}
	
	private JPanel getJPanelTimeToGo() {
		if (jPanelTimeToGo == null) {
			jPanelTimeToGo = new JPanel();
			jPanelTimeToGo.add(getJPanelHourToGo());
			jPanelTimeToGo.add(getJPanelMinuteToGo());
			jPanelTimeToGo.add(getJPanelSecondToGo());
			jPanelTimeToGo.add(getJPanelMilliSecondToGo());
		}
		return jPanelTimeToGo;
	}
	
	private JPanel getJPanelHourToGo() {
		if (jPanelHourToGo == null) {
			jPanelHourToGo = new JPanel();
			jPanelHourToGo.add(new JLabel("H :"));
			jPanelHourToGo.add(getJTextFieldHourToGo());
		}
		return jPanelHourToGo;
	}
	
	private JTextField getJTextFieldHourToGo() {
		if (jTextFieldHourToGo == null) {
			jTextFieldHourToGo = new JTextField(2);
			jTextFieldHourToGo.setText("0");
		}
		return jTextFieldHourToGo;
	}
	
	private JPanel getJPanelMinuteToGo() {
		if (jPanelMinuteToGo == null) {
			jPanelMinuteToGo = new JPanel();
			jPanelMinuteToGo.add(new JLabel("M :"));
			jPanelMinuteToGo.add(getJTextFieldMinuteToGo());
		}
		return jPanelMinuteToGo;
	}
	
	private JTextField getJTextFieldMinuteToGo() {
		if (jTextFielMinuteToGo == null) {
			jTextFielMinuteToGo = new JTextField(2);
			jTextFielMinuteToGo.setText("0");
		}
		return jTextFielMinuteToGo;
	}
	
	private JPanel getJPanelSecondToGo() {
		if (jPanelSecondToGo == null) {
			jPanelSecondToGo = new JPanel();
			jPanelSecondToGo.add(new JLabel("s :"));
			jPanelSecondToGo.add(getJTextFielSecondToGo());
		}
		return jPanelSecondToGo;
	}
	
	private JTextField getJTextFielSecondToGo() {
		if (jTextFieldSecondToGo == null) {
			jTextFieldSecondToGo = new JTextField(2);
			jTextFieldSecondToGo.setText("0");
		}
		return jTextFieldSecondToGo;
	}

	private JPanel getJPanelMilliSecondToGo() {
		if (jPanelMilliSecondToGo == null) {
			jPanelMilliSecondToGo = new JPanel();
			jPanelMilliSecondToGo.add(new JLabel("ms :"));
			jPanelMilliSecondToGo.add(getJTextFielMilliSecondToGo());
		}
		return jPanelMilliSecondToGo;
	}
	
	private JTextField getJTextFielMilliSecondToGo() {
		if (jTextFieldMilliSecondToGo == null) {
			jTextFieldMilliSecondToGo = new JTextField(4);
			jTextFieldMilliSecondToGo.setText("0");
		}
		return jTextFieldMilliSecondToGo;
	}
	
	private JButton getJButtonGoTime() {
		if (jButtonGoTime == null) {
			jButtonGoTime = new JButton("go");
			jButtonGoTime.setActionCommand("goTime");
			jButtonGoTime.addActionListener(this);
		}
		return jButtonGoTime;
	}
	
	private JPanel getJPanelFrameToGo() {
		if (jPanelFrameToGo == null) {
			jPanelFrameToGo = new JPanel(new BorderLayout());
			jPanelFrameToGo.add(getJPanelFrames(), BorderLayout.CENTER);
			jPanelFrameToGo.add(getJButtonFrameGo(), BorderLayout.LINE_END);
		}
		return jPanelFrameToGo;
	}
	
	private JPanel getJPanelFrames(){
		if (jPanelFrames == null) {
			jPanelFrames = new JPanel(new BorderLayout());
			jPanelFrames.add(new JLabel("Frames :"), BorderLayout.LINE_START);
			jPanelFrames.add(getJTextFieldFrames());
		}
		return jPanelFrames;
	}
	
	private JTextField getJTextFieldFrames() {
		if (jTextFieldFrames == null) {
			jTextFieldFrames = new JTextField();
			jTextFieldFrames.setText("0");
		}
		return jTextFieldFrames;
	}
	
	private JPanel getJPanelFile() {
		if (jPanelFile == null) {
			jPanelFile = new JPanel(new BorderLayout());
			jPanelFile.add(getJTextFieldFile(), BorderLayout.CENTER);
			jPanelFile.add(getJButtonFile(), BorderLayout.LINE_END);
		}
		return jPanelFile;
	}
	
	private JTextField getJTextFieldFile() {
		if (jTextFieldFile == null) {
			jTextFieldFile = new JTextField();
			jTextFieldFile.setEditable(false);
		}
		return jTextFieldFile;
	}
	
	private JButton getJButtonFile() {
		if (jButtonFile == null) {
			jButtonFile = new JButton("browse");
			jButtonFile.setActionCommand("browse");
			jButtonFile.addActionListener(this);
		}
		return jButtonFile;
	}
	
	private JPanel getJPanelStartStopFrameToGo() {
		if (jPanelStartStopFrame == null) {
			jPanelStartStopFrame = new JPanel(new BorderLayout());
			JPanel jPanelStartStop = new JPanel();
			jPanelStartStop.add(new JLabel("Start at: "));
			final JTextField textFieldStart = new JTextField(6);
			jPanelStartStop.add(textFieldStart);
			jPanelStartStop.add(new JLabel("Stop at: "));
			final JTextField textFieldStop = new JTextField(6);
			jPanelStartStop.add(textFieldStop);
			jPanelStartStopFrame.add(jPanelStartStop, BorderLayout.LINE_START);
			JButton goButton = new JButton("GO");
			goButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					try {
						playerInstance.play(Integer.parseInt(textFieldStart.getText(), 10),
								Integer.parseInt(textFieldStop.getText(), 10));
					} catch (BasicPlayerException bpe) {
						bpe.printStackTrace();
					}
				}
			});
			jPanelStartStopFrame.add(goButton, BorderLayout.LINE_END);
		}
		return jPanelStartStopFrame;
	}
	
	private JButton getJButtonFrameGo() {
		if (jButtonFrameGo == null) {
			jButtonFrameGo = new JButton("GO");
			jButtonFrameGo.setActionCommand("goFrame");
			jButtonFrameGo.addActionListener(this);
		}
		return jButtonFrameGo;
	}
	
	@Override
	public void initAndShowIhm() {
		if (masterPanel == null) {
			masterPanel = new JPanel();
			masterPanel.setLayout(new BoxLayout(masterPanel, BoxLayout.PAGE_AXIS));
			masterPanel.add(getJPanelFile());
			masterPanel.add(getJPanelControlButton());
			masterPanel.add(getJPanelInformation());
			masterPanel.add(getJPanelGoToTime());
			masterPanel.add(getJPanelFrameToGo());
			masterPanel.add(getJPanelStartStopFrameToGo());
			
			this.setLayout(new BorderLayout());
			this.setSize(new Dimension(400, 300));
			this.add(masterPanel, BorderLayout.PAGE_START);
		}
        if (aTimer == null) {
        	aTimer = new Timer(1000, new AbstractAction() {
				private static final long serialVersionUID = 1L;
				@Override
        		public void actionPerformed(ActionEvent e) {
        			try {
        				getJProgressBar().setValue((int) (playerInstance.getPositionAsPercent() * precision));
        				getJLabelPosMilli().setText(playerInstance.getPosTimeFormated());
        			} catch (BasicPlayerException e1) {
        				e1.printStackTrace();
        			}
        			getJProgressBar().validate();
        		}
        	});
        }
        
        aTimer.start();
        this.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				aTimer.stop();
			}
        });
		setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		try {
		if(e.getActionCommand().equals("recurrence")){
			try {
				playerInstance.recurrenceJump();
			} catch (BasicPlayerException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand().equals("PP")) {
			if (playerInstance.getState() == PlayerState.STOPPED)
				playerInstance.play();
			else if (playerInstance.getState() == PlayerState.PLAYING)
				playerInstance.pause();
			else if (playerInstance.getState() == PlayerState.PAUSED)
				playerInstance.resume();
		} else if (e.getActionCommand().equals("stop")) {
			playerInstance.stop();
		} else if (e.getActionCommand().equals("back")) {
			try {
				playerInstance.seek(-1000);
			} catch (BasicPlayerException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand().equals("next")) {
			try {
				playerInstance.seek(1000);
			} catch (BasicPlayerException e1) {
				e1.printStackTrace();
			}
		} else if (e.getActionCommand().equals("goTime")) {
			playerInstance.setPosAt(Integer.parseInt(getJTextFieldHourToGo().getText(), 10),
					Integer.parseInt(getJTextFieldMinuteToGo().getText(), 10),
					Integer.parseInt(getJTextFielSecondToGo().getText(), 10),
					Integer.parseInt(getJTextFielMilliSecondToGo().getText(), 10));
		} else if (e.getActionCommand().equals("goFrame")) {
			playerInstance.setPosFrames(Integer.parseInt(getJTextFieldFrames().getText(), 10));
		} else if (e.getActionCommand().equals("browse")) {
			JFileChooser fc = new JFileChooser(System.getProperty("user.dir"));
    		fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
    		int returnVal = fc.showOpenDialog(this);
    		if (returnVal == JFileChooser.APPROVE_OPTION){
				File selectedFile = fc.getSelectedFile();
				getJTextFieldFile().setText(selectedFile.getPath());
				playerInstance.open(selectedFile);
    		}
		}
		} catch (BasicPlayerException bpe) {
			bpe.printStackTrace();
		}
	}
	
	public void setLabelState(String stateText) {
		getJLabelState().setText(stateText);
		getJLabelState().validate();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		final int xMouse = e.getX();
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				float value = new Float(xMouse) / jProgressBar.getWidth() * precision;
				jProgressBar.setValue((int) value);
				try {
					playerInstance.setPositionAsPercent(value / precision);
				} catch (BasicPlayerException e) {
					e.printStackTrace();
				}
			}
		});
	}
	@Override
	public void mousePressed(MouseEvent e) {
	}
	@Override
	public void mouseReleased(MouseEvent e) {
	}
	@Override
	public void mouseEntered(MouseEvent e) {
	}
	@Override
	public void mouseExited(MouseEvent e) {
	}

}
