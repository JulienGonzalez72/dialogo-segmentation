package fr.lexiphone.player.impl.jasiohost.provider;

public interface ILineControl {

	/**
	 * @return facteur multiplicatif 0 &lt;= left level &lt;= 1
	 */
	float getLeftLevel();
	void setLeftLevel(float leftOutput);
	/**
	 * @return facteur multiplicatif 0 &lt;= right level &lt;= 1
	 */
	float getRightLevel();
	void setRightLevel(float rightOutput);
	float getSoundLevelBoost();
	void setSoundLevelBoost(float soundLevelBoost);
	boolean getMute();
	void setMute(boolean mute);
}
