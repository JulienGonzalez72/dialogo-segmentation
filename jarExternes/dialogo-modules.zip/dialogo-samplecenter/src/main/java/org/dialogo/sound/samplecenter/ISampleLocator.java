/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.util.List;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author obicho
 */
public interface ISampleLocator {
	public List<Mp3Wrapper> getSamplesByPhaseTypeFilter(String filter);
	public List<Mp3Wrapper> getSamplesBySegmentation(String segmentation);
	public List<Mp3Wrapper> getSamplesBySegmentationAndType(String segmentation, String type);
	public List<Mp3Wrapper> getSamplesBySegmentationAndTextLevel(String segmentation,String textLevel);
	//public List<Mp3Wrapper> getSamplesBySegmentationAndTextLevel(String name,int textLevel);
	public List<Mp3Wrapper> getSamplesBySegmentationTypeAndTextLevel(String segmentation, String type, int textLevel);
	public String segmentationForFilter(String filter);
	public List<Mp3Wrapper> getMp3FilesList();
	public List<Mp3Wrapper> getMp3FilesList(boolean onlyWithProps);
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String name, String textLevel);
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String name, int textLevel);

	public List<Mp3Wrapper> getSamplesByName(String name);
	public Mp3Wrapper findByName(String name);

	public Mp3Wrapper findByFileName(String rp);

	public Mp3Wrapper findByUid(String uidsample);

	public List<String> getLanguagesInProperties();
}
