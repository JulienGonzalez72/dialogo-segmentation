/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.dialogo.sound.file.Mp3Wrapper;

/**
 *
 * @author haerwynn
 */
public class CachingSampleLocator extends SampleLocator{

	private Map<String,Mp3Wrapper>mapUids;
	private Map<String,Mp3Wrapper>mapNames;
	private Map<String,Mp3Wrapper>mapFileNames;
	public CachingSampleLocator(String samplesRootPath) {
		super(samplesRootPath);
		mapUids=new HashMap<>();
		mapNames=new HashMap<>();
		mapFileNames=new HashMap<>();
	}

	/*@Override
	public List<Mp3Wrapper> getSamplesByPhaseTypeFilter(String filter) {
		return super.getSamplesByPhaseTypeFilter(filter);
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentation(String segmentation) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationAndType(String segmentation, String type) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationAndTextLevel(String segmentation, String textLevel) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public List<Mp3Wrapper> getSamplesBySegmentationTypeAndTextLevel(String segmentation, String type, int textLevel) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public String segmentationForFilter(String filter) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}*/

	@Override
	public List<Mp3Wrapper> getMp3FilesList() {
		return super.getMp3FilesList();
	}

	@Override
	public List<Mp3Wrapper> getMp3FilesList(boolean onlyWithProps) {
		List<Mp3Wrapper> l = super.getMp3FilesList(onlyWithProps);
		if(!onlyWithProps){
			return l;
		}
		for (int i = 0; i < l.size(); i++) {
			Mp3Wrapper w = l.get(i);
			if(!mapUids.containsKey(w.getUid()))mapUids.put(w.getUid(),w);
		}
		return l;
	}

	/*@Override
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String name, String textLevel) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public List<Mp3Wrapper> getSamplesByFilterAndTextLevel(String name, int textLevel) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

	@Override
	public List<Mp3Wrapper> getSamplesByName(String name) {
		throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}*/

	@Override
	public Mp3Wrapper findByName(String name) {
		if(mapNames.containsKey(name))return mapNames.get(name);
		Mp3Wrapper w = super.findByName(name);
		mapNames.put(name,w);
		if(w==null)return null;
		mapUids.put(w.getUid(),w);
		mapFileNames.put(w.getFileName(),w);
		return w;
	}

	@Override
	public Mp3Wrapper findByFileName(String name) {
		if(mapFileNames.containsKey(name))return mapFileNames.get(name);
		Mp3Wrapper w = super.findByFileName(name);
		mapFileNames.put(name,w);
		if(w==null)return null;
		mapUids.put(w.getUid(),w);
		mapNames.put(w.getName(),w);
		return w;
	}

	@Override
	public Mp3Wrapper findByUid(String uid) {
		if(mapUids.containsKey(uid))return mapUids.get(uid);
		Mp3Wrapper w = super.findByUid(uid);
		mapUids.put(uid,w);
		if(w==null)return null;
		mapNames.put(w.getName(),w);
		mapFileNames.put(w.getFileName(),w);
		return w;
	}

}
