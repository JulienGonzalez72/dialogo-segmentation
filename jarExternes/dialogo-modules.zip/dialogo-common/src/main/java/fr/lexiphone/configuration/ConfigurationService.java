/**
 * 
 */
package fr.lexiphone.configuration;

import java.io.File;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author C&eacute;drik LIME
 */
public class ConfigurationService {

	private static final Log log = LogFactory.getLog(ConfigurationService.class);

	public ConfigurationService() {
		super();
	}

	public DLGConfiguration getConfiguration(DLGConfiguration.Type type, String fileName) throws ConfigurationException {
		File f = new File(type.folder.getDirectory(), fileName);
		if (!f.exists()) {
			log.error(f.getAbsolutePath() + " doesn't exist");
		}
		return new DLGConfiguration(f);
	}

}
