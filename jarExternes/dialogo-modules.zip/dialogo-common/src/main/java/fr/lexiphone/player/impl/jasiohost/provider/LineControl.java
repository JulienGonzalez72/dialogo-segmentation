package fr.lexiphone.player.impl.jasiohost.provider;

import fr.lexiphone.player.impl.jasiohost.ihm.ConfigIhm;
import fr.lexiphone.player.impl.jasiohost.ihm.LinePanel;


public abstract class LineControl implements ILineControl {

	protected volatile float rightLevel;
	protected volatile float leftLevel;
	protected volatile float soundLevelBoost = 1.0f;
	protected volatile boolean mute = false;
	protected ConfigIhm configIhm = null;
	protected LinePanel lineIhm = null;
	private String name = null;
	
	public LineControl(String name) {
		this.name = name;
		rightLevel = (float) 0.2;
		leftLevel = (float) 0.2;
	}
	
	@Override
	public void setLeftLevel(float leftOutput) {
		if(leftOutput < 0 || leftOutput > 1)
			throw new IllegalArgumentException("Left Level out of range: " + leftOutput);
		this.leftLevel = leftOutput * soundLevelBoost;
		if (lineIhm != null) {
			lineIhm.setLeftGain(leftOutput);
		}
	}
	
	@Override
	public float getLeftLevel() {
		return this.leftLevel;
	}
	
	@Override
	public void setRightLevel(float rightOutput) {
		if(rightOutput < 0 || rightOutput > 1)
			throw new IllegalArgumentException("Right Level out of range: " + rightOutput);
		this.rightLevel = rightOutput * soundLevelBoost;
		if (lineIhm != null) {
			lineIhm.setRightGain(rightOutput);
		}
	}
	
	@Override
	public float getRightLevel() {
		return this.rightLevel;
	}
	
	public String getName() {
		return this.name;
	}
	
	@Override
	public boolean getMute() {
		return this.mute;
	}
	
	@Override
	public void setMute(boolean mute) {
		this.mute = mute;
	}
	
	@Override
	public float getSoundLevelBoost() {
		return soundLevelBoost;
	}
	
	@Override
	public void setSoundLevelBoost(float newSoundLevelBoost) {
		if (newSoundLevelBoost != this.soundLevelBoost) {
			this.leftLevel = this.leftLevel / this.soundLevelBoost * newSoundLevelBoost;
			this.rightLevel = this.leftLevel / this.soundLevelBoost * newSoundLevelBoost;
			this.soundLevelBoost = newSoundLevelBoost;
			if (configIhm != null) {
				configIhm.setSoundLevelBoost(newSoundLevelBoost);
			}
		}
	}
	
	public ConfigIhm getIhm() {
		return configIhm;
	}
	
	public boolean haveIhm() {
		return configIhm != null;
	}
	
	public void setLineIhm(LinePanel aLineIhm) {
		this.lineIhm = aLineIhm;
	}
}
