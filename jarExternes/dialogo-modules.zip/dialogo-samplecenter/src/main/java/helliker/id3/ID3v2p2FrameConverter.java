package helliker.id3;

import java.util.HashMap;
import java.util.Map;

/**
 *	Convert a limited set of ID3v2.2 frame IDs to ID3v2.3 IDs
 * 
 *  @author acinader@arcin.net
 *
 * 
 */
public class ID3v2p2FrameConverter {
	
	public static Map idMap = new HashMap();
	
	static {
		
		idMap.put("TT2", ID3v2Frames.TITLE);
		idMap.put("TP1", ID3v2Frames.LEAD_PERFORMERS);
		idMap.put("TAL", ID3v2Frames.ALBUM);
		idMap.put("TCO", ID3v2Frames.CONTENT_TYPE);
		idMap.put("TEN", ID3v2Frames.ENCODED_BY);
		idMap.put("TRK", ID3v2Frames.TRACK_NUMBER);	 
		idMap.put("TYE", ID3v2Frames.YEAR);
		idMap.put("COM", ID3v2Frames.COMMENTS); // don't think this one will work
	
	}
	
	/**
	 * Convert ID3v2.2 IDs to ID3v2.3 IDs.  Only converts the ID's that I need
	 * i.e. the basic set. Title, Artist, Album, Track, Year.  Others could be
	 * added.  If there is anything more complex then just changing the ID, a
	 * different mechanise would be needed (could be another method in this
	 * object
	 * 
	 * @param id The ID3v2.2
	 * @return String The ID3v2.3 tag equivelent
	 * @throws ID3v2FormatException if the conversion is not implemented
	 */
	public static String convertID(String id) throws ID3v2FormatException {
		if(!idMap.containsKey(id)) 
			// could certainly make a less obnoxious way to point this out.
			throw new ID3v2FormatException(id + " was not converted");
		
		return (String) idMap.get(id);
		
	}

}
