package fr.lexiphone.reusable.util.i18n;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class Messages {

	private static final Log _log = LogFactory.getLog(Messages.class);
	private static ResourceBundle RESOURCE_BUNDLE = null;

	public static void initialize(String in_bundle, Locale in_locale) {
		RESOURCE_BUNDLE = ResourceBundle.getBundle(in_bundle, in_locale);
	}

	public static ResourceBundle getBundle(){
		return RESOURCE_BUNDLE;
	}
	public static String getString(String key) {
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			_log.warn("i18n: key not found: " + key);
			return '!' + key + '!';
		}
	}

	/**
	 * @param key can be null (null will be returned)
	 * @return le texte associ� � la cl�, "" si non existant
	 */
	public static String getStringNoFuss(String key) {
		if (key == null) {
			return null;
		}
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return "";
		}
	}

	/**
	 * @param key can be null (null will be returned)
	 * @return le texte associ� � la cl�, ou la cl� si non existant
	 */
	public static String getStringOrKey(String key) {
		if (key == null) {
			return null;
		}
		try {
			return RESOURCE_BUNDLE.getString(key);
		} catch (MissingResourceException e) {
			return key;
		}
	}

	public static String getFormatedMessage(String key, Object... arguments) {
		return MessageFormat.format(Messages.getString(key), arguments);
	}
	
	public static Locale locale(){
		if(RESOURCE_BUNDLE==null)return null;
		return RESOURCE_BUNDLE.getLocale();
	}
	public static List<String>allKeys(){
		if(RESOURCE_BUNDLE==null)return null;
		return new ArrayList<>(RESOURCE_BUNDLE.keySet());
	}
}