package fr.lexiphone.player.impl.jasiohost.provider.jlPlayer;

import java.io.IOException;
import java.io.InputStream;

/**
 * Identifies MP3 files.
 *
 * @author Noa Resare (noa@voxbiblia.com)
 */
public class MP3Identifier
{
	
	private byte[] header = null;
	private long fileSize = 0;
	private int id3TagSize = 0;
	
	public MP3Identifier(byte [] aByteBuffer, long fileSize, int id3TagSize) {
		this.header = aByteBuffer;
		this.fileSize = fileSize;
		this.id3TagSize = id3TagSize;
	}
	
	public static byte[] extractMp3Header(InputStream aMp3File) throws IOException{
		byte [] header = new byte[4];
		aMp3File.mark(4);
		aMp3File.read(header, 0, 4);
		aMp3File.reset();
		return header;
	}
	
    /**
     * If the BufferedInputStream references input that contains an ID3v2
     * metadata tag, determine the length of the tag and skip past it.
     *
     * @param audioStream the BufferedInputStram to read from and possibly
     * skip in 
     * @throws IOException if IO operation fails
     * @return the size of the idtag
     */
    public static int skipID3(InputStream audioStream)
            throws IOException {
        audioStream.mark(10);
        byte[] id3Header = new byte[10];
        if (audioStream.read(id3Header) != id3Header.length) {
            throw new Error("read failed");
        }
        audioStream.reset();
        int tagSize = 0;
        if (id3Header[0] == 'I' && id3Header[1]  == 'D' && id3Header[2] == '3') {
            // tag length does not include the 10 byte header
        	tagSize = getTagLength(id3Header);
        	int toSpkip = tagSize + 10;
            while (toSpkip > 0) {
            	toSpkip -= audioStream.skip(toSpkip);
            }
        }
        return tagSize;
    }
    
    private static int getTagLength(byte [] id3Header){
        int i = id3Header[6] << 21;
        i += id3Header[7] << 14;
        i += id3Header[8] << 7;
        return i + id3Header[9];
    }
    
    private int getLayerVersion(){
    	return (header[1] >> 1) & 3;
    }
    
    private int getMpegVersion(){
    	return (header[1] >> 3) & 3;
    }
    
    private int getBitrateValue(){
    	return (header[2] >> 4) & 15;
    }
    
    private int getFrequencyCode(){
    	return (header[2] >> 2) & 3;
    }
    
    public int getBitrate() {
    	int[][][] table ={
	        { // MPEG 2 & 2.5
	            {0,  8, 16, 24, 32, 40, 48, 56, 64, 80, 96,112,128,144,160,0}, // Layer III
	            {0,  8, 16, 24, 32, 40, 48, 56, 64, 80, 96,112,128,144,160,0}, // Layer II
	            {0, 32, 48, 56, 64, 80, 96,112,128,144,160,176,192,224,256,0}  // Layer I
	        },
	        { // MPEG 1
	            {0, 32, 40, 48, 56, 64, 80, 96,112,128,160,192,224,256,320,0}, // Layer III
	            {0, 32, 48, 56, 64, 80, 96,112,128,160,192,224,256,320,384,0}, // Layer II
	            {0, 32, 64, 96,128,160,192,224,256,288,320,352,384,416,448,0}  // Layer I
	        }};
    	return table[getMpegVersion() & 1][getLayerVersion() - 1][getBitrateValue()];
    }
    
    public int getFrequency() 
    {
        int[][] table = {    
                            {32000, 16000,  8000}, // MPEG 2.5
                            {    0,     0,     0}, // reserved
                            {22050, 24000, 16000}, // MPEG 2
                            {44100, 48000, 32000}  // MPEG 1
                        };
        return table[getMpegVersion()][getFrequencyCode()];
    }
    
    public int getDurationInSeconds() {
    	return (int) (8 * (fileSize - id3TagSize) / 1000 / getBitrate());
    }


}
