
package fr.lexiphone.application.technical;

/**
 * <P>
 *  Interface de marquage des services Application.
 * </P>
 * @author pprimot
 */

public interface IApplicationService {

}
