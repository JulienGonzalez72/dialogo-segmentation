package fr.lexiphone.entreprise.core;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

public class UserProperties extends Properties {
	private static final long serialVersionUID = 605957818159020720L;
	/** properties concernant l'orthophoniste, comme le chemin des donn�es ou le chemin de sauvegarde */
	private final static String userPropertiesFileName = "user.properties"; //$NON-NLS-1$
	private File propsFile;

	public UserProperties(){
		super();
		propsFile=new File(System.getProperty("user.dir")+File.separator+"conf"+File.separator+userPropertiesFileName);
		if(propsFile.exists()){
			try {
				load(new FileInputStream(propsFile));
				//dataPath=userProps.getProperty("data.path");
				//backupPath=userProps.getProperty("backup.path");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			setProperty("data.path", "");
			setProperty("backup.path", "");
		}

	}

	public String getDataPath() {
		return getProperty("data.path");
	}

	public String getBackupPath() {
		return getProperty("backup.path");
	}
	
	public void save(){
		try {
			store(new FileOutputStream(propsFile), "");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void setDataPath(String dataPath) {
		setProperty("data.path", dataPath);
	}

	public void setBackupPath(String path) {
		setProperty("backup.path", path);
	}
}
