/**
 * 
 */
package fr.lexiphone.player.impl;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Closeable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

import javax.annotation.PreDestroy;

import fr.lexiphone.entreprise.workmodule.PlayerState;
import fr.lexiphone.player.PlayerEvent;
import fr.lexiphone.player.PlayerListener;

/**
 * @author C&eacute;drik LIME
 */
// Implementation note: fires events in a single background thread
class PlayerPropertyChangeSupport extends PropertyChangeSupport implements Closeable {
	/** 
	 * The object to be provided as the "source" for any generated events.
	 * Need to copy the definition here as the superclass does not expose it...
	 * @serial
	 */
	private final Object source;
	private final ExecutorService executor = Executors.newSingleThreadExecutor(new ThreadFactory() {
		@Override
		public Thread newThread(Runnable r) {
			Thread t = new Thread(r, "PT PlayerListener thread");
			t.setDaemon(true);
			return t;
		}
	});

	/**
	 * @param sourceBean
	 */
	public PlayerPropertyChangeSupport(Object sourceBean) {
		super(sourceBean);
		this.source = sourceBean;
	}

	@Override
	@PreDestroy
	public void close() {
		executor.shutdownNow();
	}

	public void fireStateChange(PlayerState oldState, PlayerState newState, short sentenceNumber, long positionMillis) {
		final PlayerEvent playerEvent = new PlayerEvent(source, oldState, newState, sentenceNumber, positionMillis);
		executor.execute(new Runnable() {
			PropertyChangeSupport target;
			public Runnable setTarget(PropertyChangeSupport target) {
				this.target = target;
				return this;
			}
			@Override
			public void run() {
				target.firePropertyChange(playerEvent);
			}
		}.setTarget(this));
	}

	public void fireOpened(final String streamName) {
		PropertyChangeListener[] playerListeners = super.getPropertyChangeListeners();
		for (final PropertyChangeListener target : playerListeners) {
			executor.execute(new Runnable() {
				@Override
				public void run() {
					((PlayerListener)target).opened(streamName);
				}
			});
		}
	}

	public void fireRecurrenceJump(PlayerState state, short sentenceNumber, long positionMillis) {
		final PlayerEvent playerEvent = new PlayerEvent(source, state, state, sentenceNumber, positionMillis);
		PropertyChangeListener[] playerListeners = super.getPropertyChangeListeners();
		for (final PropertyChangeListener target : playerListeners) {
			executor.execute(new Runnable() {
				@Override
				public void run() {
					((PlayerListener)target).recurrenceJump(playerEvent);
				}
			});
		}
	}

	public void fireSeek(PlayerState state, short sentenceNumber, long positionMillis) {
		final PlayerEvent playerEvent = new PlayerEvent(source, state, state, sentenceNumber, positionMillis);
		PropertyChangeListener[] playerListeners = super.getPropertyChangeListeners();
		for (final PropertyChangeListener target : playerListeners) {
			executor.execute(new Runnable() {
				@Override
				public void run() {
					((PlayerListener)target).seek(playerEvent);
				}
			});
		}
	}
}
