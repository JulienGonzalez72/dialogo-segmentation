package fr.lexiphone_pt.entreprise.signalprocessing;

import fr.lexiphone.entreprise.technical.EntrepriseException;
import fr.lexiphone.entreprise.technical.IEntrepriseService;
import fr.lexiphone.entreprise.workmodule.ExerciseType;
import fr.lexiphone.entreprise.workmodule.PhaseConfigurationBean;
import fr.lexiphone.entreprise.workmodule.PlayerDataBean;
import java.awt.Color;
import java.awt.Font;
import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * <P>
 *  Service de pilotage du module technique de gestion des
 *  postes de travail et du poste th�rapeute.
 * </P>
 * @author pprimot
 */
public interface IEntrepriseSignalProcessingService extends IEntrepriseService, Remote {

	// Modes M, M/P, P de fonctionnement du Lexiphone
	public static final String MODE_M = "MODE_M"; //$NON-NLS-1$
	public static final String MODE_MP = "MODE_MP"; //$NON-NLS-1$
	public static final String MODE_P = "MODE_P"; //$NON-NLS-1$
	// Modes exponentiel / lin�raire de fonctionnement du Lexiphone
	public static final int MODE_LIN = 0;
	public static final int MODE_EXP = 1;

	/**
	 * Envoie les donn�es buffuris�es au module de traitement du signal
	 */
	public void commit() throws RemoteException;

	// Vu-m�tre

	/**
	 * @return [0..1]
	 */
	public float getPlayerOutputVUMeterLevel() throws RemoteException;

	/**
	 * @return [0..1]
	 */
	public float getMicrophoneOutputVUMeterLevel() throws RemoteException;

	/**
	 * @return int
	 */
	public int getMaxIn0() throws RemoteException;

	/**
	 * @return int
	 */
	public int getMaxIn1() throws RemoteException;

	/**
	 * @return int
	 */
	public int getMaxOut0() throws RemoteException;

	/**
	 * @return int
	 */
	public int getMaxOut1() throws RemoteException;

	/**
	 * @return float
	 */
	public float getMaxPrmIn() throws RemoteException;

	/**
	 * @return float
	 */
	public float getPosRel() throws RemoteException;
	/**
	 * @return sample duration, in milliseconds
	 */
	public long getSampleTotalTime() throws RemoteException;

	/**
	 * Sets the posRel.
	 * @param posRel The posRel to set
	 * @deprecated not precise enough for precise positioning. Use {@link #setPosMillisec(long)}.
	 */
	@Deprecated
	public void setPosRel(float posRel) throws RemoteException;

	/**
	 * Sets the posSec.
	 * @param posMillisec The posMillisec to set
	 */
	public void setPosMillisec(long posMillisec) throws RemoteException;

	/**
	 * @return float
	 */
	public float getFrq() throws RemoteException;

	// Lexiphone

	/**
	 * Sets the nCrtIn.
	 * @param nCrtIn The nCrtIn to set
	 */
	public void setNCrtIn(int nCrtIn) throws RemoteException;

	/**
	 * Sets the nCrtOut.
	 * @param nCrtOut The nCrtOut to set
	 */
	public void setNCrtOut(int nCrtOut) throws RemoteException;

	/**
	 * Sets the tleBuf.
	 * @param tleBuf The tleBuf to set
	 */
	public void setTleBuf(int tleBuf) throws RemoteException;

	/**
	 * Sets the nbrBuf.
	 * @param nbrBuf The nbrBuf to set
	 */
	public void setNbrBuf(int nbrBuf) throws RemoteException;

	/**
	 * Sets the coefIn00: In0 = micro PT, In00 = gauche
	 * @param coefIn00 The coefIn00 to set
	 */
	public void setCoefIn00(float coefIn00) throws RemoteException;

	/**
	 * Sets the coefIn01: In0 = micro PT, In01 = droite
	 * @param coefIn01 The coefIn01 to set
	 */
	public void setCoefIn01(float coefIn01) throws RemoteException;

	/**
	 * Sets the coefIn10: In1 = micro TH, In10 = gauche
	 * @param coefIn10 The coefIn10 to set
	 */
	public void setCoefIn10(float coefIn10) throws RemoteException;

	/**
	 * Sets the coefIn11: In1 = micro TH, In11 = droit
	 * @param coefIn11 The coefIn11 to set
	 */
	public void setCoefIn11(float coefIn11) throws RemoteException;

	/**
	 * Sets the coefM0: M = son modul� (MP3) (mixage), 0 = gauche
	 * @param coefM0 The coefM0 to set
	 */
	public void setCoefM0(float coefM0) throws RemoteException;

	/**
	 * Sets the coefM1: M = son modul� (MP3) (mixage), 1 = droite
	 * @param coefM1 The coefM1 to set
	 */
	public void setCoefM1(float coefM1) throws RemoteException;

	/**
	 * Sets the coefP0: P = son param�trique (mixage), 0 = gauche
	 * @param coefP0 The coefP0 to set
	 */
	public void setCoefP0(float coefP0) throws RemoteException;

	/**
	 * Sets the coefP1: P = son param�trique (mixage), 1 = droite
	 * @param coefP1 The coefP1 to set
	 */
	public void setCoefP1(float coefP1) throws RemoteException;

	/**
	 * Sets the prmIn0: partie du mixage qui rentre dans la param�trie, 0 = PT
	 * @param prmIn0 The prmIn0 to set
	 */
	public void setPrmIn0(float prmIn0) throws RemoteException;

	/**
	 * Sets the prmIn1: partie du mixage qui rentre dans la param�trie, 1 = TH
	 * @param prmIn1 The prmIn1 to set
	 */
	public void setPrmIn1(float prmIn1) throws RemoteException;

	/**
	 * Sets the prmM: partie du mixage qui rentre dans la param�trie, M = son modul� (MP3)
	 * @param prmM The prmM to set
	 */
	public void setPrmM(float prmM) throws RemoteException;

	/**
	 * Sets the f0: fr�quence maximal d'�coute d'ultrason
	 * @param f0 The f0 to set
	 */
	public void setF0(float f0) throws RemoteException;

	/**
	 * Sets the f1: fr�quence minimal d'�coute d'ultrason = 4000Hz
	 * @param f1 The f1 to set
	 */
	public void setF1(float f1) throws RemoteException;

	/**
	 * Sets the seuilLmt: plus bas volume audible = 0.03
	 * @param seuilLmt The seuilLmt to set
	 */
	public void setSeuilLmt(float seuilLmt) throws RemoteException;

	/**
	 * Sets the typeLmt: lin�aire / exponentiel
	 * @param typeLmt The typeLmt to set
	 */
	public void setTypeLmt(int typeLmt) throws RemoteException;

	/**
	 * Sets the frqPb1.
	 * @param frqPb1 The frqPb1 to set
	 */
	public void setFrqPb1(float frqPb1) throws RemoteException;

	/**
	 * Sets the frqPh1.
	 * @param frqPh1 The frqPh1 to set
	 */
	public void setFrqPh1(float frqPh1) throws RemoteException;

	/**
	 * Sets the frqPbDemod.
	 * @param frqPbDemod The frqPbDemod to set
	 */
	public void setFrqPbDemod(float frqPbDemod) throws RemoteException;


	/**
	 * Sets the recSeuil.
	 * @param recSeuil The recSeuil to set
	 */
	public void setRecSeuil(float recSeuil) throws RemoteException;

	/**
	 * Sets the recPrd.
	 * @param recPrd The recPrd to set
	 */
	public void setRecPrd(float recPrd) throws RemoteException;

	/**
	 * Sets the mtvPrd.
	 * @param mtvPrd The mtvPrd to set
	 */
	public void setMtvPrd(float mtvPrd) throws RemoteException;

	/**
	 * Sets the mtvPrc.
	 * @param mtvPrc The mtvPrc to set
	 */
	public void setMtvPrc(float mtvPrc) throws RemoteException;


	/**
	 * Sets the file to play and starts the current phase.
	 */
	public void startPhase(PhaseConfigurationBean in_configuration) throws RemoteException, EntrepriseException;

	/**
	 * Sets the server IP address.
	 * @param in_ip The IP
	 */
	public void setIPAdr(String in_ip) throws RemoteException;

	/**
	 * Sets the server port.
	 * @param in_port The server port
	 */
	public void setIPPort(int in_port) throws RemoteException;

	/**
	 * Sets the c0g: casque PT gauche
	 * @param c0g The c0g to set
	 */
	public void setC00(float c00) throws RemoteException;
	
	/**
	 * Sets the c0d: casque PT droite
	 * @param c0d The c0d to set
	 */
	public void setC01(float c01) throws RemoteException;

	/**
	 * Sets the c1g: casque TH gauche
	 * @param c1g The c1g to set
	 */
	public void setC10(float c10) throws RemoteException;
	
	/**
	 * Sets the c1d: casque TH droite
	 * @param c1d The c1d to set
	 */
	public void setC11(float c11) throws RemoteException;

	public void setPatientSpeedModifier(float value) throws RemoteException;

	public void setNonProsodicLeftLevel(float value) throws RemoteException;
	public void setNonProsodicRightLevel(float value) throws RemoteException;

	public void playSound() throws RemoteException;
	public void playSound(long milliseconds) throws RemoteException;
	public void stopSound() throws RemoteException;
	public void pauseSound() throws RemoteException;
	/** pause or resume sound, depending on the player state */
	public void pauseOrResumeSound() throws RemoteException;
	public void fastForwardSound() throws RemoteException;
	public void fastReverseSound() throws RemoteException;
	public void recurrenceJump() throws RemoteException;

	public void setRecurrenceAllowed(boolean in_recurrence) throws RemoteException;
	/** Fin de 1/2 s�ance */
	public void endStep() throws RemoteException;

	/**
	 * Refreshes the PlayerDataBean after creating it if it doesn't already exists, and returns it.
	 * @return the bean
	 * @throws RemoteException
	 */
	public PlayerDataBean getRefreshedPlayerDataBean()throws RemoteException;

	/**
	 * Puts the sample at the beginning of sentence number n (beginning by 0)
	 * @param n le num�ro de phrase
	 * @throws RemoteException
	 */
	public void setCurrentSentenceNumber(Integer n) throws RemoteException;

	/**
	 * 
	 * @return the total sentence number for current sample, or null if not available.
	 * @throws RemoteException
	 */
	public Integer getTotalSentenceNumber() throws RemoteException;

	public void setFont(Font font) throws RemoteException;

	//public void setLetterDelay(String value) throws RemoteException;

	public void setCaseSensitive(boolean sensitive)throws RemoteException;

	public void setPunctuationSensitive(boolean sensitive)throws RemoteException;

	public void setMaxErrorsNumber(int n)throws RemoteException;

	public void enable()throws RemoteException;
	
	public void run()throws RemoteException;

	public void setLetterPersistence(int n)throws RemoteException;

	public void setAnimateDisplay(boolean b)throws RemoteException;
	
	public void setAllowAudioWindowRestore(boolean b)throws RemoteException;

	public String checkIfSampleHasErrorBeforeStarting(String relativePath, ExerciseType type, String phaseTypeName)throws RemoteException;

	public void setTextBackground(Color color)throws RemoteException;

	public boolean maybePlayIntro()throws RemoteException;
}
