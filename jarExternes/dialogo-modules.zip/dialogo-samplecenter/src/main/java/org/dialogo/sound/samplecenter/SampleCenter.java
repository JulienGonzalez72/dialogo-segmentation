/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.dialogo.sound.samplecenter;


import org.dialogo.sound.file.FiltersLocator;


/**
 *
 * @author haerwynn
 */
public class SampleCenter {
	private static ISampleLocator locator;
	private static FiltersLocator filtersLocator;
	private static SampleCenterConfig config = null;
	private static ISampleService service = null;

	public static void reinit(SampleCenterConfig conf) {
		if (conf != null) {
			filtersLocator=null;
			locator=null;
			config = conf;
		}
	}
	public static boolean isInited(){
		return config != null;
	}
	public static void init(SampleCenterConfig conf) {
		if (conf != null && config == null) {
			config = conf;
		}
	}

	public static FiltersLocator filters() {
		if(filtersLocator==null){
			if(config.getI18nPath()!=null)filtersLocator=new FiltersLocator(config.getI18nPath());
			else filtersLocator=new FiltersLocator(config.getI18nBundle());
		}
		return filtersLocator;
	}

	private SampleCenter() {
		throw new UnsupportedOperationException("not instanciable");
	}

	public static SampleCenterConfig config() {
		return config;
	}
	
	public static ISampleService service(){
		if(config == null)throw new UnsupportedOperationException("config = null");
		if(service==null){
			service=new SampleService();
		}
		return service;
	}
	
	public static ISampleLocator locator(){
		if(config == null)throw new UnsupportedOperationException("config = null");
		if(locator==null){
			if(config.getSampleLocator()!=null)locator=config.getSampleLocator();
			else locator=new SampleLocator(config.getSamplesRootPath());
		}
		return locator;
	}
	public static void setLocator(ISampleLocator sampleLocator) {
		if(sampleLocator!=null)locator=sampleLocator;
	}

}
