package fr.lexiphone.player.impl.jasiohost.bus.asio;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Map;
import java.util.Set;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import com.synthbot.jasiohost.AsioChannel;
import com.synthbot.jasiohost.AsioDriverListener;

import fr.lexiphone.player.impl.jasiohost.StereoBuffer;
import fr.lexiphone.player.impl.jasiohost.bus.LeaderBus;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import fr.lexiphone.player.impl.jasiohost.tools.parameters.Parameters;

public class AsioBus extends LeaderBus implements AsioDriverListener {

	public static String ID = "Asio";
	protected final static String SOUND_BOOST = "soundLevelBoost";

	private Asio asioDriver = null;
	
	private Map<String, String> properties = null;

	public AsioBus() {
		super(ID);
		asioDriver = new Asio();
		loadParameters();
		initIhm();
	}

	/**
	 * this methods load the saved parameters
	 */
	private void loadParameters() {
		properties = Parameters.getInstance().getBusParameters(this);
		String soundLevelBoost = properties.get(SOUND_BOOST);
		setSoundLevelBoost(soundLevelBoost == null ? 4.0f : Float.parseFloat(soundLevelBoost));
	}

	@Override
	public boolean initDriver() {
		asioDriver.addAsioDriverListener(this);
		boolean result = asioDriver.initializeDriver() == 0;
		if (result) {
			this.frameRate = asioDriver.getSampleRate();
			((AsioBusIhm)this.configIhm).updateFrameRate(this.frameRate);
		}
		if (asioDriver.getLeftOutputChannel() == null || asioDriver.getRightOutputChannel() == null) {
			asioDriver.controlPanel();
			configIhm.initAndShowIhm();
		}
		return result;
	}

	@Override
	public void setSoundLevelBoost(float soundLevelBoost) {
		super.setSoundLevelBoost(soundLevelBoost);
		properties.put(SOUND_BOOST, Float.toString(soundLevelBoost));
	}

	@Override
	public int getBufferSize() {
		return asioDriver.getBufferSize();
	}

	@Override
	public void write(StereoBuffer aStereoBuffer) {
		if (asioDriver.getLeftOutputChannel() != null) {
			asioDriver.getLeftOutputChannel().write(aStereoBuffer.getLeftChannel());
		}
		if (asioDriver.getRightOutputChannel() != null) {
			asioDriver.getRightOutputChannel().write(aStereoBuffer.getRightChannel());
		}
		if (asioDriver.getLeftTHOutputChannel() != null) {
			asioDriver.getLeftTHOutputChannel().write(aStereoBuffer.getLeftChannel());
		}
		if (asioDriver.getRightTHOutputChannel() != null) {
			asioDriver.getRightTHOutputChannel().write(aStereoBuffer.getRightChannel());
		}
	}

	@Override
	public boolean changeFrameRate(double sampleRate) {
		if ((sampleRate != 44100.0 && sampleRate != 48000.0) || this.asioDriver == null) {
			return false;
		}
		
		boolean result = asioDriver.initializeDriver(sampleRate) == 0;
		if (result) {
			this.frameRate = asioDriver.getSampleRate();
			((AsioBusIhm)this.configIhm).updateFrameRate(this.frameRate);
		} else {
			return false;
		}
		
		if (this.effect != null) {
			this.effect.setBus(this);
		}
		for(BaseProvider provider : this.devices) {
			provider.sampleRateChanged(this.frameRate, this);
		}
		return true;
	}
	
	/**
s	 * @return the asio Driver
	 */
	public Asio getDriver() {
		return this.asioDriver;
	}
	
	public void initIhm() {
		final AsioBusIhm anIhm = new AsioBusIhm(asioDriver);
		anIhm.setSoundLevelBoost(this.soundLevelBoost);
		configIhm = anIhm;
		anIhm.addSoundLevelBoostChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				setSoundLevelBoost(configIhm.getSoundLevelBoost());
			}
		});
		anIhm.addActionToOkButton(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Parameters.getInstance().setBusParameters(AsioBus.this, properties);
			}
		});
	}

	@Override
	public boolean stopDriver() {
		asioDriver.stopDriver();
		return true;
	}

	/**
	 * call the asio driver control panel
	 */
	public void showControlPanel() {
		asioDriver.controlPanel();
	}
	
	/**
	 * AsioDriver implementations
	 */

	/**
	 * This is the most important method, she's call
	 * everytime that the buffer is going to be empty !
	 * In others terms this is here that you will be take the sound
	 * who want to listen
	 */
	@Override
	public void bufferSwitch(long sampleTime, long samplePosition, Set<AsioChannel> activeChannels) {
		theListener.bufferSwitch();
	}
	
	/**
	 * This method is call when the buffer size is changed
	 * on the control panel of the driver
	 * If somebody change the buffer size, we need to
	 * reinit the driver
	 */
	@Override
	public void bufferSizeChanged(int bufferSize) {
		//System.out.println("bufferChange");
		resetRequest();
	}
	
	@Override
	public void latenciesChanged(int inputLatency, int outputLatency) {	
		//System.out.println("Latency Changed");
		resetRequest();
	}

	@Override
	public void resetRequest() {
		initDriver();
		theListener.bufferSizeChanged(asioDriver.getBufferSize());
	}

	@Override
	public void resyncRequest() {
		//System.out.println("must resync");
	}

	@Override
	public void sampleRateDidChange(double sampleRate) {
		//System.out.println("Sample rate changed");
		resetRequest();
	}
}
