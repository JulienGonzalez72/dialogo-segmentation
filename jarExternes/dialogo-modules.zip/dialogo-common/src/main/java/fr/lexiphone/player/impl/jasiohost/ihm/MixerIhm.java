package fr.lexiphone.player.impl.jasiohost.ihm;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import fr.lexiphone.player.impl.jasiohost.Mixer;
import fr.lexiphone.player.impl.jasiohost.bus.BaseBus;
import fr.lexiphone.player.impl.jasiohost.effect.ParametricEffectIhm;
import fr.lexiphone.player.impl.jasiohost.provider.BaseProvider;
import fr.lexiphone.player.impl.jasiohost.tools.LexiTools;
import fr.lexiphone.player.impl.jasiohost.tools.parameters.Parameters;

public class MixerIhm {

	private JFrame jFrame = null;
	private JPanel jContentPane = null;
	private JMenuBar jJMenuBar = null;
	private JMenu jMenuConfig = null;
	private JMenu jMenuHelp = null;
	private JMenuItem About = null;
	private JCheckBoxMenuItem ihmPanel = null;
	private JMenuItem saveParameters = null;
	private JMenuItem reloadParamenters = null;
	private JPanel jPanelInputLines, jPanelOutputLines, jPanelDevices = null;
	private JPanel jPanelLabel = null;
	private JPanel jPanelLines = null;
	private JPanel jPanelEffect = null;
	private JPanel jPanelBusName = null;
	private JSlider jSliderDevicesLeft, jSliderDevicesRight = null;

	private Mixer mixerInstance = null;

//	private Asio asioDriver = null;
	
	public MixerIhm(Mixer instance) {
		this.mixerInstance = instance;
	}
	
	/**
	 * add visual lines for a list of devices
	 * @param discoveredDevices the list of instance of BaseProvider
	 */
	public void addDevicesOnMixer(List<BaseProvider> discoveredDevices) {
		for(BaseProvider aSoundProvider : discoveredDevices) {
			getJPanelInputLines().add(new LinePanel(aSoundProvider));
		}
	}
	
	/**
	 * add visual line for a bus
	 * @param aBus a bus class which are an instance of BaseBus
	 */
	public void addBusOnMixer(BaseBus aBus) {
		getJPanelOutputLines().add(new LinePanel(aBus));
	}

	public void init(WindowAdapter anAdapter) {
		getJFrame(anAdapter).setVisible(true);
	}

	/**
	 * This method initializes jFrame
	 * 
	 * @return javax.swing.JFrame
	 */
	private JFrame getJFrame(WindowAdapter anAdapter) {
		if (jFrame == null) {
			jFrame = new JFrame();
			jFrame.setSize(new Dimension(614, 400));
			jFrame.setTitle("Lexidia Mixer");
			jFrame.setJMenuBar(getJJMenuBar());
			jFrame.setContentPane(getJContentPane());
			jFrame.setResizable(true);
			jFrame.addWindowListener(anAdapter);
		}
		return jFrame;
	}

	/**
	 * This method initializes jContentPane
	 * 
	 * @return javax.swing.JPanel
	 */
	private JPanel getJContentPane() {
		if (jContentPane == null) {
			jContentPane = new JPanel();
			jContentPane.setLayout(new BorderLayout());
			jContentPane.add(getJPanelLabel(), BorderLayout.LINE_START);
			jContentPane.add(getJPanelLines(), BorderLayout.CENTER);
		}
		return jContentPane;
	}

	/**
	 * This method initializes jJMenuBar
	 * 
	 * @return javax.swing.JMenuBar
	 */
	private JMenuBar getJJMenuBar() {
		if (jJMenuBar == null) {
			jJMenuBar = new JMenuBar();
			jJMenuBar.add(getJMenuConfig());
			jJMenuBar.add(getJMenuHelp());
		}
		return jJMenuBar;
	}

	/**
	 * This method initializes jMenuConfig
	 * 
	 * @return javax.swing.JMenu
	 */
	private JMenu getJMenuConfig() {
		if (jMenuConfig == null) {
			jMenuConfig = new JMenu();
			jMenuConfig.setText("Configuration");
			jMenuConfig.add(getIhmPanel());
			jMenuConfig.add(getReloadParamenters());
			jMenuConfig.add(getSaveParameters());
		}
		return jMenuConfig;
	}

	/**
	 * This method initializes jMenuHelp
	 * 
	 * @return javax.swing.JMenu
	 */
	private JMenu getJMenuHelp() {
		if (jMenuHelp == null) {
			jMenuHelp = new JMenu();
			jMenuHelp.setText("About");
			jMenuHelp.add(getAbout());
		}
		return jMenuHelp;
	}

	/**
	 * This method initializes About
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private JMenuItem getAbout() {
		if (About == null) {
			About = new JMenuItem("About");
		}
		return About;
	}

	/**
	 * This method initializes controlPanel
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private JCheckBoxMenuItem getIhmPanel() {
		if (ihmPanel == null) {
			ihmPanel = new JCheckBoxMenuItem("Open ihm");
			ihmPanel.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					Parameters.getInstance().openIhm(ihmPanel.isSelected());
				}
			});
		}
		return ihmPanel;
	}
	
	public void selectOpenIhm() {
		getIhmPanel().setSelected(true);
	}

	public JSlider getJSliderDevicesLeft() {
		if (jSliderDevicesLeft == null) {
			jSliderDevicesLeft = new JSlider(SwingConstants.VERTICAL);
			jSliderDevicesLeft.setMaximum(10);
			jSliderDevicesLeft.setMinimum(0);
			jSliderDevicesLeft.setMajorTickSpacing(2);
			jSliderDevicesLeft.setPaintTicks(true);
			jSliderDevicesLeft.setToolTipText("Device Left");
			jSliderDevicesLeft.setValue(2);
			jSliderDevicesLeft.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					mixerInstance.setDevicesLeftLevel((float) (getJSliderDevicesLeft().getValue() / 10.0));
				}
			});
		}
		return jSliderDevicesLeft;
	}

	public JSlider getJSliderDevicesRight() {
		if (jSliderDevicesRight == null) {
			jSliderDevicesRight = new JSlider(SwingConstants.VERTICAL);
			jSliderDevicesRight.setMaximum(10);
			jSliderDevicesRight.setMinimum(0);
			jSliderDevicesRight.setMajorTickSpacing(2);
			jSliderDevicesRight.setPaintTicks(true);
			jSliderDevicesRight.setToolTipText("Device Right");
			jSliderDevicesRight.setValue(2);
			jSliderDevicesRight.addChangeListener(new ChangeListener() {
				@Override
				public void stateChanged(ChangeEvent e) {
					mixerInstance.setDevicesRightLevel(getJSliderDevicesRight().getValue() / 10.0f);
				}
			});
		}
		return jSliderDevicesRight;
	}
	
	/**
	 * This method initializes controlPanel
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private JMenuItem getReloadParamenters() {
		if (reloadParamenters == null) {
			reloadParamenters = new JMenuItem("Reload Config");
			reloadParamenters.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					Parameters.getInstance().reload();
				}
			});
		}
		return reloadParamenters;
	}

	/**
	 * This method initializes controlPanel
	 * 
	 * @return javax.swing.JMenuItem
	 */
	private JMenuItem getSaveParameters() {
		if (saveParameters == null) {
			saveParameters = new JMenuItem("Save Config");
			saveParameters.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					Parameters.getInstance().save();
				}
			});
		}
		return saveParameters;
	}

	/**
	 * This method initializes jPanelLabel	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelLabel() {
		if (jPanelLabel == null) {	
			jPanelLabel = new JPanel();
			jPanelLabel.setLayout(new BorderLayout());
			jPanelLabel.add(new JLabel("Lines :"), BorderLayout.CENTER);
			jPanelLabel.add(getJPanelBusName(), BorderLayout.PAGE_END);
		}
		return jPanelLabel;
	}

	/**
	 * This method initializes jPanelLines	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelLines() {
		if (jPanelLines == null) {
			jPanelLines = new JPanel();
			jPanelLines.setLayout(new BorderLayout());
			jPanelLines.add(createSection("Input Devices", getJPanelInputLines()), BorderLayout.LINE_START);
			JPanel jPanelCenter = new JPanel(new BorderLayout());
			jPanelCenter.add(createSection("Mix devices", getJPanelDevices()), BorderLayout.LINE_START);
			jPanelCenter.add(createSection("Effects", getJPanelEffect()), BorderLayout.CENTER);
			jPanelLines.add(jPanelCenter, BorderLayout.CENTER);
			jPanelLines.add(createSection("Output Lines", getJPanelOutputLines()), BorderLayout.LINE_END);
		}
		return jPanelLines;
	}
	
	private JPanel getJPanelDevices() {
		if(this.jPanelDevices == null) {
			FlowLayout flowLayout = new FlowLayout();
			flowLayout.setVgap(5);
			this.jPanelDevices = new JPanel(flowLayout);
			this.jPanelDevices.add(getJSliderDevicesLeft(), null);
			this.jPanelDevices.add(getJSliderDevicesRight(), null);
		}
		return jPanelDevices;
	}
	
	/**
	 * this method create jpanel for display lines
	 * @param name a string that is the name of the lines (input, output , ...)
	 * @param lines a jPanel with the lines
	 * @return the integrated jPanel
	 */
	private JPanel createSection(String name, JPanel lines){
		TitledBorder title = BorderFactory.createTitledBorder(
				BorderFactory.createEtchedBorder(EtchedBorder.LOWERED), name);
		title.setTitleJustification(TitledBorder.CENTER);
		lines.setBorder(title);
		return lines;
	}
	
	private JPanel getJPanelInputLines() {
		if(jPanelInputLines  == null) {
			jPanelInputLines = new JPanel();
			jPanelInputLines.setLayout(new BoxLayout(jPanelInputLines, BoxLayout.X_AXIS));
		}
		return jPanelInputLines;
	}

	private JPanel getJPanelEffect() {
		if (jPanelEffect == null) {
			jPanelEffect = new JPanel(new BorderLayout());
		}
		return jPanelEffect;
	}

	private JPanel getJPanelOutputLines() {
		if (jPanelOutputLines == null) {
			jPanelOutputLines = new JPanel();
			jPanelOutputLines.setLayout(new BoxLayout(jPanelOutputLines, BoxLayout.X_AXIS));
		}
		return jPanelOutputLines;
	}

	/**
	 * This method initializes jPanelBusName	
	 * 	
	 * @return javax.swing.JPanel	
	 */
	private JPanel getJPanelBusName() {
		if (jPanelBusName == null) {
			jPanelBusName = new JPanel();
			jPanelBusName.setLayout(new BoxLayout(jPanelBusName, BoxLayout.Y_AXIS));
			getBusLabel("Asio Bus", jPanelBusName);
			getBusLabel("Default Bus", jPanelBusName);
		}
		return jPanelBusName;
	}
	
	private void getBusLabel(String name, JPanel panel) {
		JLabel aLabel = new JLabel(name, JLabel.CENTER);
		panel.add(aLabel);
		panel.add(Box.createRigidArea(new Dimension(0,7)));
	}
	
	public void setEffectIhm(String [] effectNames, ActionListener anEffectAction) {
		JComboBox aCombo = new JComboBox(LexiTools.concat(new String[]{"none"}, effectNames));
		aCombo.setEditable(false);
		aCombo.addActionListener(anEffectAction);
		getJPanelEffect().add(aCombo, BorderLayout.PAGE_START);
	}
	
	public void setPanelEffectIhm(final JPanel panel){
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				getJPanelEffect().add(panel, BorderLayout.CENTER);
				getJPanelEffect().validate();
				getJPanelEffect().repaint();
			}
		});
	}
	
	public void removePanelEffect(){
		SwingUtilities.invokeLater(new Runnable() {
			@Override
			public void run() {
				for(Component compo : getJPanelEffect().getComponents()) {
					if(compo.getClass() == ParametricEffectIhm.class) {
						getJPanelEffect().remove(compo);
						getJPanelEffect().repaint();
					}
				}
			}
		});
	}
}
